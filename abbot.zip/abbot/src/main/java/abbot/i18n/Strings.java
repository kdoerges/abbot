package abbot.i18n;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import abbot.Log;

/** Provides i18n support. */

public class Strings {
    static final String BUNDLE = "abbot.i18n.StringsBundle";
    private static ResourceBundle local;
    private static ResourceBundle fallback;
    private static HashMap formats = new HashMap(5);
    private static HashSet missingResources = new HashSet();
    private static HashSet missingTranslations = new HashSet();

    static {
        Locale locale = Locale.getDefault();
        try {
            local = ResourceBundle.getBundle(BUNDLE, locale);
            fallback = ResourceBundle.getBundle(BUNDLE, Locale.US);
        }
        catch(MissingResourceException mre) {
            try {
                local = ResourceBundle.getBundle(BUNDLE, Locale.US);
                fallback = local;
            }
            catch(MissingResourceException mre2) {
                Log.warn("No resource bundle found in " + BUNDLE);
                System.exit(1);
            }
        }
        Runnable runnable = new Runnable() {
            private void showMissing(Iterator iter, String msg) {
                String nl = System.getProperty("line.separator");
                msg += nl;
                while (iter.hasNext()) {
                    msg += (String)iter.next() + nl;
                }
                Log.warn(msg);
            }
            public void run() {
                if (missingTranslations.size() > 0) {
                    showMissing(missingTranslations.iterator(),
                                get("MissingTranslations"));
                }
                if (missingResources.size() > 0) {
                    showMissing(missingResources.iterator(),
                                get("MissingResources"));
                }
            }
        };
        if (Boolean.getBoolean("abbot.show_missing_resources")) {
            Thread thread = new Thread(runnable, "Missing resource checker");
            Runtime.getRuntime().addShutdownHook(thread);
        }
    }

    private Strings() { }

    /** Returns the localized string for the given key, or the key surrounded
        by '#' if no corresponding localized string is found.
    */
    public static String get(String key) {
        return get(key, false);
    }

    /** Returns the localized string for the given key.  If optional is true,
        return null, otherwise returns the key surrounded by '#' if no
        corresponding localized string is found. 
    */
    public static String get(String key, boolean optional) {
        String value = "#" + key + "#";
        try {
            value = local.getString(key);
        }
        catch(MissingResourceException mre) {
            if (!optional) {
                missingTranslations.add(key);
            }
            try { 
                value = fallback.getString(key);
            }
            catch(MissingResourceException mre2) {
                if (optional) {
                    value = null;
                }
                else {
                    Log.log("Missing resource '" + key + "'");
                    missingResources.add(key);
                    missingTranslations.remove(key);
                }
            }
        }
        return value;
    }

    /** Returns a formatted localized string for the given key and arguments,
        or the key if no corresponding localized string is found.  Use
        java.text.MessageFormat syntax for the format string and arguments.
    */
    public static String get(String key, Object[] args) {
        MessageFormat fmt = (MessageFormat)formats.get(key);
        if (fmt == null) {
            fmt = new MessageFormat(get(key));
            formats.put(key, fmt);
        }
        return fmt.format(args);
    }
}
