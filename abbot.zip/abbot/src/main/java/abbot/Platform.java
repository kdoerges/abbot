package abbot;

import java.util.StringTokenizer;
import java.awt.event.InputEvent;

/** Simple utility to figure out what platform we're on. */

public class Platform {

    public static final int JAVA_1_0 = 0x1000;
    public static final int JAVA_1_1 = 0x1100;
    public static final int JAVA_1_2 = 0x1200;
    public static final int JAVA_1_3 = 0x1300;
    public static final int JAVA_1_4 = 0x1400;

    private static String osName = System.getProperty("os.name");

    private static String javaVersion = System.getProperty("java.version");
    private static int javaVersionNumber = JAVA_1_0;

    private static boolean isWindows = osName.startsWith("Windows");
    private static boolean isWindowsXP = isWindows && osName.indexOf("XP") != -1;
    private static boolean isMac = System.getProperty("mrj.version") != null;
    private static boolean isOSX = isMac && osName.indexOf("OS X") != -1;
    private static boolean isSunOS = (osName.startsWith("SunOS")
                                      || osName.startsWith("Solaris"));
    private static boolean isHPUX = osName.equals("HP-UX");
    private static boolean isLinux = osName.equals("Linux");

    /** No instantiations. */
    private Platform() {
    }

    static boolean parsed = false;
    private static void parse() {
        if (!parsed) {
            javaVersionNumber = parse(javaVersion);
            parsed = true;
        }
    }

    private static String strip(String number) {
        while (number.startsWith("0") && number.length() > 1)
            number = number.substring(1);
        return number;
    }

    static int parse(String vs) {
        int version = 0;
        try {
            StringTokenizer st = new StringTokenizer(vs, "._");
            version = Integer.parseInt(strip(st.nextToken())) * 0x1000;
            version += Integer.parseInt(strip(st.nextToken())) * 0x100;
            version += Integer.parseInt(strip(st.nextToken())) * 0x10;
            version += Integer.parseInt(strip(st.nextToken()));
        }
        catch(NumberFormatException nfe) {
        }
        catch(java.util.NoSuchElementException nse) {
        }
        return version;
    }

    // FIXME this isn't entirely correct, maybe should look for a motif class
    // instead. 
    public static boolean isX11() { return !isOSX && !isWindows; }
    public static boolean isWindows() { return isWindows; }
    public static boolean isWindowsXP() { return isWindowsXP; }
    public static boolean isMacintosh() { return isMac; }
    public static boolean isOSX() { return isOSX; }
    public static boolean isSolaris() { return isSunOS; }
    public static boolean isHPUX() { return isHPUX; }
    public static boolean isLinux() { return isLinux; }
    public static String getJavaVersion() { return javaVersion; }
    public static int getJavaVersionNumber() {
        parse();
        return javaVersionNumber;
    }

    public static void main(String[] args) {
        System.out.println("Java version is " + getJavaVersion());
        System.out.println("Version number is " + Integer.toHexString(getJavaVersionNumber()));
        System.out.println("os.name=" + osName);
    }
}
