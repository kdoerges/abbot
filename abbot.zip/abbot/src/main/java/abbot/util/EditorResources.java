package abbot.util;

import java.util.*;


/**
 * Verwaltet zu GBO-Editoren zu zugeh�rigen ResourceBundles
 *  
 */
public class EditorResources {

    private static Map<String, Map<Locale, ResourceBundle>> editorResources =
            new HashMap<String, Map<Locale, ResourceBundle>>();

    public static String getString(String editorClassname, String key) {

        return getString(editorClassname, key, Locale.getDefault());

    }


    public static String getString(String editorClassname, String key, Locale aLocale) {

        try {
            Map<Locale, ResourceBundle> editorBundles = editorResources.get(editorClassname);
            if (editorBundles == null) {

                editorBundles = new HashMap<Locale, ResourceBundle>();
                editorResources.put(editorClassname, editorBundles);
            }

            ResourceBundle editorBundle = editorBundles.get(aLocale);
            if (editorBundle == null) {

                String bundleName = editorClassname + "Text";
                editorBundle = ResourceBundle.getBundle(bundleName, aLocale);
                editorBundles.put(aLocale, editorBundle);
            }

            String value = editorBundle.getString(key);
            return value;

        }


        catch (MissingResourceException mre) {
            return null;
        }
    }

}
