package abbot.util;

import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Window;
import java.awt.event.InputEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;

import abbot.Log;
import abbot.Platform;

/** Various AWT utilities. */

public class AWT {

    private AWT() { }

    /** Ensure the given action happens on the event dispatch thread.  Any
     * component modifications must be invoked this way.
     */
    public static void invokeAndWait(Runnable action) {
        if (EventQueue.isDispatchThread()) {
            action.run();
        }
        else {
            try {
                EventQueue.invokeAndWait(action);
            }
            catch(InterruptedException ie) {
                Log.warn(ie);
            }
            catch(java.lang.reflect.InvocationTargetException ite) {
                Log.warn(ite);
            }
        }
    }

    /** Ensure the given action happens on the event dispatch thread.  Any
     * component modifications must be invoked this way.  Note that this is
     * <b>not</b> the same as EventQueue.invokeLater, since if the current
     * thread is the dispatch thread, the action is invoked immediately.
     */
    public static void invokeAction(Runnable action) {
        if (EventQueue.isDispatchThread()) {
            action.run();
        }
        else {
            EventQueue.invokeLater(action);
        }
    }

    /** Expects to be invoked on the dispatch thread only. */
    private static List disable(Component root, List list) {
        if (root instanceof Container) {
            Component[] children = ((Container)root).getComponents();
            for (int i=0;i < children.length;i++) {
                disable(children[i], list);
            }
        }
        if (root.isEnabled()) {
            list.add(root);
            root.setEnabled(false);
        }
        return list;
    }

    /** Restore the enabled state. */
    public static void reenableHierarchy(final List enabled) {
        invokeAction(new Runnable() {
             public void run() {
                 Iterator iter = enabled.iterator();
                 while (iter.hasNext()) {
                     ((Component)iter.next()).setEnabled(true);
                 }
             }
        });
    }

    /** Disable a component hierarchy starting at the given component.
     * Returns a list of all components which used to be enabled, for use with
     * reenableHierarchy. 
     */ 
    public static List disableHierarchy(final Component root) { 
        final List list = new ArrayList();
        invokeAndWait(new Runnable() {
            public void run() {
                disable(root, list);
            }
        });
        return list;
    }

    /** Return whether the given component is a transient wrapper around a
     * popup.
     */
    public static boolean isTransientPopup(Object c) {
        // check for lightweight popup
        if ((c instanceof JPanel)
            && ((JPanel)c).getComponentCount() == 1
            && (((JPanel)c).getComponents()[0] instanceof JPopupMenu)) {
            // Window might be null if the component has no parent
            Window w = SwingUtilities.getWindowAncestor((Component)c);
            if (w == null || !isTransientPopup(w))
                return true;
        }

        Class cls = c.getClass();
        return cls.getName().startsWith("javax.swing.DefaultPopupFactory$")
            || cls.getName().startsWith("javax.swing.Popup$");
    }

    /** Return whether the given component is part of an internal frame's LAF
        decoration.
    */
    public static boolean isInternalFrameDecoration(Component c) {
        Component parent = c.getParent();
        return (parent instanceof JInternalFrame
                && !(c instanceof JRootPane))
            || (parent != null
                && (parent.getParent() instanceof JInternalFrame)
                && (!(parent instanceof JRootPane)));
    }

    private static final boolean POPUP_ON_BUTTON2 = Platform.isMacintosh();

    /** Returns the InputEvent mask for the popup trigger button. */
    public static int getPopupMask() {
        return POPUP_ON_BUTTON2
            ? InputEvent.BUTTON2_MASK : InputEvent.BUTTON3_MASK;
    }
    /** Returns the InputEvent mask for the tertiary button. */
    public static int getTertiaryMask() {
        return POPUP_ON_BUTTON2
            ? InputEvent.BUTTON3_MASK : InputEvent.BUTTON2_MASK;
    }
    /** Returns whether the platform registers a popup on mouse press. */
    public static boolean getPopupOnPress() {
        return Platform.isWindows();
    }
}
