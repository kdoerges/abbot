package abbot.util;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLStreamHandler;
import java.net.URLStreamHandlerFactory;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import abbot.Platform;


/** Provide a class loader that loads from a custom path.   Similar to
 * sun.misc.Launcher$AppClassLoader (the usual application class loader),
 * except that it doesn't do the security checks that AppClassLoader does.
 * If path given is null, uses java.class.path.
 */
public class PathClassLoader extends java.net.URLClassLoader {

    private String classPath;

    private static final Factory factory = new Factory();

    private static final Logger logger = LoggerFactory.getLogger(PathClassLoader.class);

    /** Create a class loader that loads classes from the given path. */
    public PathClassLoader(String path, ClassLoader parent) {
        super(getURLs(path != null ? path : System.getProperty("java.class.path"), ":;"), parent, factory);
        this.classPath = path != null ? path : System.getProperty("java.class.path");
    }

    public String getClassPath() {
        return classPath;
    }

    @Override
    public synchronized Class loadClass(String name, boolean resolve) throws ClassNotFoundException {
        int i = name.lastIndexOf('.');
        if (i != -1) {
            SecurityManager sm = System.getSecurityManager();
            if (sm != null) sm.checkPackageAccess(name.substring(0, i));
        }
        return super.loadClass(name, resolve);
    }

    static URL[] getURLs(String p, String separators) {
        String s = p != null ? p : System.getProperty("java.class.path");
        File files[] = s != null ? convertPathToFiles(s, separators) : new File[0];
        URL[] urls = new URL[files.length];
        for (int i = 0; i < urls.length; i++) {
            try {
                urls[i] = files[i].toURL();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return urls;
    }

    static File[] convertPathToFiles(String path, String seps) {
        return convertPathToFiles(path, seps, Platform.isWindows() && seps.indexOf(":") != -1);
    }

    static File[] convertPathToFiles(String path, String seps, boolean fixDrives) {
        StringTokenizer st = new StringTokenizer(path, seps);
        java.util.ArrayList files = new java.util.ArrayList();
        while (st.hasMoreTokens()) {
            String fp = st.nextToken();
            // Fix up w32 absolute pathnames
            if (fixDrives && fp.length() == 1 && st.hasMoreTokens()) {
                char ch = fp.charAt(0);
                if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
                    fp += ":" + st.nextToken();
                }
            }
            files.add(new File(fp));
        }
        return (File[])files.toArray(new File[files.size()]);
    }

    /** Taken from sun.misc.Launcher. */
    private static class Factory implements URLStreamHandlerFactory {

        private static final String PREFIX = "sun.net.www.protocol";

        private Factory() {}

        @Override
        public URLStreamHandler createURLStreamHandler(String protocol) {
            String name = PREFIX + "." + protocol + ".Handler";
            try {
                Class c = Class.forName(name);
                return (URLStreamHandler)c.newInstance();
            } catch (ClassNotFoundException e) {
                logger.error("Something ugly happened: ", e);
            } catch (InstantiationException e) {
                logger.error("Something ugly happened: ", e);
            } catch (IllegalAccessException e) {
                logger.error("Something ugly happened: ", e);
            }
            throw new Error("could not load " + protocol + "system protocol handler");
        }
    }
}
