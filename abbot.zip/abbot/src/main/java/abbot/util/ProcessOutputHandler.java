package abbot.util;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import abbot.Log;


/** Default process output handler, redirecting the subprocesses output to
 * System.out and System.err.  Override the handleOutput and handleError
 * methods in order to get different results.
 */
public class ProcessOutputHandler extends Thread {

    private Runnable outputHandler;

    private Runnable errorHandler;

    /** Simple stream reader. */
    private abstract class Reader implements Runnable {

        private InputStream is;

        public Reader(InputStream is) {
            this.is = is;
        }

        public abstract void handleBytes(byte[] buf, int count);

        @Override
        public void run() {
            byte[] buf = new byte[1024];
            while (true) {
                try {
                    int count = is.read(buf, 0, buf.length);
                    if (count == -1) break;
                    handleBytes(buf, count);
                } catch (IOException io) {
                    Log.warn(io);
                    break;
                }
            }
        }
    }

    /** Create an output handler for the given process. */
    public ProcessOutputHandler(Process p) {
        this("Process Output Handler", p);
    }

    /** Create an output handler for the given process. */
    public ProcessOutputHandler(String name, Process p) {
        super("Process output reaper for " + name);
        InputStream output = new BufferedInputStream(p.getInputStream());
        outputHandler = new Reader(output) {

            @Override
            public void handleBytes(byte[] buf, int count) {
                handleInput(buf, count);
            }
        };
        InputStream error = new BufferedInputStream(p.getErrorStream());
        errorHandler = new Reader(error) {

            @Override
            public void handleBytes(byte[] buf, int count) {
                handleError(buf, count);
            }
        };
        setDaemon(true);
    }

    @Override
    public void run() {
        Thread err = new Thread(errorHandler, getName() + " (err)");
        err.start();
        outputHandler.run();
        try {
            err.join();
        } catch (InterruptedException ie) {
            Log.warn(ie);
        }
    }

    protected void handleInput(byte[] buf, int len) {
        System.out.print(new String(buf, 0, len));
    }

    protected void handleError(byte[] buf, int len) {
        System.err.print(new String(buf, 0, len));
    }
}
