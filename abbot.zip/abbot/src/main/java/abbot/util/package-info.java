/**
 * Dieses Package besteht schon in den original Abbot Sourcen und umfasst allgemeine Utilities
 * zum Betrieb von Abbot.
 * <br>
 * Hier werden Klassen abgelegt, die GfD seitig von den original Sourcen �berschrieben 
 * wurden. Die hier abgelegten Klassen ersetzen jeweils das Pendant im Originalpackage. 
 */

package abbot.util;