package abbot.util;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.KeyEvent;

import javax.swing.KeyStroke;

import abbot.Log;
import abbot.tester.Robot;

/** Provide an AWTEventListener which normalizes the event stream.
    Namely, culls extra key events (pre 1.4 VMs).  
*/
public class EventNormalizer implements AWTEventListener {

    private static boolean captureModifierRepeats = 
        Boolean.getBoolean("abbot.capture_modifier_repeats");

    private AWTEventListener listener;
    private long modifiers;

    public void startListening(AWTEventListener listener, long  mask) {
        fnKeyDown = false;
        lastKeyPress = lastKeyRelease = KeyEvent.VK_UNDEFINED;
        lastKeyStroke = null;
        lastKeyChar = KeyEvent.VK_UNDEFINED;
        lastKeyComponent = null;

        this.listener = listener;
        modifiers = 0;
        Toolkit.getDefaultToolkit().addAWTEventListener(this, mask);
    }

    public void stopListening() {
        Toolkit.getDefaultToolkit().removeAWTEventListener(this);
        listener = null;
        modifiers = 0;
    }

    /** For OSX pre-1.4 laptops... */
    private boolean fnKeyDown = false;
    /** These aid in culling duplicate key events, pre-1.4. */
    private int lastKeyPress = KeyEvent.VK_UNDEFINED;
    private int lastKeyRelease = KeyEvent.VK_UNDEFINED;
    private KeyStroke lastKeyStroke = null;
    private char lastKeyChar = KeyEvent.VK_UNDEFINED;
    private Component lastKeyComponent = null;
    /** Returns whether the event is spurious and should be discarded. */
    private boolean isSpuriousEvent(AWTEvent event) {
        return isDuplicateKeyEvent(event) || isOSXFunctionKey(event);
    }

    /** Flag duplicate key events on pre-1.4 VMs, and repeated modifiers. */
    private boolean isDuplicateKeyEvent(AWTEvent event) {
        int id = event.getID();
        if (id == KeyEvent.KEY_PRESSED) {
            KeyEvent ke = (KeyEvent)event;
            lastKeyRelease = KeyEvent.VK_UNDEFINED;
            int code = ke.getKeyCode();

            if (code == lastKeyPress) {
                // Discard duplicate key events (prior to 1.4)
                // A duplicate key event is sent to the parent frame.
                if (event.getSource() != lastKeyComponent) {
                    lastKeyPress = KeyEvent.VK_UNDEFINED;
                    lastKeyComponent = null;
                    Log.debug("Discarded duplicate key press");
                    return true;
                }
            }
            lastKeyPress = code;
            lastKeyComponent = ke.getComponent();

            // Don't pass on key repeats for modifier keys (w32)
            if (Robot.isModifier(code)) {
                int mask = Robot.keyCodeToMask(code);
                if ((mask & modifiers) != 0
                    && !captureModifierRepeats) {
                    Log.debug("Discarded modifier key repeat");
                    return true;
                }
                modifiers |= mask;
            }
        }
        else if (id == KeyEvent.KEY_RELEASED) {
            KeyEvent ke = (KeyEvent)event;
            lastKeyPress = KeyEvent.VK_UNDEFINED;
            int code = ke.getKeyCode();
            if (code == lastKeyRelease) {
                if (event.getSource() != lastKeyComponent) {
                    lastKeyRelease = KeyEvent.VK_UNDEFINED;
                    lastKeyComponent = null;
                    Log.debug("Discarded duplicate key release");
                    return true;
                }
            }
            lastKeyRelease = code;
            lastKeyComponent = ke.getComponent();
            if (Robot.isModifier(code)) {
                modifiers &= ~Robot.keyCodeToMask(code);
            }
        }
        else if (id == KeyEvent.KEY_TYPED) {
            KeyStroke ks = KeyStroke.getKeyStrokeForEvent((KeyEvent)event);
            char ch = ((KeyEvent)event).getKeyChar();
            if (ks == lastKeyStroke || ch == lastKeyChar) {
                if (event.getSource() != lastKeyComponent) {
                    lastKeyStroke = null;
                    lastKeyChar = KeyEvent.VK_UNDEFINED;
                    lastKeyComponent = null;
                    Log.debug("Discarded duplicate key typed");
                    return true;
                }
            }
            lastKeyStroke = ks;
            lastKeyChar = ch;
            lastKeyComponent = ((KeyEvent)event).getComponent();
        }
        else {
            lastKeyPress = lastKeyRelease = KeyEvent.VK_UNDEFINED;
            lastKeyComponent = null;
        }
        
        return false;
    }

    /** Discard function key press/release on 1.3.1 OSX laptops. */
    // FIXME fn pressed after arrow keys results in a RELEASE event
    private boolean isOSXFunctionKey(AWTEvent event) {
        if (event.getID() == KeyEvent.KEY_RELEASED) {
            if (((KeyEvent)event).getKeyCode() == KeyEvent.VK_CONTROL
                && fnKeyDown) {
                Log.debug("Discarded bogus control release");
                fnKeyDown = false;
                return true;
            }
        }
        else if (event.getID() == KeyEvent.KEY_PRESSED) {
            if (((KeyEvent)event).getKeyCode() == KeyEvent.VK_CONTROL) {
                int mods = ((KeyEvent)event).getModifiers();
                if ((mods & KeyEvent.CTRL_MASK) == 0) {
                    fnKeyDown = true;
                    Log.debug("Discarded bogus control press");
                    return true;
                }
            }
        }
        return false;
    }

    /** Event reception callback.  */
    public void eventDispatched(AWTEvent event) {
        boolean discard = isSpuriousEvent(event);
        if (Log.isClassDebugEnabled(getClass())) {
            Log.debug("EventNormalizer " + (discard
                                            ? "discarding "
                                            : "processing ")
                      + Robot.toString(event));
        }
        if (!discard && listener != null)
            listener.eventDispatched(event);
    }
}
