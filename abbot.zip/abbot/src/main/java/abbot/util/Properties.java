package abbot.util;

import testframework.testrunner.RTVariablesSingleton;

import com.obi.test.tregs.abbot.component.AbbotProperties;


public class Properties {

    /** Load an integer system property, keeping it within the given valid
        range. */
    public static int getProperty(String name, int min, int max, int defValue) {
        int value = defValue;

        //abbot_ext_begin

        String prop = null;

        if (RTVariablesSingleton.theInstance().getVariable(name) != null) {
            prop = RTVariablesSingleton.theInstance().getVariable(name);
        } else {
            if (AbbotProperties.theInstance().containsProperty(name)) {
                prop = AbbotProperties.theInstance().getValue(name);
            } else {
                prop = System.getProperty(name);
            }
        }

        //abbot_ext_end

        if (prop != null) {
            try {
                value = Integer.parseInt(prop);
                if (value < min)
                    value = min;
                else if (value > max) value = max;
            } catch (Exception exc) {}
        }
        return value;
    }

    /** Load a long system property, keeping it within the given valid
        range. */
    public static long getProperty(String name, long min, long max, long defValue) {
        long value = defValue;

        //abbot_ext_begin

        String prop = null;

        if (RTVariablesSingleton.theInstance().getVariable(name) != null) {
            prop = RTVariablesSingleton.theInstance().getVariable(name);
        } else {
            if (AbbotProperties.theInstance().containsProperty(name)) {
                prop = AbbotProperties.theInstance().getValue(name);
            } else {
                prop = System.getProperty(name);
            }
        }

        //abbot_ext_end

        if (prop != null) {
            try {
                value = Long.parseLong(prop);
                if (value < min)
                    value = min;
                else if (value > max) value = max;
            } catch (Exception exc) {}
        }
        return value;
    }
}
