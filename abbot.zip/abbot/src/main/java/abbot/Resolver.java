package abbot;

import java.awt.Component;

import abbot.script.ComponentReference;

/** Interface to provide a general context in which tests are run.
 *  Includes ComponentReferences, properties, and a filesystem location.
 */
public interface Resolver {
    /** Return the ComponentReference matching the given id, or null if none
        exists. */
    ComponentReference getComponentReference(String refid);
    /** Return the existing reference for the given component, or null if none
        exists. */
    ComponentReference getComponentReference(Component comp);
    /** Add a new component to the existing collection. */
    ComponentReference addComponent(Component comp);
    /** Add a new component reference to the existing collection. */
    void addComponentReference(ComponentReference ref);
    /** Derive a unique identifier for the given reference. */
    String getUniqueID(ComponentReference ref);
    /** Returns a collection of all the existing references. */
    java.util.Collection getComponentReferences();
    /** Provide a working directory context for relative pathnames. */
    java.io.File getDirectory();
    /** Provide temporary storage of values. */
    void setProperty(String name, String value);
    /** Provide retrieval of values from temporary storage. */
    String getProperty(String name);
}
