package abbot;

/** Current version of the framework. */

public interface Version {
    String VERSION = "0.10.1";
}




