package abbot;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.util.*;
import java.util.List;

import javax.swing.*;

import abbot.script.*;
import abbot.util.ExtendedComparator;
import abbot.tester.*;
import abbot.tester.Robot;

/** Basic component lookup implementation.
 */
// FIXME maybe move some of the component methods to component tester and
// derive from component tester?  or just move them to component utilities?
// FIXME could use some merging of getComponents() functions -- there are two
// places that combine children, owned windows, and menuelements
// FIXME match weights is really not quite the right approach.  what you
// really want is to have a few types of lookup; one needs to be exact, one
// needs to be slightly flexible (allow slight changes in hierarchy/layout),
// and maybe another, though it doesn't come to mind.  then the
// comparisons/tradeoffs can be made explicit instead of being obscured by the
// weight checking.
public class DefaultComponentFinder implements ComponentFinder, Tags {
    /** Timeout for waiting on a popup menu. */
    public static int POPUP_TIMEOUT = 5000;

    private Map filteredComponents = new WeakHashMap();

    /** Allow chaining to existing filter sets. */
    private ComponentFinder parent = null;
    private boolean filter = true;
    private WindowTracker tracker = WindowTracker.getTracker();
    private static boolean trackAppletConsole =
        Boolean.getBoolean("abbot.applet.track_console");

    static {
        String to = System.getProperty("abbot.finder.popup_timeout");
        if (to != null) {
            try {
                POPUP_TIMEOUT = Integer.parseInt(to);
            }
            catch(Exception e) {
            }
        }
    }

    private static DefaultComponentFinder defaultFinder = null;

    /** This is the factory method to use unless you already know otherwise :)
     */ 
    public static ComponentFinder getFinder() {
        return getFinder(null);
    }

    /** This factory method allows the finder to be used where a finder
     * already exists and is filtering components.  This should only be
     * required in very rare cases like when the script editor needs to test
     * itself. 
     */
    public static synchronized ComponentFinder getFinder(ComponentFinder context) {
        if (defaultFinder == null) {
            defaultFinder = new DefaultComponentFinder(context);
        }
        return defaultFinder;
    }

    /** Only factory creation is allowed. */
    private DefaultComponentFinder(ComponentFinder parent) {
        this.parent = parent;
    }

    /** 
     *  Attempt to find the component corresponding to the given reference
     * among existing, visible components.
     *
     *  @param ref A Component reference to use to identify a component
     *  @throws ComponentNotFoundException if a Component cannot be located via
     *  the passed in ComponentReference
     *  @throws MultipleComponentsFoundException if more then one component is 
     *  found via the passed in reference       
     *  @return The component which matches the passed in ComponentReference
     */
    public Component findComponent(ComponentReference ref)
        throws ComponentNotFoundException, MultipleComponentsFoundException {

        return ref.findInHierarchy(this);
    }

    /**
     * Returns the first visible window found using the name as the match
     * critia.  
     * @param match The string to match with a window name
     * @return A window with a name equal to the passed in string, null
     * otherwise 
     */
    private Window findWindowByName(String match) {
        Window[] windows = getWindows();
        for (int i=0;i < windows.length;i++) {
            Window w = windows[i];
            if (w.isShowing()) {
                String name = getComponentName(w);
                if ((match != null && match.equals(name))
                    || name == match) {
                    return w;
                }
            }
        }
        return null;
    }

    /** Return the first visible window whose title matches the given
     * pattern.  
     */
    private Window findWindowByTitle(String title)
        throws ComponentNotFoundException, MultipleComponentsFoundException {
        Window[] windows = getWindows();
        ArrayList found = new ArrayList();
        for (int i=0;i < windows.length;i++) {
            Window w = windows[i];
            if (w.isShowing()) {
                if (w instanceof Dialog) {
                    if (expressionMatch(title, ((Dialog)w).getTitle())) {
                        found.add(w);
                    }
                }
                else if (w instanceof Frame) {
                    if (expressionMatch(title, ((Frame)w).getTitle())) {
                        found.add(w);
                    }
                }
            }
        }
        if (found.size() > 0) {
            if (found.size() == 1)
                return (Window)found.get(0);
            String msg = "More than one Window found with title matching '"
                + title + "'";
            Component[] matches = (Component[])
                found.toArray(new Component[found.size()]);
            throw new MultipleComponentsFoundException(msg, matches);
        }
        String msg = "Window '" + title + "' does not exist or is not showing";
        throw new ComponentNotFoundException(msg);
    }

    /** Return the window with the given name or title.  Attempts to find a
     * named window first, since that search is more restrictive.  Regular
     * expressions are allowed.
     */
    public Window findWindow(String nameOrTitle)
        throws ComponentNotFoundException, MultipleComponentsFoundException {
        Log.debug("Looking for window '" + nameOrTitle + "'");
        Window w = findWindowByName(nameOrTitle);
        if (w == null)
            w = findWindowByTitle(nameOrTitle);
        Log.debug("Found match " + w);
        return w;
    }

    /** Returns the currently active popup menu with the given invoker. */
    public Component findActivePopupMenu(Component invoker) {
        Component popup = findActivePopupMenu(null, invoker);
        if (popup == null
            && !SwingUtilities.isEventDispatchThread()) {
            long now = System.currentTimeMillis();
            while ((popup = findActivePopupMenu(null, invoker)) == null) {
                if (System.currentTimeMillis() - now > POPUP_TIMEOUT) {
                    break;
                }
                try { Thread.sleep(100); } 
                catch(Exception e) { }
            }
        }
        return popup;
    }

    // FIXME there has got to be a better way of finding the currently active
    // popup menu
    private Component findActivePopupMenu(Component root, Component invoker) {
        if (root == null) {
            Window[] wins = getWindows();
            for (int i=0;i < wins.length;i++) {
                Component comp = (Component)wins[i];
                Component menu = findActivePopupMenu(comp, invoker);
                if (menu != null)
                    return menu;
            }
        }
        else if (root instanceof javax.swing.JPopupMenu
            && ((JPopupMenu)root).isShowing()) {
            return root;
        }
        else if (root instanceof Container) {
            Component[] subs = ((Container)root).getComponents();
            for (int i=0;i < subs.length;i++) {
                Component menu = findActivePopupMenu(subs[i], invoker);
                if (menu != null)
                    return menu;
            }
        }
        return null;
    }

    public Component findMenuItemByName(Component root, String name) {
        if (root instanceof JMenuItem
            && ((JMenuItem)root).getText().equals(name))
            return root;
        if (root instanceof Container) {
            Component[] subs = ((Container)root).getComponents();
            for (int i=0;i < subs.length;i++) {
                Component comp = findMenuItemByName(subs[i], name);
                if (comp != null)
                    return comp;
            }
        }
        if (root instanceof MenuElement) {
            MenuElement[] els = ((MenuElement)root).getSubElements();
            for (int i=0;i < els.length;i++) {
                Component comp = findMenuItemByName((Component)els[i], name);
                if (comp != null)
                    return comp;
            }
        }
        return null;
    }

    /** 
     * Return whether the the given title matches the given pattern. 
     */
    private boolean expressionMatch(String pattern, String actual) {
        return ExtendedComparator.stringsMatch(pattern, actual);
    }

    /** Return the component's name, ensuring that null is returned if the
     * name appears to be auto-generated.
     */
    public String getComponentName(Component comp) {
        // Component.getName() can cause deadlocks if invoked off the event
        // dispatch thread (since it locks both the component and then the
        // component's class; the event thread is likely to want to lock the
        // component and may have already locked the class (prior to 1.4).
        String name = comp.getName();
        // Pretend auto-generated names don't exist.
        if (name != null 
            && (name.startsWith("null.")
                || isDefaultName(comp, name))) {
            name = null;
        }
        return name;
    }

    /** Return whether the name is a default generated name. */
    private boolean isDefaultName(Component c, String name) {
        if (c instanceof JComponent)
            return false;

        return (c instanceof Button && Regexp.stringMatch("button[0-9]+", name))
            || (c instanceof Canvas && Regexp.stringMatch("canvas[0-9]+", name))
            || (c instanceof Checkbox && Regexp.stringMatch("checkbox[0-9]+", name))
            || (c instanceof Choice && Regexp.stringMatch("choice[0-9]+", name))
            || (c instanceof Dialog && Regexp.stringMatch("dialog[0-9]+", name))
            || (c instanceof FileDialog && Regexp.stringMatch("filedlg[0-9]+", name))
            || (c instanceof Frame && Regexp.stringMatch("frame[0-9]+", name))
            || (c instanceof List && Regexp.stringMatch("list[0-9]+", name))
            || (c instanceof Label && Regexp.stringMatch("label[0-9]+", name))
            || (c instanceof Panel && Regexp.stringMatch("panel[0-9]+", name))
            || (c instanceof Scrollbar && Regexp.stringMatch("scrollbar[0-9]+", name))
            || (c instanceof ScrollPane && Regexp.stringMatch("scrollpane[0-9]+", name))
            || (c instanceof TextArea && Regexp.stringMatch("text[0-9]+", name))
            || (c instanceof TextField && Regexp.stringMatch("textfield[0-9]+", name))
            || (c instanceof Window && Regexp.stringMatch("win[0-9]+", name));
    }

    /** Return all windows owned by the given window (filtered). */
    private List getWindowList(Window parent) {
        return getWindowList(parent, filter, false);
    }

    /** Return all windows owned by the given window, optionally filtered. */
    private List getWindowList(Window parent, boolean filter, boolean recurse){
        Window[] windows = parent.getOwnedWindows();
        ArrayList list = new ArrayList();
        for (int i=0;i < windows.length;i++) {
            if (!filter || !isComponentFiltered(windows[i])) {
                list.add(windows[i]);
                if (recurse) {
                    list.addAll(getWindowList(windows[i], filter, recurse));
                }
            }
        }
        return list;
    }

    /** Return an array of all available Frames, across all known contexts.
    */ 
    public Window[] getRootWindows() {
        ArrayList unf = new ArrayList();
        Iterator iter = tracker.getRootWindows().iterator();
        while (iter.hasNext()) {
            Window win = (Window)iter.next();
            if (!isComponentFiltered(win))
                unf.add(win);
        }
        Log.debug("Have " + unf.size() + " root windows");
        return (Window[])unf.toArray(new Window[unf.size()]);
    }

    /** Return all windows owned by the given window that have not been
     * filtered.
     */ 
    public Window[] getWindows(Window parent) {
        List list = getWindowList(parent, filter, false);
        return (Window[])list.toArray(new Window[list.size()]);
    }

    /** Return all known unfiltered windows. */
    private List getWindowList() {
        Iterator iter = tracker.getRootWindows().iterator();
        ArrayList list = new ArrayList();
        while(iter.hasNext()) {
            Window root = (Window)iter.next();
            if (!filter || !isComponentFiltered(root)) {
                list.add(root);
                list.addAll(getWindowList(root, filter, true));
            }
        }
        return list;
    }

    /** Returns the set of all available windows that have not been
     * filtered.  This includes frames and windows.
     */ 
    public Window[] getWindows() {
        List list = getWindowList();
        return (Window[])list.toArray(new Window[list.size()]);
    }

    /** Returns all components below the GUI hierarchy of the given Container,
     * including Windows and MenuElements.
     */ 
    public Component[] getComponents(Container c) {
        Component[] children = c.getComponents();
        ArrayList unf = new ArrayList();
        for (int i=0;i < children.length;i++) {
            if (!isComponentFiltered(children[i]))
                unf.add(children[i]);
        }
        if (c instanceof javax.swing.JMenu) {
            MenuElement[] els = ((javax.swing.JMenu)c).getSubElements();
            for (int i=0;i < els.length;i++) {
                if (!isComponentFiltered(els[i].getComponent()))
                    unf.add(els[i].getComponent());
            }
        }
        if (c instanceof Window) {
            unf.addAll(getWindowList((Window)c));
        }
        children = (Component[])unf.toArray(new Component[unf.size()]);
        return children;
    }

    /** Look up the apparent parent of a component.  A
     * popup menu's parent is the menu or component that spawned it.
     */
    public Component getComponentParent(Component comp) {
        Component parent = comp.getParent();
        // A popup menu's "parent" is its invoker
        if (comp instanceof JPopupMenu) {
            parent = ((JPopupMenu)comp).getInvoker();
        }
        return parent;
    }

    /** Return the component's owning frame.   There will
     * <b>always</b> one of these; even a frameless window will have a
     * temporary frame generated for it.
     */
    public Frame getComponentFrame(Component comp) {
        Component parent = comp;
        while (!(parent instanceof Frame) 
               && (comp = getComponentParent(parent)) != null) {
            parent = comp;
        }
        return (Frame)comp;
    }

    /** Return the nearest Window ancestor of the given Component.
        If the component is a Window, returns the component.
        Note that for popups, this means the window of the invoker.
     */
    public Window getComponentWindow(Component comp) {
        Component parent = comp;
        while (!(parent instanceof Window) 
               && (comp = getComponentParent(parent)) != null) {
            parent = comp;
        }
        return (Window)comp;
    }

    /** 
     * Return the title of the nearest ancestor window with a title.  
     * If no title is found, return null.
     */
    public String getComponentWindowTitle(Component comp) {
        Window w = getComponentTitledWindow(comp);
        String title = null;
        if (w instanceof Frame) {
            title = ((Frame)w).getTitle();
        }
        else if (w instanceof Dialog) {
            title = ((Dialog)w).getTitle();
        }
        return title;
    }

    /** Return the component's owning frame or dialog.   There will
     * <b>always</b> one of these; even a frameless window will have a
     * temporary frame generated for it.
     */
    public Window getComponentTitledWindow(Component comp) {
        Component parent = comp;
        while (!(comp instanceof Frame || comp instanceof Dialog)
               && (comp = getComponentParent(parent)) != null) {
            parent = comp;
        }
        return (comp instanceof Frame || comp instanceof Dialog) 
            ? (Window)comp : null;
    }

    private boolean isComponentFiltered(Component comp) {
        if (comp == null)
            return false;
        return filter 
            && (filteredComponents.containsKey(comp)
                || (!trackAppletConsole
                    && "sun.plugin.ConsoleWindow".
                    equals(comp.getClass().getName()))
                || (parent != null && parent.isFiltered(comp)));
    }

    /** Returns whether any window or frame ancestor is filtered. */
    private boolean isAncestorFiltered(Component comp) {
        Window w = getComponentWindow(comp);
        if (w == comp) {
            w = (Window)getComponentParent(w);
        }
        return isFiltered(w);
    }

    /** Returns true if the component or its Window ancestor is filtered. */
    public boolean isFiltered(Component comp) {
        return (comp != null)
            && (isComponentFiltered(comp) || isAncestorFiltered(comp));
    }

    private boolean isSharedInvisibleFrame(Component comp) {
        return comp.getClass().getName().startsWith("javax.swing.SwingUtilities");
    }

    public void filterComponent(Component comp) {
        if (isSharedInvisibleFrame(comp)) {
            // If the component is Swing's parent for windows and dialog with
            // a null parent, don't filter it, but do filter its children.  
            Component[] children = getComponents((Container)comp);
            for (int i=0;i < children.length;i++) {
                filterComponent(children[i]);
            }
        }
        else {
            Log.debug("Now filtering " + Robot.toString(comp));
            filteredComponents.put(comp, comp);
        }
    }

    /** Ignore (for the purpose of future lookup) the given component. */
    public void ignoreComponent(Component comp) {
        filterComponent(comp);
        if (parent != null) {
            parent.ignoreComponent(comp);
        }
    }

    /** Ignore (for the purposes of future lookup) all currently available
     * components.
     */ 
    public void ignoreExistingComponents() {
        Iterator iter = getWindowList().iterator();
        while(iter.hasNext()) {
            ignoreComponent((Window)iter.next());
        }
    }

    public void setFilterEnabled(boolean enable) {
        this.filter = enable;
    }

    /** Send an explicit window close event to all showing windows.  Note
        that this is not guaranteed to actually make the window go away.  */
    public void closeWindows() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Iterator iter = getWindowList().iterator();
                while (iter.hasNext()) {
                    Window win = (Window)iter.next();
                    if (win.isShowing()) {
                        WindowEvent ev = 
                            new WindowEvent(win, WindowEvent.WINDOW_CLOSING);
                        win.getToolkit().getSystemEventQueue().postEvent(ev);
                    }
                }
            }
        });
    }

    /** Dispose of all available windows, and does not return until they have
        been disposed of.  */
    public void disposeWindows() {
        // This must be done on the swing thread, since disposing of a window
        // may trigger more gui events and/or locking the tree, and we want to
        // wait until it all gets done.
        Window[] windows = getWindows();
        for (int i=0;i < windows.length;i++) {
            final Window win = windows[i];
            ignoreComponent(win);
            // HACK to distinguish between the abbot framework
            // disposing a window and anyone else (AppletViewer, for
            // instance). 
            // FIXME maybe use ThreadLocal instead of a property
            System.setProperty("abbot.finder.disposal", "true");
            try {
                if (!isSharedInvisibleFrame(win)) {
                    Log.debug("Disposing of " + Robot.toString(win));
                    win.dispose();
                }
            }
            catch(NullPointerException npe) {
                // Catch bug in AWT 1.3.1 when generating hierarchy
                // events 
                Log.log(npe);
            }
            System.setProperty("abbot.finder.disposal", "false");
        }
    }

    /** Indicates whether the given component is showing and ready for
        input. */
    public boolean isShowing(Component c) {
        Window w = getComponentWindow(c);
        return c.isShowing() && ((w == null) || tracker.isWindowReady(w));
    }
}
