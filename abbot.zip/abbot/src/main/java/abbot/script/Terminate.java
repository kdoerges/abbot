package abbot.script;

import java.util.Map;

import abbot.Resolver;
import abbot.i18n.Strings;


/** Placeholder step to indicate to a script that it should terminate.
    Doesn't actually do anything itself.
 */

public class Terminate extends Step {

    private static final String USAGE = "<terminate/>";

    public Terminate(Resolver resolver, Map attributes) throws InvalidScriptException {
        super(resolver, attributes);
    }

    public Terminate(Resolver resolver, String description) {
        super(resolver, description);
    }

    @Override
    public void runStep() {
        // does nothing
    }

    @Override
    protected String getDefaultDescription() {
        return Strings.get("Terminate");
    }

    @Override
    public String getUsage() {
        return USAGE;
    }

    @Override
    public String getXMLTag() {
        return TAG_TERMINATE;
    }
}
