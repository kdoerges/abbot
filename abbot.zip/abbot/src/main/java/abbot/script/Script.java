package abbot.script;

import java.awt.Component;
import java.io.*;
import java.net.URL;
import java.util.*;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import testframework.testrunner.RTVariablesSingleton;
import testframework.testrunner.variables.PseudoVarUtil;
import abbot.Log;
import abbot.Resolver;
import abbot.i18n.Strings;
import abbot.script.parsers.FileParser;
import abbot.script.parsers.Parser;
import abbot.tester.Robot;
import abbot.util.Properties;

import com.obi.test.tregs.abbot.component.AbbotProperties;

import extensions.system.AbbotService;


/**
 * Provide a structure to encapsulate actions invoked on GUI components and
 * tests performed on those components.  Scripts need to be short and concise
 * (and therefore easy to read/write). Extensions don't have to be.<p> 
 * This takes a single filename as a constructor argument.<p>
 * Use
 * <a href="{@docRoot}/junit/extensions/abbot/ScriptTestCase.html">ScriptTestCase</a>
 * and
 * </a href="{@docRoot}/junit/extensions/abbot/ScriptTestSuite.html">ScriptTestSuite</a>
 * to generate a suite (auto-generate the collection).<p>  
 */

public class Script extends Sequence implements Resolver {

    private static final String USAGE = "<AWTTestScript [desc=\"\"] [forked=\"true\"] [slow=\"true\"]"
                                        + " [vmargs=\"...\"]>...</AWTTestScript>\n";

    /** Robot delay for slow playback.  */
    private static int slowDelay = 250;

    static boolean validate = true;

    private String filename;

    private File relativeDirectory = null;

    private boolean loaded = false;

    private boolean fork = false;

    private boolean slow = false;

    private int lastSaved = 0;

    private String vmargs = null;

    private final Map<String, String> properties = new HashMap<String, String>();

    static {
        slowDelay = Properties.getProperty("abbot.script.slow_delay", 0, 60000, slowDelay);
        validate = "true".equals(System.getProperty("abbot.script.validate", "true"));
    }

    private static Map<String, String> createDefaultMap(String filename) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(TAG_FILENAME, filename);
        return map;
    }

    /** Create a new, empty script.  Used as a temporary resolver. */
    public Script() {
        this(null, new HashMap<String, String>());
    }

    /** Create a script.  Actual reading of the script is deferred. */
    public Script(String filename) {
        this(null, createDefaultMap(filename));
    }

    public Script(Resolver parent, Map<String, String> attributes) {
        super(parent, attributes);
        String tFilename = attributes.get(TAG_FILENAME);
        File file =
                tFilename != null ? new File(tFilename) : getTempFile(parent != null ? parent.getDirectory() : null);
        setFile(file);
        if (parent != null) {
            setRelativeTo(parent.getDirectory());
        }
    }

    private File getTempFile(File dir) {
        File file;
        try {
            file = (dir != null ? File.createTempFile("script", ".xml", dir) : File.createTempFile("script", ".xml"));
        } catch (IOException io) {
            file = (dir != null ? new File(dir, "tmpscript.xml") : new File("tmpscript.xml"));
        }
        file.deleteOnExit();
        return file;
    }

    public String getName() {
        return filename;
    }

    public void setForked(boolean fork) {
        this.fork = fork;
    }

    public boolean isForked() {
        return fork;
    }

    public void setVMArgs(String args) {
        if (args != null && "".equals(args)) args = null;
        vmargs = args;
    }

    public String getVMArgs() {
        return vmargs;
    }

    public boolean isSlowPlayback() {
        return slow;
    }

    public void setSlowPlayback(boolean slow) {
        this.slow = slow;
    }

    /** Return the file where this script is saved.  Will always be an
     * absolute path.
     */
    public File getFile() {

        // abbot_ext_begin
        int index = filename.indexOf("PROCEDURES");
        if (index != -1) {
            String procedurePath = RTVariablesSingleton.theInstance().getVariable("PROCEDURES");
            if (procedurePath != null) {

                String fileName2 = filename.substring(index);
                fileName2 =
                        fileName2.replaceFirst("PROCEDURES",
                                               RTVariablesSingleton.theInstance().getVariable("PROCEDURES"));

                File fileVar = new File(fileName2);
                return fileVar;
            }
        }

        // abbot_ext_end

        File file = new File(filename);
        if (!file.isAbsolute()) {
            String path = getRelativeTo().getPath() + File.separator + filename;
            file = new File(path);
        }
        return file;
    }

    /** Warning: if the directory is changed, need to change associated files
    	as well.
    */
    public void setFile(File file) {
        Log.debug("Script file set to " + file);
        if (file == null) throw new IllegalArgumentException("File must not be null");
        if (filename == null || !file.equals(getFile())) {
            filename = file.getPath();
            Log.debug("Script filename set to " + filename);
            if (relativeDirectory != null) setRelativeTo(relativeDirectory);
            loaded = false;
        }
    }


    /* abbot_ext begin */
    // Aus 0.12.3 �bernommen
    /** Change the file system basis for the current script.  Does not affect
    	the script contents.
    */
    public void changeFile(File file) {
        setFile(file);
        lastSaved = getHash() + 1;
        loaded = true;
    }

    /**
     * Gibt zur�ck, ob das Skript geladen wurde
     * @return boolean 
     */
    public boolean isLoaded() {
        return loaded;
    }

    /* abbot_ext end */

    /** Typical xml header, so we can know about how much file prefix to
     * skip.
     */
    private static final String XML_INFO = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";

    /** Flag to indicate whether emitted XML should contain the script
    	contents.  Sometimes we just want a one-liner (like when displaying in
    	the script editor), and sometimes we want the full contents (when
    	writing to file).
    */
    private boolean exportAllData = false;

    /** Write the current state of the script to file. */
    public void save(Writer writer) throws IOException {
        exportAllData = true;
        Element el = toXML();
        exportAllData = false;
        el.setName(TAG_AWTTESTSCRIPT);
        // Filename doesn't need to be saved
        el.removeAttribute(TAG_FILENAME);

        Document doc = new Document(el);
        //abbot_ext_begin
        // ge�ndert f�r jdom 1.1.1
        Format tempFormat = Format.getPrettyFormat();
        XMLOutputter outputter = new XMLOutputter(tempFormat);
        //abbot_ext_end
        outputter.output(doc, writer);
    }

    /**
     * Liefert dieses Skript als String XML Repr�sentation
     * @return String
     * @throws IOException
     */
    public String asString() throws IOException {
        exportAllData = true;
        Element el = toXML();
        exportAllData = false;
        el.setName(TAG_AWTTESTSCRIPT);
        // Filename doesn't need to be saved
        el.removeAttribute(TAG_FILENAME);

        Document doc = new Document(el);
        //abbot_ext_begin
        // ge�ndert f�r jdom 1.1.1
        Format tempFormat = Format.getPrettyFormat();
        XMLOutputter outputter = new XMLOutputter(tempFormat);
        //abbot_ext_end
        ByteArrayOutputStream tBAOS = new ByteArrayOutputStream();
        outputter.output(doc, tBAOS);

        return tBAOS.toString();
    }

    /** Only thing directly editable on a script is its file path. */
    @Override
    public String toEditableString() {
        return getFilename();
    }

    /** Has this script changed since the last save. */
    public boolean isDirty() {
        return getHash() != lastSaved;
    }

    /** Write the script to file.  Note that this differs from the toXML for
    	the script, which simply indicates the file on which it is based. */
    public void save() throws IOException {

        /* abbot_ext begin */
        /* work-around f�r Speicherproblem von Undo-Funktion i.V.m. Unterskripten:
           wenn Undo-Funktion aktiviert, dann IOException in Console anzeigen
        */
        try {

            File file = getFile();
            Log.debug("Saving script to '" + file + "' " + hashCode());
            OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
            save(new BufferedWriter(writer));
            writer.close();
            lastSaved = getHash();

        } catch (IOException e) {

            System.err.println(e.getMessage());
        }
    };

    /* abbot_ext end */


    /** Ensure that all referenced components are actually in the components
     * list.
     */
    private void verify() throws InvalidScriptException {
        Iterator<ComponentReference> iter = refs.values().iterator();
        while (iter.hasNext()) {
            ComponentReference ref = iter.next();
            if (ref.getAttribute(TAG_PARENT) != null && ref.getParentReference() == null) {
                String msg = Strings.get("ParentMissing", new Object[] {ref.getAttribute(TAG_PARENT)});
                throw new InvalidScriptException(msg);
            }
            if (ref.getAttribute(TAG_WINDOW) != null && ref.getWindowReference() == null) {
                String msg = Strings.get("WindowMissing", new Object[] {ref.getAttribute(TAG_WINDOW)});

                // Wo tritt das eigentlich auf?
                msg = msg + " in Script: " + filename;

                throw new InvalidScriptException(msg);
            }
        }
    }

    /** Make the path to the given child script relative to this one. */
    private void updateRelativePath(Step child) {
        // Make sure included scripts are located relative to this one
        if (child instanceof Script) {
            ((Script)child).setRelativeTo(getDirectory());
        }
    }

    @Override
    protected void parseChild(Element el) throws InvalidScriptException {
        if (el.getName().equals(TAG_COMPONENT)) {
            addComponentReference(el);
        } else {
            synchronized (steps()) {
                super.parseChild(el);
                updateRelativePath(steps().get(size() - 1));
            }
        }
    }

    /** Loads the XML test script.  Performs a check against the XML schema.
    	@param reader Provides the script data
    	@throws InvalidScriptException
    	@throws IOException
     */
    public void load(Reader reader) throws InvalidScriptException, IOException {
        clear();
        try {
            // Set things up to optionally validate on load

            //abbot_ext_begin
            // F�r Java6
            /* Wir ziehen derzeit JDOM 1.x hier ist der Aufruf des Konstruktors okay 
             * Ab JDOM 2.x ist das ganze deprecated. Der Aufruf ist wie folgt zu �ndern
             * deprecated.=> use SAXBuilder(XMLReaderJDOMFactory) with either XMLReaders.DTDVALIDATING or XMLReaders.NONVALIDATING 
             */
            SAXBuilder builder = new SAXBuilder(validate);
            //abbot_ext_end

            if (validate) {
                builder.setFeature("http://apache.org/xml/features/validation/schema", true);
                URL url = getClass().getClassLoader().getResource("abbot/abbot.xsd");
                builder.setProperty("http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation",
                                    url.toString());

            }
            Document doc = builder.build(reader);
            Element root = doc.getRootElement();
            Map<String, String> map = createAttributeMap(root);
            parseStepAttributes(map);
            fork = Boolean.valueOf(map.get(TAG_FORKED)).booleanValue();
            slow = Boolean.valueOf(map.get(TAG_SLOW)).booleanValue();
            vmargs = map.get(TAG_VMARGS);
            parseChildren(root);
        } catch (JDOMException e) {
            throw new InvalidScriptException(e.getMessage() + "\nfilename: " + filename);
        }
        // Make sure we have all referenced components
        synchronized (refs) {
            verify();
        }
    }

    private void loadNoThrow() {
        try {
            load();
        } catch (Throwable e) {
            setScriptError(e);
        }
    }

    @Override
    public int size() {
        loadNoThrow();
        return super.size();
    }

    @Override
    public java.util.List<Step> steps() {
        loadNoThrow();
        return super.steps();
    }

    @Override
    public int indexOf(Step step) {
        loadNoThrow();
        return super.indexOf(step);
    }

    @Override
    public Step getStep(int index) {
        loadNoThrow();
        return super.getStep(index);
    }

    @Override
    public void addStep(int index, Step step) {
        loadNoThrow();
        super.addStep(index, step);
        updateRelativePath(step);
    }

    @Override
    public void addStep(Step step) {
        loadNoThrow();
        super.addStep(step);
        updateRelativePath(step);
    }

    /** Replaces the step at the given index. */
    @Override
    public void setStep(int index, Step step) {
        loadNoThrow();
        super.setStep(index, step);
        updateRelativePath(step);
    }

    @Override
    public void removeStep(Step step) {
        loadNoThrow();
        super.removeStep(step);
    }

    @Override
    public void removeStep(int index) {
        loadNoThrow();
        super.removeStep(index);
    }

    /** Parse the script file and build internal structures. */
    public void load() throws InvalidScriptException, IOException {
        if (!loaded) {
            File file = getFile();
            Log.debug("Loading script " + file + " (" + hashCode() + ")");
            loaded = true;
            if (!file.exists()) {

                /* abbot_ext begin */
                // auch relative Dateinamen zum Classpath werden unterst�tzt
                AbbotService.loadScript(this);
                // String msg = "The script '" + getFilename()
                // 	+ "' does not exist at the expected location '"
                //	+ file.getAbsolutePath() + "'";
                //	throw new InvalidScriptException(msg);
                /* abbot_ext end */

            } else if (file.length() != 0) {
                InputStreamReader reader = new InputStreamReader(new FileInputStream(file), "UTF-8");
                try {
                    load(new BufferedReader(reader));
                } catch (InvalidScriptException e) {
                    loaded = false;
                    throw e;
                } catch (IOException io) {
                    loaded = false;
                    throw io;
                } finally {
                    reader.close();
                }
            }
            lastSaved = getHash();

            /* abbot_ext_begin */
            // evtl. zugeh�rige Properties (d.h. Variablenbelegungen) laden
            // Herausgenommen, da dies nicht automatisch erfolgen sollte
            // Entsprechenden Men�punkt im ScriptEditor eingebaut
            // AbbotService.loadProperties(this);
            /* abbot_ext_end */

        }
    }

    private int getHash() {
        try {
            exportAllData = true;
            return toXMLString(this).hashCode();
        } finally {
            exportAllData = false;
        }
    }

    @Override
    public String getXMLTag() {
        return TAG_SCRIPT;
    }

    /** Save component references in addition to everything else. */
    @Override
    public Element addContent(Element el) {
        // Only save content if writing to disk
        if (exportAllData) {
            synchronized (refs) {
                Iterator<ComponentReference> iter = refs.values().iterator();
                while (iter.hasNext()) {
                    ComponentReference cref = iter.next();
                    el.addContent(cref.toXML());
                }
            }
            // Now collect our child steps
            return super.addContent(el);
        }
        return el;
    }

    /** Return the (possibly relative) path to this script. */
    public String getFilename() {
        return filename;
    }

    /** Provide XML attributes for this Step.  This class adds its filename. */
    @Override
    public Map<String, String> getAttributes() {
        Map<String, String> map = exportAllData ? super.getAttributes() : new TreeMap<String, String>();
        map.put(TAG_FILENAME, getFilename());

        if (exportAllData) {
            // default is no fork
            if (fork) {
                map.put(TAG_FORKED, "true");
                if (vmargs != null) {
                    map.put(TAG_VMARGS, vmargs);
                }
            }
            if (slow) {
                map.put(TAG_SLOW, "true");
            }
        }
        return map;
    }

    @Override
    protected void runStep(StepRunner runner) throws Throwable {
        properties.clear();
        load();
        // Make all files relative to this script
        Parser fc = new FileParser() {

            @Override
            public String relativeTo() {
                Log.debug("All file references will be relative to " + getDirectory().getAbsolutePath());
                return getDirectory().getAbsolutePath();
            }
        };
        Parser oldfc = ArgumentParser.setParser(File.class, fc);
        int old = Robot.getAutoDelay();
        if (slow) {
            Robot.setAutoDelay(slowDelay);
        }
        try {
            super.runStep(runner);
        } finally {
            Robot.setAutoDelay(old);
            ArgumentParser.setParser(File.class, oldfc);
        }
    }

    /** Return a unique reference ID. */
    @Override
    public String getUniqueID(ComponentReference ref) {
        // Use the component's name, if available
        String id = ref.getID();
        String cname = ref.getRefClassName();
        cname = cname.substring(cname.lastIndexOf(".") + 1);
        if (id == null) {
            // Don't ever use an empty string for the ID
            if (ref.getAttribute(TAG_NAME) != null && !"".equals(ref.getAttribute(TAG_NAME))) {
                id = ref.getAttribute(TAG_NAME);
            } else if (ref.getAttribute(TAG_TAG) != null && !"".equals(ref.getAttribute(TAG_TAG))) {
                id = ref.getAttribute(TAG_TAG);
            } else {
                id = cname + " Instance";
            }
        }

        String ext = "";
        int count = 2;
        while (refs.get(id + ext) != null) {
            ext = " " + count++;
        }
        return id + ext;
    }

    /** Set up a blank script, discarding any current state. */
    @Override
    public void clear() {
        loadNoThrow();
        synchronized (refs) {
            refs.clear();
            components.clear();
        }
        super.clear();
    }

    @Override
    public String getUsage() {
        return USAGE;
    }

    @Override
    public String getDescription() {
        // If there's a description in the file itself, make sure we read it
        loadNoThrow();
        return super.getDescription();
    }

    @Override
    protected String getDefaultDescription() {
        return toString();
    }

    @Override
    public String toString() {
        String ext = fork ? " &" : "";

        return Strings.get("ScriptDesc", new Object[] {getFilename(), ext});
    }

    public boolean hasLaunch() {
        return size() > 0 && ((steps().get(0)) instanceof Launch);
    }

    public boolean hasTerminate() {
        return size() > 0 && ((steps().get(size() - 1)) instanceof Terminate);
    }

    /** By default, all pathnames are relative to the current working
    	directory.
    */
    public File getRelativeTo() {
        if (relativeDirectory == null) return new File(System.getProperty("user.dir"));
        return relativeDirectory;
    }

    /** Indicate that when invoking toXML, a path relative to the given one
     * should be shown.  Note that this is a runtime setting only and never
     * shows up in saved XML.
     */
    public void setRelativeTo(File dir) {
        Log.debug("Want relative dir " + dir);
        relativeDirectory = dir;
        if (dir != null) {
            // FIXME ideally, we'd want a more robust "make relative" here.
            // for now, simply check to see if the relpath is a prefix.
            // or if the file itself is relative
            String relPath = dir.getPath();
            if (filename.startsWith(relPath)) {
                char ch = filename.charAt(relPath.length());
                if (ch == '/' || ch == '\\') {
                    filename = filename.substring(relPath.length() + 1);
                }
            }
        }
        Log.debug("Relative dir set to " + relativeDirectory + " for " + this);
    }

    /** Return whether the given file looks like a valid AWT script. */
    public static boolean isScript(File file) {
        if (file.length() == 0) return true;
        if (!file.exists() || !file.isFile() || file.length() < TAG_AWTTESTSCRIPT.length() * 2 + 5) return false;
        FileInputStream is = null;
        try {
            int len = XML_INFO.length() + TAG_AWTTESTSCRIPT.length() + 15;
            is = new FileInputStream(file);
            byte[] buf = new byte[len];
            is.read(buf, 0, buf.length);
            String str = new String(buf, 0, buf.length);
            return str.indexOf(TAG_AWTTESTSCRIPT) != -1;
        } catch (Exception exc) {
            return false;
        } finally {
            if (is != null) try {
                is.close();
            } catch (Exception exc) {}
        }
    }

    // NOTE: it may make sense to make the launch part of the script itself,
    // as well as the class loading context.
    public Launch getLaunchStep() {
        synchronized (steps()) {
            if (hasLaunch()) {
                return (Launch)steps().get(0);
            }
        }
        return null;
    }

    /** Maps a short mnemonic into a ComponentReference. */
    private final Map<String, ComponentReference> refs = new TreeMap<String, ComponentReference>();

    /** Maps actual components into ComponentReferences.  This speeds up
     * lookup when attempting to match a component to an existing reference.
     */
    private final WeakHashMap<Component, ComponentReference> components =
            new WeakHashMap<Component, ComponentReference>();

    /** All relative files should be accessed relative to this directory,
    	which is the directory where the script resides.
    	It will always return an absolute path.
    */
    @Override
    public File getDirectory() {
        return getFile().getParentFile();
    }

    @Override
    public Collection<ComponentReference> getComponentReferences() {
        synchronized (refs) {
            return Collections.unmodifiableCollection(refs.values());
        }
    }

    @Override
    public void addComponentReference(ComponentReference ref) {
        synchronized (refs) {
            refs.put(ref.getID(), ref);
        }
    }

    /** Add a new component reference for the given component. */
    @Override
    public ComponentReference addComponent(Component comp) {
        // See if we've already got it
        synchronized (refs) {
            ComponentReference ref = findExistingReference(comp);
            if (ref == null) {
                // Nope, create a new one
                /*Log.debug("Component " + Robot.toString(comp)
                  + " not yet referenced, adding it");*/
                ref = new ComponentReference(this, comp);
                refs.put(ref.getID(), ref);
                components.put(comp, ref);
                if (ref.getID().equals("")) {
                    Log.warn("Reference id is empty: " + ref);
                }
            } else {
                /*Log.debug("Component " + Robot.toString(comp)
                  + " already referenced, using " + ref);*/
            }
            return ref;
        }
    }

    /** Add a new component reference to the script.  For use only when
     * parsing a script.
     */
    ComponentReference addComponentReference(Element el) throws InvalidScriptException {
        synchronized (refs) {
            ComponentReference ref = new ComponentReference(this, el);
            refs.put(ref.getID(), ref);
            return ref;
        }
    }

    /** Return the reference for the given component, or null if none yet
     * exists. 
     */
    @Override
    public ComponentReference getComponentReference(Component comp) {
        return findExistingReference(comp);
    }

    /** Return the reference for the given component, or null if none yet
     * exists. 
     */
    private ComponentReference findExistingReference(Component comp) {
        synchronized (refs) {
            ComponentReference match = components.get(comp);
            if (match == null && refs.values().size() > 0) {
                // String className = comp.getClass().getName();

                //				if (className.startsWith("de.gebit.trend")) {
                //					match = ComponentReference.matchExisting(comp, refs.values());
                //				}
                //				else {
                //				match = ComponentReference.matchExisting(comp, refs.values());
                //				}

                boolean fastRecording;


                fastRecording = AbbotProperties.theInstance().getFastRecording();


                if (fastRecording) {
                    match = ComponentReference.quickMatchExisting(comp, refs.values(), this);
                } else {
                    match = ComponentReference.matchExisting(comp, refs.values());
                }

                if (match != null) {
                    Log.debug("Cacheing component match");
                    //					System.out.println("Referenz gefunden: " + match.getID());
                    components.put(comp, match);
                } else {
                    //					System.out.println("Referenz noch nicht vorhanden: " + comp.getName());

                }
            }
            return match;
        }
    }

    /** Convert the given reference ID into a component reference.  If it's
     * not in the Script's list, throw an appropriate exception.
     */
    @Override
    public ComponentReference getComponentReference(String name) {
        synchronized (refs) {
            Log.debug("Looking for reference with id '" + name + "' among " + refs.size() + " references");
            return refs.get(name);
        }
    }

    @Override
    public void setProperty(String name, String value) {
        if (value == null)
            properties.remove(name);
        else {
            /* abbot_ext_begin */
            properties.put(name, value);

            // TODO Pothmann, 29.01.08 -> ist das so ok? kann zu interdependenzen f�hren ..
            RTVariablesSingleton.theInstance().setVariable(name, value);
        }
        /* abbot_ext_end */

    }


    /* abbot_ext_begin */

    public Map<String, String> getProperties() {
        return properties;
    }


    /* abbot_ext_end */


    /* abbot_ext_begin */
    @Override
    public String getProperty(String name) {

        if (PseudoVarUtil.isPseudoVariable(name)) {
            return PseudoVarUtil.getPseudoVarValue(name, false);
        }

        String propertyValue = properties.get(name);

        if (propertyValue == null) {
            /* Pr�fe, ob die Variable in AbbotExchange vorhanden ist */

            propertyValue = RTVariablesSingleton.theInstance().getVariable(name);
            if (propertyValue == null) {

                String message = "Undefined property: " + name;
                System.out.println(message);
                return null;
            } else {
                return propertyValue;
            }

        }
        if (propertyValue.startsWith("$")) {
            propertyValue = propertyValue.substring(1);
            return PseudoVarUtil.getPseudoVarValue(propertyValue, false);

        } else {
            return propertyValue;
        }
    }

    /* abbot_ext_end */


    /* abbot_ext begin */

    public void removeComponentReference(ComponentReference ref) {
        synchronized (refs) {
            refs.remove(ref.getID());
        }
    }


    public Terminate getTerminateStep() {
        synchronized (steps()) {
            if (hasTerminate()) {
                return (Terminate)steps().get(size() - 1);
            }
        }
        return null;
    }

    /* abbot_ext end */


}
