package abbot.script.parsers;

/** This interface provides a method for converting a String into some
 * destination class type.  This interface was designed as an extensible
 * method of converting Strings into arbitrary target classes when parsing
 * scripted arguments to methods.  When a script is run and a method is
 * resolved, the String arguments are converted to the classes required for
 * the method invocation.  Built-in conversions are provided for component
 * references and all the basic types, including arrays. You might, for
 * instance, write a Parser that takes some ID code and converts it to some
 * data internal to your application.
 */
public interface Parser {
    Object parse(String string) throws IllegalArgumentException;
}
