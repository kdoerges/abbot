package abbot.script.parsers;

import javax.swing.tree.TreePath;

import abbot.script.ArgumentParser;

/** Convert a String into a TreePath.  */
public class TreePathParser implements Parser {

    /** The string representation of a TreePath is what is usually generated
        by its toString method, e.g.
        <p>
        [root, parent, child]
        <p>
        Nodes which contain a comma need to have that comma preceded by a
        backslash to avoid it being interpreted as two separate nodes.
    */
    public Object parse(String input) throws IllegalArgumentException {
        if (!(input.startsWith("[") && input.endsWith("]"))) 
            throw new IllegalArgumentException("TreePath must be bounded by square brackets");
        input = input.substring(1, input.length()-1);
        // Use our existing utility for parsing a comma-separated list
        String[] nodeNames = ArgumentParser.parseArgumentList(input);
        // Strip off leading space, if there is one
        for (int i=0;i < nodeNames.length;i++) {
            if (nodeNames[i].startsWith(" "))
                nodeNames[i] = nodeNames[i].substring(1);
        }
        TreePath path = new TreePath(nodeNames);
        return path;
    }
}
