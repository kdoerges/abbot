package abbot.script;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.swing.SwingUtilities;

import abbot.AssertionFailedError;
import abbot.DefaultComponentFinder;
import abbot.ExitException;
import abbot.Log;
import abbot.NoExitSecurityManager;
import abbot.i18n.Strings;
import abbot.util.EDTExceptionCatcher;


public class StepRunner {

    private boolean stopOnFailure = true;

    private boolean stopOnError = true;

    /** Whether to terminate the app after an error/failure. */
    private boolean terminateOnError = true;

    /** Whether to terminate the app after stopping. */
    private transient boolean terminateOnStop = false;

    private final ArrayList<StepListener> listeners = new ArrayList<StepListener>();

    private final Map<Step, Throwable> errors = new HashMap<Step, Throwable>();

    private Launch launchStep = null;

    /** Whether to stop running. */
    private transient boolean stop = false;

    private EDTExceptionCatcher catcher;

    /** Provides control and tracking of the execution of a step or series of
    	steps.  By default the runner stops execution on the first encountered
    	failure/error.  The running environment is preserved to the extent
    	possible, which includes discarding any GUI components created by the
    	code under test.<p>
    	If you wish to preserve the application state when there is an error,
    	you can use the method <code>setTerminateOnError(false)</code>.
    */
    public StepRunner() {
        // Assume any existing windows are part of some running framework, and
        // ensure the script ignores them.
        DefaultComponentFinder.getFinder().ignoreExistingComponents();

        this.catcher = new EDTExceptionCatcher();
        catcher.install();
    }

    public void setStopOnFailure(boolean stop) {
        stopOnFailure = stop;
    }

    public void setStopOnError(boolean stop) {
        stopOnError = stop;
    }

    public boolean getStopOnFailure() {
        return stopOnFailure;
    }

    public boolean getStopOnError() {
        return stopOnError;
    }

    /** Stop execution of the script after the current step completes.  The
     * launched application will be left in its current state.
     */
    public void stop() {
        stop(false);
    }

    /** Stop execution, indicating whether to terminate the app. */
    public void stop(boolean terminate) {
        stop = true;
        terminateOnStop = terminate;
    }

    /** Return whether the runner has been stopped. */
    public boolean stopped() {
        return stop;
    }

    private boolean isSetUp = false;

    private SecurityManager oldsm = null;

    private boolean installed = false;

    private Properties oldProps = null;

    private PrintStream oldOut = null;

    private PrintStream oldErr = null;

    /** Set up an appropriate environment for launching an app under test.
    	This includes the following:
    	<ul>
    	<li>Preserve System.out/err.
    	<li>Save the current System properties.
    	<li>Install a security manager to prevent the AUT from exiting.
    	</ul>
     */
    protected synchronized void setUp() {
        if (isSetUp) {
            throw new IllegalStateException("tearDown must be invoked before setUp may be called again");
        }
        isSetUp = true;
        oldOut = System.out;
        oldErr = System.err;
        System.setOut(new ProtectedStream(oldOut));
        System.setErr(new ProtectedStream(oldErr));
        oldProps = (Properties)System.getProperties().clone();
        oldsm = System.getSecurityManager();
        String doInstall = System.getProperty("abbot.use_security_manager");
        if (oldsm == null && !"false".equals(doInstall)) {
            installed = true;
            // When the application tries to exit, throw control back to the
            // step runner to dispose of it
            Log.debug("Installing sm");
            System.setSecurityManager(new NoExitSecurityManager() {

                @Override
                public void checkRead(String file) {
                    // avoid annoying drive a: bug on w32 VM
                }

                @Override
                protected void exitCalled(int status) {
                    Log.debug("Terminating from security manager");
                    terminate();
                }
            });
        }
    }

    /** Restore (to the extent possible) the environment prior to running.
     */
    protected synchronized void tearDown() {
        if (isSetUp) {
            if (installed) {
                Log.debug("Uninstalling sm");
                System.setSecurityManager(oldsm);
                installed = false;
                oldsm = null;
            }
            if (oldProps != null) {
                System.setProperties(oldProps);
                oldProps = null;
            }
            System.setOut(oldOut);
            System.setErr(oldErr);
            oldOut = oldErr = null;
            isSetUp = false;
        }
    }

    /** Run the given script, propagating any failures or errors.  If the
     * given step is a script, preserves and restores the current test
     * environment. 
     */
    public void run(Step step) throws Throwable {
        if (SwingUtilities.isEventDispatchThread()) {
            throw new Error(Strings.get("BadScriptInvoke"));
        }
        boolean completed = false;
        clearErrors();
        if (step instanceof Script) setUp();

        try {
            if ((step instanceof Script) && ((Script)step).isForked()) {
                Log.debug("Forking " + step);
                StepRunner runner = new ForkedStepRunner();
                runner.listeners.addAll(listeners);
                try {
                    runner.runStep(step);
                } finally {
                    errors.putAll(runner.errors);
                }
            } else {
                runStep(step);
            }
            completed = !stopped();
        } catch (ExitException ee) {
            // application tried to exit
            Log.debug("App tried to exit");
            terminate();
        } finally {
            if (step instanceof Script) {
                if (completed && errors.size() == 0 || stopped() && terminateOnStop) {
                    /* abbot_ext begin */
                    // Beenden des Testsdialoges herausgenommen
                    // terminate();
                    /* abbot_ext end */
                }
            }
        }
    }

    /** Set whether the application under test should be terminated when an
    	error is encountered and script execution stopped.  The default
    	implementation always terminates.
    */
    public void setTerminateOnError(boolean state) {
        terminateOnError = state;
    }

    protected void clearErrors() {
        stop = false;
        errors.clear();
    }

    /** Main run method, which stores any failures or exceptions for later
     * retrieval.  Any step will fire STEP_START on starting, and exactly one
     * of STEP_END, STEP_FAILURE, or STEP_ERROR upon termination.  If
     * stopOnFailure/stopOnError is set false, then both STEP_FAILURE/ERROR
     * may be sent in addition to STEP_END.
     */
    @SuppressWarnings("unchecked")
    protected void runStep(final Step step) throws Throwable {
        Log.debug("Running " + step);
        fireStepStart(step);

        // checking for stopped here allows a listener to stop execution on a
        // particular step in response to its "start" event.
        if (!stopped()) {
            Throwable exception = null;
            long exceptionTime = -1;
            try {
                if (step instanceof Sequence) {
                    ((Sequence)step).runStep(this);
                } else if (step instanceof Launch) {
                    if (launchStep != null) {
                        /* abbot_ext begin */
                        // Launch z.B. in Unterscripten wird einfach ignoriert
                        // throw new IllegalArgumentException(Strings.get("runner.error.invalid_launch"));
                        return;

                        /* abbot_ext end */
                    }
                    launchStep = (Launch)step;
                    launchStep.setThreadedLaunchListener(new LaunchListener());
                    launchStep.run();
                } else {
                    step.run();
                    /* abbot_ext begin */
                    /* Testinstanz nicht mehr beenden */
                    /*
                    if (step instanceof Terminate) {
                        terminate();
                    }
                    */
                    /* abbot_ext end */
                }
            } catch (AssertionFailedError afe) {
                fireStepFailure(step, afe);
                if (stopOnFailure) {
                    stop(terminateOnError);
                    throw afe;
                }
            } catch (Throwable thr) {

                fireStepError(step, thr);
                if (stopOnError) {
                    stop(terminateOnError);
                    throw thr;
                }
            } finally {
                // Cf. ComponentTestFixture.runBare()
                // Any EDT exception which occurred *prior* to when the
                // exception on the main thread was thrown should be used
                // instead.
                long edtExceptionTime = EDTExceptionCatcher.getThrowableTime();
                Throwable edtException = EDTExceptionCatcher.getThrowable();
                if (edtException != null && (exception == null || edtExceptionTime < exceptionTime)) {
                    exception = edtException;
                }
            }
            fireStepEnd(step);
        }
    }


    /** Invoke the given script's launch step, if any.  Preserves the current
     * environment for later restore via the terminate method.
     */
    public void launch(Script script) throws Throwable {
        Launch launch = script.getLaunchStep();
        if (launch != null) {
            Log.debug("Launching " + launch);
            run(launch);
        } else {
            clearErrors();
        }
    }

    /** Dispose of any extant windows and restore any saved environment
     * state.
     */


    /* abbot_ext begin */

    public void terminate() {
        terminate(true);
    }

    //	public void terminate() {
    public void terminate(boolean tearDown) {

        Log.debug("terminating code under test");
        /* abbot_ext begin */
        /* Hier muss eine Implementierung hin, die die Basis3 komplett abr�umt
        /* Unter MWWMain nachschauen, was dort beim Exit der Basis3 gemacht wird

        //		System.out.println(DefaultComponentFinder.getFinder().getClass().getName());
        //		
        //		DefaultComponentFinder aFinder = (DefaultComponentFinder) DefaultComponentFinder.getFinder();
        //		Window[] windows = aFinder.getWindows();
        //		
        //		for (int i = 0; i < windows.length; i++) {
        //			Window nextWindow = windows[i];
        //			
        //			if (nextWindow.getClass().getName().equals("de.gfd.trend.gui.application.main.MWWMain")) {
        //				MWWMain theMain = (MWWMain) nextWindow;
        //				theMain.destroy();
        //			}
        //
        //		}
        
        /* abbot_ext end */

        DefaultComponentFinder.getFinder().disposeWindows();
        if (launchStep != null) {
            launchStep.uninstallContext();
            launchStep = null;
        }

        if (tearDown) {
            tearDown();
        }

    }

    /* abbot_ext end */


    protected void setError(Step step, Throwable thr) {
        errors.put(step, thr);
    }

    public Throwable getError(Step step) {
        return errors.get(step);
    }

    public void addStepListener(StepListener sl) {
        synchronized (listeners) {
            listeners.add(sl);
        }
    }

    public void removeStepListener(StepListener sl) {
        synchronized (listeners) {
            listeners.remove(sl);
        }
    }

    /** 
     * If this is used to propagate a failure/error, be sure to invoke
     * setError on the step first.
     * @SuppressWarnings("unchecked") Clone liefert immer Object
     */
    @SuppressWarnings("unchecked")
    protected void fireStepEvent(StepEvent event) {
        Iterator<StepListener> iter;
        synchronized (listeners) {
            iter = ((ArrayList<StepListener>)listeners.clone()).iterator();
        }
        while (iter.hasNext()) {
            StepListener sl = iter.next();
            sl.stateChanged(event);
        }
    }

    private void fireStepEvent(Step step, String type, int val, Throwable throwable) {
        synchronized (listeners) {
            if (listeners.size() != 0) {
                StepEvent event = new StepEvent(step, type, val, throwable);
                fireStepEvent(event);
            }
        }
    }


    //abbot_ext_begin alle Methoden public
    public void fireStepStart(Step step) {
        fireStepEvent(step, StepEvent.STEP_START, 0, null);
    }

    public void fireStepProgress(Step step, int val) {
        fireStepEvent(step, StepEvent.STEP_PROGRESS, val, null);
    }

    public void fireStepEnd(Step step) {
        fireStepEvent(step, StepEvent.STEP_END, 0, null);
    }

    //abbot_ext_end alle Methoden public

    protected void fireStepFailure(Step step, Throwable afe) {
        setError(step, afe);
        fireStepEvent(step, StepEvent.STEP_FAILURE, 0, afe);
    }

    protected void fireStepError(Step step, Throwable thr) {
        setError(step, thr);
        fireStepEvent(step, StepEvent.STEP_ERROR, 0, thr);
    }

    private class LaunchListener implements Launch.ThreadedLaunchListener {

        @Override
        public void stepFailure(Launch step, AssertionFailedError afe) {
            fireStepFailure(step, afe);
            if (stopOnFailure) stop(terminateOnError);
        }

        @Override
        public void stepError(Launch step, Throwable thr) {
            fireStepError(step, thr);
            if (stopOnError) stop(terminateOnError);
        }
    }

    /** Provide a wrapper that prevents the original stream from being
    	closed.
    */
    static private class ProtectedStream extends PrintStream {

        private boolean closed = false;

        public ProtectedStream(PrintStream original) {
            super(original);
        }

        @Override
        public void flush() {
            if (!closed) super.flush();
        }

        @Override
        public void close() {
            closed = true;
        }

        @Override
        public void write(int b) {
            if (!closed) super.write(b);
        }

        @Override
        public void write(byte[] buf, int off, int len) {
            if (!closed) super.write(buf, off, len);
        }
    }


}
