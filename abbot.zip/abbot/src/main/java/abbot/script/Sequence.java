package abbot.script;

import java.util.ArrayList;
import java.util.Map;
import java.util.Iterator;
import java.util.List;

import org.jdom2.Content;
import org.jdom2.Element;

import abbot.Resolver;
import abbot.i18n.Strings;


/** Script step which groups a sequence of other Steps.  The sub-Steps have a
 * fixed order and are executed in the order contained in the sequence.
 * Events sent by sub-Steps are propagated by this one.
 */
public class Sequence extends Step {

    private static final String USAGE = "<sequence ...>...</sequence>";

    private ArrayList<Step> sequence = new ArrayList<Step>();

    public Sequence(Resolver resolver, Element el, Map<String, String> atts) {
        super(resolver, atts);
        try {
            parseChildren(el);
        } catch (InvalidScriptException ise) {
            setScriptError(ise);
        }
    }

    public Sequence(Resolver resolver, Map<String, String> atts) {
        super(resolver, atts);
    }

    public Sequence(Resolver resolver, String desc) {
        this(resolver, desc, null);
    }

    /** Create an aggregate from existing AWTEvents. */
    public <M extends Step> Sequence(Resolver resolver, String desc, List<M> steps) {
        super(resolver, desc);
        if (steps != null) {
            Iterator<M> iter = steps.iterator();
            synchronized (sequence) {
                while (iter.hasNext()) {
                    addStep(iter.next());
                }
            }
        }
    }

    protected void parseChild(Element el) throws InvalidScriptException {
        Step step = createStep(getResolver(), el);
        addStep(step);
    }

    @SuppressWarnings("unchecked")
    protected void parseChildren(Element el) throws InvalidScriptException {
        synchronized (sequence) {
            Iterator<Content> iter = el.getContent().iterator();
            while (iter.hasNext()) {
                Object obj = iter.next();
                if (obj instanceof Element)
                    parseChild((Element)obj);
                else if (obj instanceof org.jdom2.Comment) {
                    String text = ((org.jdom2.Comment)obj).getText();
                    addStep(new abbot.script.Comment(getResolver(), text));
                }
            }
        }
    }

    @Override
    protected String getDefaultDescription() {
        return Strings.get("SequenceDesc", new Object[] {String.valueOf(size())});
    }

    @Override
    public String getXMLTag() {
        return TAG_SEQUENCE;
    }

    /**
     * 
     * {@inheritDoc}
     * @see abbot.script.Step#addContent(org.jdom.Element)
     * @SuppressWarnings("unchecked") Clone liefert immer Object
     */
    @SuppressWarnings("unchecked")
    @Override
    protected Element addContent(Element el) {
        ArrayList<Step> seq;
        synchronized (sequence) {
            seq = (ArrayList<Step>)sequence.clone();
        }
        Iterator<Step> iter = seq.iterator();
        while (iter.hasNext()) {
            Step step = iter.next();
            if (step instanceof abbot.script.Comment)
                el.addContent(new org.jdom2.Comment(step.getDescription()));
            else
                el.addContent(step.toXML());
        }
        return el;
    }

    /** Returns a string describing the proper XML usage for this class. */
    @Override
    public String getUsage() {
        return USAGE;
    }

    /** Only thing directly editable on a sequence is its description. */
    @Override
    public String toEditableString() {
        return getDescription();
    }

    /** Process each event in our list. */
    @Override
    protected void runStep() throws Throwable {
        runStep(null);
    }

    /** Process each event in our list, using the given runner. 
	 * @SuppressWarnings("unchecked") Clone liefert Object
	 */
    @SuppressWarnings("unchecked")
    protected void runStep(StepRunner runner) throws Throwable {
        Iterator<Step> iter;
        synchronized (sequence) {
            iter = ((List<Step>)sequence.clone()).iterator();
        }
        if (runner != null) {
            while (iter.hasNext() && !runner.stopped()) {
                runner.runStep(iter.next());
            }
        } else {
            while (iter.hasNext()) {
                (iter.next()).run();
            }
        }
    }

    /** Returns the number of steps contained in this one. */
    public int size() {
        synchronized (sequence) {
            return sequence.size();
        }
    }

    /** Remove all stepchildren. More effective than Cinderella's
        stepmother. */
    public void clear() {
        synchronized (sequence) {
            sequence.clear();
        }
    }

    /** Returns a list of the steps contained in this one. */
    public java.util.List<Step> steps() {
        return sequence;
    }

    /** Returns the index of the given step in the sequence, or -1 if the step
        is not in the sequence. */
    public int indexOf(Step step) {
        synchronized (sequence) {
            return sequence.indexOf(step);
        }
    }

    /** Return the step at the given index in the sequence. */
    public Step getStep(int index) {
        synchronized (sequence) {
            return sequence.get(index);
        }
    }

    /** Inserts a step at the given index in the sequence. */
    public void addStep(int index, Step step) {
        synchronized (sequence) {
            sequence.add(index, step);
        }
    }

    /** Adds a step to the end of the sequence. */
    public void addStep(Step step) {
        synchronized (sequence) {
            sequence.add(step);
        }
    }

    /** Replaces the step at the given index. */
    public void setStep(int index, Step step) {
        synchronized (sequence) {
            sequence.set(index, step);
        }
    }

    /** Removes the step if it exists in the sequence. */
    public void removeStep(Step step) {
        synchronized (sequence) {
            sequence.remove(step);
        }
    }

    /** Removes the step at the given index in the sequence. */
    public void removeStep(int index) {
        synchronized (sequence) {
            sequence.remove(index);
        }
    }
}
