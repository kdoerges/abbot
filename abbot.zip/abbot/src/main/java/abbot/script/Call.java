package abbot.script;

import java.awt.Component;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Map;
import java.util.Vector;

import abbot.Log;
import abbot.Resolver;
import abbot.i18n.Strings;
import abbot.tester.ComponentTester;

import com.obi.test.tregs.abbot.component.AbbotProperties;

import extensions.docgenerator.DocumentText;
import extensions.docgenerator.MessageText;


/* abbot_ext begin */


/* abbot_ext end */

/** Class for script steps that want to invoke a method on a class.
 * Subclasses may override getMethod and getTarget to customize behavior.
 * <blockquote><code>
 * &lt;call method="..." args="..." class="..."&gt;<br>
 * </code></blockquote>
 */
public class Call extends Step {

    private String targetClassName = null;

    private String methodName;

    private String[] args;

    private static final String USAGE = "<call class=\"...\" method=\"...\" args=\"...\" [property=\"...\"]/>";

    public Call(Resolver resolver, Map<String, String> attributes) {
        super(resolver, attributes);
        setMethodName(attributes.get(TAG_METHOD));
        setTargetClassName(attributes.get(TAG_CLASS));
        String argList = attributes.get(TAG_ARGS);
        if (argList == null) {
            argList = "";
        }
        args = ArgumentParser.parseArgumentList(argList);
    }

    public Call(Resolver resolver, String description, String className, String methodName, String[] args) {
        super(resolver, description);
        this.targetClassName = className;
        this.methodName = methodName;
        this.args = args != null ? args : new String[0];
    }

    @Override
    protected String getDefaultDescription() {

        /* abbot_ext begin */
        if (AbbotProperties.theInstance().getUseStepDescription()) {
            String udgDesc = DocumentText.getInstance().getDescriptionForCall(this);
            if (!MessageText.getInstance().isWarning(udgDesc)) {
                return udgDesc;
            } else {
                return getMethodName() + "(" + getEncodedArguments() + ")" + " " + udgDesc;
            }
        }
        ;
        /* abbot_ext end */

        return getMethodName() + "(" + getEncodedArguments() + ")";
    }

    @Override
    public String getUsage() {
        return USAGE;
    }

    @Override
    public String getXMLTag() {
        return TAG_CALL;
    }

    /** Convert our argument vector into a single String. */
    public String getEncodedArguments() {
        String argList = "";
        for (int i = 0; i < args.length; i++) {
            if (i != 0) {
                argList += ",";
            }
            argList += encode(args[i]);
        }
        return argList;
    }

    public void setArguments(String argList) {
        args = ArgumentParser.parseArgumentList(argList);
    }

    // abbot_ext_begin
    public void setArgs(String[] argList) {
        args = argList;
    }

    // abbot_ext_end

    public void setMethodName(String mn) {
        if (mn == null) {
            usage(Strings.get("MethodNameMissing"));
        }
        methodName = mn;
    }

    /** Method name to save in script. */
    public String getMethodName() {
        return methodName;
    }

    public String getTargetClassName() {
        //abbot_ext_begin
        //TargetClassName aus ComponentReferenz holen

        if (getArgs().length == 0) {
            return targetClassName;
        }

        // Pr�fe, ob ein ComponentTester schon direkt angegeben ist (z.B. f�r das �ffnen von Best�tigungsfenstern)

        boolean tempIsComponentTester = false;

        try {
            tempIsComponentTester = ComponentTester.class.isAssignableFrom(Class.forName(targetClassName));
        } catch (ClassNotFoundException e) {
            tempIsComponentTester = false;
        }

        if (tempIsComponentTester) {
            return targetClassName;
        }

        ComponentReference tempCompRef = getResolver().getComponentReference(getArgs()[0]);

        if (tempCompRef == null) {
            return targetClassName;
        } else {
            String tempTargetClassNameInCompRef = tempCompRef.getAttribute(ComponentReference.TAG_CLASS);
            if (tempTargetClassNameInCompRef == null) {
                return targetClassName;
            } else {
                return tempTargetClassNameInCompRef;
            }
        }

        //abbot_ext_end

    }

    public void setTargetClassName(String cn) {
        if (cn == null) {
            usage(Strings.get("ClassNameMissing"));
        }
        targetClassName = cn;
    }

    /** Attributes to save in script.  */
    @Override
    public Map<String, String> getAttributes() {
        Map<String, String> map = super.getAttributes();
        map.put(TAG_CLASS, getTargetClassName());
        map.put(TAG_METHOD, getMethodName());
        if (args.length != 0) {
            map.put(TAG_ARGS, getEncodedArguments());
        }
        return map;
    }

    /** Return the arguments as an array of String. */
    public String[] getArgs() {
        return args;
    }

    @Override
    protected void runStep() throws Throwable {
        try {
            invoke();
        } catch (Exception e) {
            Log.debug(e);
            throw e;
        }
    }

    /** Deferred evaluation of arguments allows us to refer to components that
     * don't necessarily exist when the script is read in. 
     */
    // NOTE: the default invocation is expected to be performed on a
    // ComponentTester target. 
    protected Object invoke() throws Throwable {
        try {
            Method m = getMethod();
            Log.debug("Invoking " + m + " with " + getEncodedArguments());
            Object[] params = ArgumentParser.eval(getResolver(), args, m.getParameterTypes());
            if ((params.length > 0) && (params[0] instanceof Component)) {
                setTargetClassName(params[0].getClass().getName());
                m = getMethod();
            }
            return m.invoke(getTarget(m), params);
        } catch (java.lang.reflect.InvocationTargetException ite) {
            throw ite.getTargetException();
        }
    }

    /** Return the method to be used for invocation.  The concrete
     * implementation of this method should invoke the method
     * resolveMethod with the appropriate arguments.
     */
    protected Method getMethod() throws InvalidScriptException {
        return resolveMethod(getMethodName(), getTargetClass(), null);
    }

    /** Get the class of the target of the method invocation.  This is public
     * to provide editors access to the class being used (for example,
     * providing a menu of all available methods).
     */
    public Class getTargetClass() throws InvalidScriptException {
        return resolveClass(getTargetClassName());
    }

    /** Return the target of the invocation.  The default implementation
     * always returns null for static methods; it will attempt to instantiate
     * a target for non-static methods.
     */
    protected Object getTarget(Method m) throws Throwable {
        if ((m.getModifiers() & Modifier.STATIC) == 0) {
            try {
                return getTargetClass().newInstance();
            } catch (Exception e) {
                setScriptError(new InvalidScriptException("Can't create an object instance of class "
                                                          + getTargetClassName()
                                                          + " for non-static method "
                                                          + m.getName()));
            }
        }
        return null;
    }

    /** Look up the given method name in the given class. */
    protected Method resolveMethod(String name, Class cls, Class returnType) {
        // use getDeclaredMethods to include class methods
        Method[] mlist = cls.getMethods();
        Vector<Method> found = new Vector<Method>();
        for (int i = 0; i < mlist.length; i++) {
            Method m = mlist[i];
            Class[] params = m.getParameterTypes();
            if (m.getName().equals(name)
                && params.length == args.length
                && (returnType == null || m.getReturnType().equals(returnType))) {
                found.add(m);
            }
        }
        if (found.size() == 0) {
            throw new IllegalArgumentException(Strings.get("NoMatchingMethod",
                                                           new Object[] {name,
                                                                         (returnType == null ? "void" : returnType
                                                                                 .toString()),
                                                                         String.valueOf(args.length),
                                                                         cls}));
        } else if (found.size() != 1) {
            throw new IllegalArgumentException(Strings.get("MultipleMethods", new Object[] {name, cls}));
        }
        Log.debug("found '" + name + "' in " + cls);
        return found.get(0);
    }

    static String encode(String arg) {
        if (arg == null) {
            return "(null)";
        }
        // Don't encode arrays, assume they're already encoded properly
        if (arg.startsWith("[") && arg.endsWith("]")) {
            return arg;
        }
        arg = ArgumentParser.replace(arg, "\\,", "--ESCAPED-COMMA--");
        arg = ArgumentParser.replace(arg, ",", "\\,");
        return ArgumentParser.replace(arg, "--ESCAPED-COMMA--", "\\,");
    }
}
