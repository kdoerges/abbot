package abbot.script;

import java.lang.reflect.Method;
import java.util.Map;

import abbot.Resolver;

import com.obi.test.tregs.abbot.component.AbbotProperties;

import extensions.docgenerator.DocumentText;
import extensions.docgenerator.MessageText;


/* abbot_ext begin */


/* abbot_ext end */

/** Encapsulate an action. Usage:<br>
 * <blockquote><code>
 * &lt;action method="..." args="..."&gt;<br>
 * &lt;action method="..." args="component_id[,...]" class="..."&gt;<br>
 * </code></blockquote>
 * An Action reproduces a user semantic action (such as a mouse click, menu
 * selection, or drag/drop action) on a particular component.  The id of the
 * component being operated on must be the first argument, and the class of
 * that component must be identified by the class tag if the action is not
 * provided by the base
 * <a href="../tester/ComponentTester.html">ComponentTester</a> class.<p>
 * Note that the method name is the name of the actionXXX method,
 * e.g. to click a button (actionClick on
 * AbstractButtonTester), the XML would appear thus:<p> 
 * <blockquote><code>
 * &lt;action method="actionClick" args="My Button" class=javax.swing.AbstractButton&gt;<br>
 * </code></blockquote>
 * Note that if the first argument is a Component, the class tag is required.
 * Note also that the specified class is the <i>tested</i> class, not the
 * target class for the method invocation.
 */
// FIXME don't put tested class into target class
public class Action extends Call {

    private static final String USAGE = "<action method=\"...\" args=\"...\" [class=\"...\"]/>";

    /** Provide a default value for the target class name, so that the Call
     * parent class won't choke.
     */
    private static Map<String, String> patchAttributes(Map<String, String> map) {
        if (map.get(TAG_CLASS) == null) {
            map.put(TAG_CLASS, "java.awt.Component");
        }
        return map;
    }

    public Action(Resolver resolver, Map<String, String> attributes) {
        super(resolver, patchAttributes(attributes));
        init();
    }

    /** Action for a method in the ComponentTester base class. */
    public Action(Resolver resolver, String description, String methodName, String[] args) {
        super(resolver, description, "java.awt.Component", methodName, args);
        init();
    }

    public Action(Resolver resolver, String description, String methodName, String[] args, Class targetClass) {
        super(resolver, description, targetClass.getName(), methodName, args);
        init();
    }

    private void init() {
        // account for deprecated usage
        String mn = getMethodName();
        if (!mn.startsWith("action")) setMethodName("action" + mn);
    }

    /** Ensure the default class name is "java.awt.Component".
     * The target class <i>must</i> be a subclass of java.awt.Component.
     */
    @Override
    public void setTargetClassName(String cn) {
        if (cn == null || "".equals(cn)) cn = "java.awt.Component";
        super.setTargetClassName(cn);
    }

    /** Return the XML tag for this step. */
    @Override
    public String getXMLTag() {
        return TAG_ACTION;
    }

    /** Return custom attributes for an Action. */
    @Override
    public Map<String, String> getAttributes() {
        Map<String, String> map = super.getAttributes();
        // Only save the class attribute if it's not the default
        map.remove(TAG_CLASS);
        if (!getTargetClassName().equals("java.awt.Component")) map.put(TAG_CLASS, getTargetClassName());
        return map;
    }

    /** Return the proper XML usage for this step. */
    @Override
    public String getUsage() {
        return USAGE;
    }

    /** Return a default description for this action. */
    @Override
    protected String getDefaultDescription() {

        /* abbot_ext begin */
        if (AbbotProperties.theInstance().getUseStepDescription()) {
            String udgDesc = DocumentText.getInstance().getDescriptionForAction(this);
            if (!MessageText.getInstance().isWarning(udgDesc)) {
                return udgDesc;
            } else {
                return (getMethodName().substring(6) + "(" + getEncodedArguments() + ")" + " " + udgDesc);
            }
        }
        ;
        /* abbot_ext end */

        // strip off "action"
        String name = getMethodName().substring(6);
        return name + "(" + getEncodedArguments() + ")";
    }

    @Override
    public Class getTargetClass() throws InvalidScriptException {
        return resolveTester(getTargetClassName()).getClass();
    }

    /** Return the target of the invocation. */
    @Override
    protected Object getTarget(Method m) throws InvalidScriptException {
        return resolveTester(getTargetClassName());
    }

    /** Resolve the method name into its final form. */
    @Override
    protected Method getMethod() throws InvalidScriptException {
        return resolveMethod(getMethodName(), getTargetClass(), void.class);
    }


}
