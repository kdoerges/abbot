/**
 * Dieses Package besteht schon in den original Abbot Sourcen und umfasst alle Methoden
 * zur Verwaltung / Parsen / Speichern von Abbot Skripten.
 * Da einige Steps GfD seitig �berschrieben wurden, um Zusatzfunktionen (etwa in Kommentaren oder
 * bei der iterierten Ausf�hrung von Sequencen) zur Verf�gung zu stellen, ersetzen diese
 * Klassen damit die original Sourcen und erweitern diese.
 * <br>
 * Hier werden Klassen abgelegt, die GfD seitig von den original Sourcen �berschrieben 
 * wurden. Die hier abgelegten Klassen ersetzen jeweils das Pendant im Originalpackage.
 */

package abbot.script;