package abbot.script;

import java.applet.Applet;
import java.awt.*;
import java.io.IOException;
import java.io.StringReader;
import java.lang.ref.WeakReference;
import java.util.*;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import abbot.*;
import abbot.tester.ComponentTester;
import abbot.tester.Robot;
import abbot.util.ExtendedComparator;

import com.obi.test.tregs.abbot.component.AbbotProperties;

import extensions.editor.ExtendedScriptEditor;
import extensions.util.AbbotI18NUtil;


/****
 * TEMPHACK to fix FW-941
 */

/** Encapsulate as much information as is available to identify a GUI
 * component. Usage:<br>
 * <blockquote><code>
 * &lt;component id="..." class="..." [...]&gt;<br>
 * </code></blockquote>
 * A number of optional tags are supported to provide an increasingly precise
 * specification of the desired component:<br>
 * <ul>
 * <li><b><code>tag</code></b> a class-specific identifier, e.g. the label on a
 * JButton.<br>
 * <li><b><code>name</code></b> the Component name, as set by
 * <code>setName()</code>.  Note that auto-generated names for windows and
 * frames are ignored and are considered to be null.
 * <li><b><code>parent</code></b> the reference id of this component's
 * parent.<br> 
 * </ul>
 * (This list subject to change as required by the
 * <a href="{@docRoot}/abbot/DefaultComponentFinder.html">DefaultComponentFinder</a>).  
 */
// TODO: extract resolver stuff
// - adjust attribute values when fuzzy matches are accepted
// - add an "appearance order" for frames, based on frame0, frame1, etc
//   should this be preferred over horder and vorder?  not for applets, b/c
//   appearance order is not deterministic.
public class ComponentReference implements Tags, XMLifiable {

	private static final Logger logger = LoggerFactory.getLogger(ComponentReference.class);
	
    // Matching weights for various attributes
    private static final int MW_NAME = 100;

    private static final int MW_TAG = 50;

    private static final int MW_PARENT = 25;

    private static final int MW_WINDOW = 25;

    private static final int MW_INVOKER = 25;

    private static final int MW_INDEX = 25;

    private static final int MW_TITLE = 10;

    private static final int MW_CLASS = 1;

    // Pretty much for applets only, or other embedded frames
    private static final int MW_PARAMS = 1;

    private static final int MW_DOCBASE = 1;

    // Mostly for distinguishing between multiple components that would
    // otherwise all match 
    private static final int MW_HORDER = 1;

    private static final int MW_VORDER = 1;

    private static final int MW_ENABLED = 1;

    private static final int MW_FOCUSED = 1;

    /** Match weight corresponding to no possible match. */
    public static final int MW_FAILURE = 0;

    private final Resolver resolver;

    private final ComponentFinder finder;

    private final Map<String, String> attributes = new TreeMap<String, String>();

    // This helps component reference creation by an order of magnitude,
    // especially when dealing with ordered attributes.
    private WeakReference<Component> cachedLookup = null;

    //abbot_ext_begin

    private static boolean oldConventionMode = false;

    public static boolean isOldConventionMode() {
        return oldConventionMode;
    }


    public static void setOldConventionMode(boolean someOldConventionMode) {
        oldConventionMode = someOldConventionMode;
    }


    //abbot_ext_end

    public static final Collection<String> VALID_ATTRIBUTES = Arrays.asList(new String[] {TAG_ID,
                                                                                          TAG_NAME,
                                                                                          TAG_TAG,
                                                                                          TAG_CLASS,
                                                                                          TAG_WINDOW,
                                                                                          TAG_TITLE,
                                                                                          TAG_PARENT,
                                                                                          TAG_INDEX,
                                                                                          TAG_INVOKER,
                                                                                          TAG_PARAMS,
                                                                                          TAG_DOCBASE,
                                                                                          TAG_HORDER,
                                                                                          TAG_VORDER,
                                                                                          // These are deprecated
                                                                                          TAG_X,
                                                                                          TAG_Y,});

    private static final Collection<String> DEPRECATED_ATTRIBUTES = Arrays.asList(new String[] {TAG_X, TAG_Y,});

    /** For general component lookup by class name.
     * @param id Desired ID for the reference.  Only used if this reference is
     * to be passed as the parent, window, or invoker of another.
     * @param compClass Class of the component (required)
     */
    public ComponentReference(String id, Class compClass) {
        this(null, compClass, createAttributeMap(new String[][] {{TAG_ID, id},}));
    }

    /** For general component lookup.
     * @param id Desired ID for the reference.  Only used if this reference is
     * to be passed as the parent, window, or invoker of another.
     * @param compClass Class of the component (required)
     * @param name Name of the component, or null
     * @param tag Tag as returned by ComponentTester.getTag(Component)
     */
    public ComponentReference(String id, Class compClass, String name, String tag) {
        this(null, compClass, createAttributeMap(new String[][] { {TAG_ID, id}, {TAG_NAME, name}, {TAG_TAG, tag},}));
    }

    /** For general component lookup.
     * @param id Desired ID for the reference.  Only used if this reference is
     * to be passed as the parent, window, or invoker of another.
     * @param compClass Class of the component (required)
     * @param name Name of the component, or null
     * @param tag Tag as returned by ComponentTester.getTag(Component)
     * @param title Owning Frame/Dialog title, or null
     */
    public ComponentReference(String id, Class compClass, String name, String tag, String title) {
        this(null, compClass, createAttributeMap(new String[][] { {TAG_ID, id},
                                                                 {TAG_NAME, name},
                                                                 {TAG_TAG, tag},
                                                                 {TAG_TITLE, title},}));
    }

    /** For general component lookup.
     * @param id Desired ID for the reference.  Only used if this reference is
     * to be passed as the parent, window, or invoker of another.
     * @param compClass Class of the component (required)
     * @param name Name of the component, or null
     * @param tag Tag as returned by ComponentTester.getTag(Component)
     * @param title Owning Frame/Dialog title, or null
     * @param parent Reference to parent, or null
     * @param index Index within parent, or -1
     */
    public ComponentReference(String id, Class compClass, String name, String tag, String title,
            ComponentReference parent, int index) {
        this(null, compClass, createAttributeMap(new String[][] { {TAG_ID, id},
                                                                 {TAG_NAME, name},
                                                                 {TAG_TAG, tag},
                                                                 {TAG_TITLE, title},
                                                                 {TAG_PARENT, parent.getID()},
                                                                 {TAG_INDEX, String.valueOf(index)},}));
    }

    /** For general component lookup.
     * @param id Desired ID for the reference.  Only used if this reference is
     * to be passed as the parent, window, or invoker of another.
     * @param compClass Class of the component (required)
     * @param name Name of the component, or null
     * @param tag Tag as returned by ComponentTester.getTag(Component)
     * @param title Owning Frame/Dialog title, or null
     * @param parent Reference to parent, or null
     * @param index Index within parent, or -1
     * @param invokerOrWindow Window reference, invoker, or null
     */
    public ComponentReference(String id, Class compClass, String name, String tag, String title,
            ComponentReference parent, int index, ComponentReference invokerOrWindow) {
        this(null, compClass, createAttributeMap(new String[][] { {TAG_ID, id},
                                                                 {TAG_NAME, name},
                                                                 {TAG_TAG, tag},
                                                                 {TAG_TITLE, title},
                                                                 {TAG_PARENT, parent.getID()},
                                                                 {TAG_INDEX, String.valueOf(index)},
                                                                 {(JPopupMenu.class.isAssignableFrom(compClass)
                                                                          ? TAG_INVOKER : TAG_WINDOW),
                                                                  invokerOrWindow.getID()},}));
    }

    /** For creation from XML. */
    public ComponentReference(Resolver resolver, Element el) throws InvalidScriptException {
        this.resolver = resolver;
        this.finder = DefaultComponentFinder.getFinder();
        fromXML(el, true);
    }

    public ComponentReference(Resolver resolver, Class cls, Map<String, String> attributes) {
        // sort of a hack to provide a 'default' resolver
        this.resolver = resolver;
        this.finder = DefaultComponentFinder.getFinder();
        Iterator<String> iter = attributes.keySet().iterator();
        while (iter.hasNext()) {
            String key = iter.next();
            if (!VALID_ATTRIBUTES.contains(key))
                throw new IllegalArgumentException("Attribute '" + key + "' not recognized");
        }
        this.attributes.putAll(attributes);
        this.attributes.put(TAG_CLASS, Robot.getCanonicalClass(cls).getName());
    }

    /** Create a reference based on the given component.  May recursively add
     * other components required to identify this one.
     */
    public ComponentReference(Resolver resolver, Component comp) {
        this(resolver, comp, true);
    }

    /** Create a reference based on the given component.  May recursively add
     * other components required to identify this one if <code>resolve</code>
     * is true.
     */
    public ComponentReference(Resolver resolver, Component comp, boolean resolve) {
        this.resolver = resolver;
        this.finder = DefaultComponentFinder.getFinder();

        Class refClass = Robot.getCanonicalClass(comp.getClass());
        setAttribute(TAG_CLASS, refClass.getName());
        setAttribute(TAG_NAME, finder.getComponentName(comp));
        setAttribute(TAG_TAG, ComponentTester.getTag(comp));


        if (comp instanceof Applet) {
            Applet applet = (Applet)comp;
            setAttribute(TAG_PARAMS, encodeParams(applet));
            java.net.URL url = applet.getDocumentBase();
            setAttribute(TAG_DOCBASE, url != null ? url.toString() : "null");
        }

        // If there's no tag, we need to store the parent in order to get
        // enough identifying information.
        Container parent = comp.getParent();
        if (null != parent) {
            Component[] children = parent.getComponents();
            for (int i = 0; i < children.length; ++i) {
                if (children[i] == comp) {
                    setAttribute(TAG_INDEX, String.valueOf(i));
                    break;
                }
            }
        }

        if (resolve) resolve(resolver, comp);

        /* abbot_ext begin */
        // F�r Labels den Editor im Name-Tag festhalten, damit Text �bersetzt werden kann
        if (comp instanceof JLabel) {

            if (AbbotProperties.theInstance().getI18NSupport()) {
                String editorName = comp.getParent().getClass().getName();
                //              W�re am elegantesten, wird aber von Abbot wieder �berschrieben  
                //              setAttribute(TAG_WINDOW, editorName );
                setAttribute(TAG_NAME, editorName);
            }
        }

        /* abbot_ext end */

    }

    /** Ensure the reference can be used to actually look up the given
     * component.  This can be a compute-intensive search, and thus is omitted
     * from the basic constructor.
     */
    private void resolve(Resolver aResolver, Component comp) {
        Class refClass = Robot.getCanonicalClass(comp.getClass());

        if (comp instanceof JPopupMenu) {
            ComponentReference ref = aResolver.addComponent(((JPopupMenu)comp).getInvoker());
            setAttribute(TAG_INVOKER, ref.getID());
        }

        Component parent = comp.getParent();
        if (null != parent && getAttribute(TAG_TAG) == null && !(parent instanceof Window)) {
            aResolver.addComponent(parent);
        }
        // Always save the window ID if the component is not a window, which
        // is preferable to the title for script maintenance purposes.
        // Popup menus with a non-JMenu invoker shouldn't store a window.
        // They provide a tag which will store the invoking component instead.
        if (!(JPopupMenu.class.isAssignableFrom(refClass) && JMenu.class.isAssignableFrom(((JPopupMenu)comp)
                .getInvoker().getClass()))) {
            Window win = finder.getComponentWindow(comp);
            if (win != null && !(comp instanceof Window)) {
                ComponentReference wref = aResolver.addComponent(win);
                setAttribute(TAG_WINDOW, wref.getID());
            }
        }

        // Ensure that what we just created can be used to look up the
        // component.  Under certain situations where we know the component is
        // unreachable from the root of the hierarchy, or if a lookup will
        // fail for other reasons, simply check for a match.
        // * Popups may already have gone away, and will be unreachable.
        // * JInternalFrames have no parent when closed/iconified.
        // * Since non-showing windows are skipped on lookup, Components on
        // just-closed windows would fail lookup.
        // WARNING: this leaves a hole if the component actually needs an
        // ORDER attribute.
        if (Robot.isOnPopup(comp) || (!(comp instanceof Window) && parent == null) || !comp.isShowing()) {
            if (getMatchWeight(comp) < getExactMatchWeight()) {

                /* abbot_ext_begin */

                // Herausgenommen, da dies im Kassenbereich zu dem Fehler f�hrte
                //              throw new Error("Generated reference does not exactly "
                //                              + " match original component ("
                //                              + toXMLString() + " vs. " + comp);
                System.out.println("Generated reference does not exactly "
                                   + " match original component ("
                                   + toXMLString()
                                   + " vs. "
                                   + comp);

                /* abbot_ext_end */
            }
        } else
            try {
                findInHierarchy(finder, getExactMatchWeight());
            } catch (MultipleComponentsFoundException multiples) {
                try {
                    // More than one match found, so add more information
                    Log.debug("Disambiguating");
                    disambiguate(comp, multiples.getComponents());
                } catch (Exception e) {
                    Log.warn(e);
                    throw new Error("Reverse lookup failed to uniquely match "
                                    + Robot.toString(comp)
                                    + " against "
                                    + toXMLString());
                }
            } catch (ComponentNotFoundException cnf) {
                // This indicates a failure in the reference recording mechanism,
                // and requires a fix.
                Log.warn(cnf);
                throw new Error("Reverse lookup failed looking for " + Robot.toString(comp) + " using " + toXMLString());
            }

        // Finally, get a unique ID for this reference
        setAttribute(TAG_ID, aResolver.getUniqueID(this));
        Log.debug("Unique ID is " + getID());
    }

    public String getID() {
        return getAttribute(TAG_ID);
    }

    public String getRefClassName() {
        return getAttribute(TAG_CLASS);
    }

    public String getAttribute(String key) {
        return attributes.get(key);
    }

    /** For package-level testing only. */
    /* abbot_ext begin */
    // void setAttribute(String key, String value) {
    public void setAttribute(String key, String value) {
        /* abbot_ext end */
        attributes.put(key, value);
    }

    private boolean isAssignableFrom(String refClassName, Class cls) {
        return refClassName.equals(cls.getName())
               || (!Component.class.equals(cls) && isAssignableFrom(refClassName, cls.getSuperclass()));
    }

    /** Return whether this reference has the same class or is a superclass of
     * the given component's class.  Simply compare class names to avoid class
     * loader conflicts.  Note that this does not take into account interfaces
     * (which is okay, since with GUI components we're only concerned with
     * class inheritance). 
     */
    public boolean isAssignableFrom(Class cls) {
        return cls != null && Component.class.isAssignableFrom(cls) && isAssignableFrom(getAttribute(TAG_CLASS), cls);
    }

    public ComponentReference getParentReference() {
        String parentID = getAttribute(TAG_PARENT);
        ComponentReference pref = null;
        if (parentID != null) {
            pref = resolver.getComponentReference(parentID);
        }
        return pref;
    }

    /** Reference ID of this component's parent window (optional). */
    public ComponentReference getWindowReference() {
        String windowID = getAttribute(TAG_WINDOW);
        ComponentReference wref = null;
        if (windowID != null) {
            wref = resolver.getComponentReference(windowID);
        }
        return wref;
    }

    public ComponentReference getInvokerReference() {
        String invokerID = getAttribute(TAG_INVOKER);
        ComponentReference iref = null;
        if (invokerID != null) {
            iref = resolver.getComponentReference(invokerID);
        }
        return iref;
    }

    /** Set all options based on the given XML. */
    // This is only used when editing scripts, since we don't want to have to
    // hunt down existing references
    public void fromXML(String xml) throws InvalidScriptException {
        StringReader reader = new StringReader(xml);
        try {
            SAXBuilder builder = new SAXBuilder();

            //abbot_ext_begin
            // ge�ndert f�r jdom 1.1.1

            Document doc;
            try {
                doc = builder.build(reader);
            } catch (IOException e) {
                throw new InvalidScriptException(e.toString());
            }
            //abbot_ext_end

            Element el = doc.getRootElement();
            if (el == null) throw new InvalidScriptException("Invalid ComponentReference" + " XML '" + xml + "'");
            fromXML(el, false);
        } catch (JDOMException e) {
            throw new InvalidScriptException(e.getMessage() + " (when parsing " + xml + ")");
        }
    }

    /** Parse settings from the given XML.   Only overwrite the ID if
        useGivenID is set.
        @throws InvalidScriptException if the given Element is not valid XML
        for a ComponentReference.
    */
    @SuppressWarnings("unchecked")
    private void fromXML(Element el, boolean useIDFromXML) throws InvalidScriptException {

        Iterator<Attribute> iter = el.getAttributes().iterator();
        while (iter.hasNext()) {
            Attribute att = iter.next();
            String nodeName = att.getName();
            String value = att.getValue();
            if (!VALID_ATTRIBUTES.contains(nodeName))
                throw new InvalidScriptException("Invalid attribute '" + nodeName + "'");
            else if (DEPRECATED_ATTRIBUTES.contains(nodeName))
                continue;
            else if (nodeName.equals(TAG_ID) && !useIDFromXML) continue;

            setAttribute(nodeName, value);
        }
        if (getAttribute(TAG_CLASS) == null) {
            throw new InvalidScriptException("Class must be specified", el);
        }
        String id = getID();
        if (useIDFromXML) {
            // Make sure the ID we read in is not already in use by the manager
            if (id != null) {
                if (resolver.getComponentReference(id) != null) {
                    String msg = "Persistent ID '" + id + "' is already in use";
                    throw new InvalidScriptException(msg, el);
                }
            }
        }
        if (id == null) setAttribute(TAG_ID, resolver.getUniqueID(this));
    }

    @Override
    public Element toXML() {
        Element el = new Element(TAG_COMPONENT);
        Iterator<String> iter = attributes.keySet().iterator();
        while (iter.hasNext()) {
            String key = iter.next();
            String value = getAttribute(key);
            if (value != null) el.setAttribute(key, value);
        }
        return el;
    }

    @Override
    public String toEditableString() {
        return Step.toXMLString(this);
    }

    /** Two ComponentReferences with identical XML representations should 
        be equal. */
    @Override
    public boolean equals(Object obj) {
        return this == obj
               || (obj instanceof ComponentReference)
               && Step.toXMLString(this).equals(Step.toXMLString((ComponentReference)obj));
    }

    /** Return a human-readable representation. */
    @Override
    public String toString() {
        String id = getID();
        String refClassName = getAttribute(TAG_CLASS);
        String str = id != null ? id : (refClassName + " (no id yet)");
        if (str.indexOf("Instance") == -1) str += " (" + refClassName + ")";
        return str;
    }

    public String toXMLString() {
        return Step.toXMLString(this);
    }

    /** Return which of the otherwise indistinguishable components provides
     * the best match, or throw a MultipleComponentsFoundException if no
     * distinction is possible.  Assumes that all given components return an
     * equivalent match weight.
     */
    private Component bestMatch(Collection<Component> set) throws MultipleComponentsFoundException {
        Component[] matches = set.toArray(new Component[set.size()]);
        int weights[] = new int[matches.length];
        for (int i = 0; i < weights.length; i++) {
            // Prefer enabled components
            weights[i] = 0;
            // Preferring one enabled/focused state is dangerous to do:
            // An enabled component might be preferred over a disabled one,
            // but it will fail if you're trying to examing state on the
            // disabled component.  Ditto for focused.
            /*
            if (matches[i].isEnabled())
                weights[i] += MW_ENABLED;
            if (matches[i].hasFocus())
                weights[i] += MW_FOCUSED;
            */
        }

        String horder = getAttribute(TAG_HORDER);
        if (horder != null) {
            for (int i = 0; i < matches.length; i++) {
                String order = getOrder(matches[i], matches, true);
                if (horder.equals(order)) {
                    weights[i] += MW_HORDER;
                }
            }
        }
        String vorder = getAttribute(TAG_VORDER);
        if (vorder != null) {
            for (int i = 0; i < matches.length; i++) {
                String order = getOrder(matches[i], matches, false);
                if (vorder.equals(order)) {
                    weights[i] += MW_VORDER;
                }
            }
        }
        // Figure out the best match, if any
        boolean isMaximum = true;
        int max = 0;
        for (int i = 1; i < weights.length; i++) {
            if (weights[i] > weights[max]) {
                if (Log.isClassDebugEnabled(ComponentReference.class))
                    Log.debug(Robot.toString(matches[i]) + " is max: " + weights[i]);
                max = i;
                isMaximum = true;
            } else if (weights[i] == weights[max]) {
                isMaximum = false;
            }
        }
        if (isMaximum) {
            if (Log.isClassDebugEnabled(ComponentReference.class))
                Log.debug("Best match is " + Robot.toString(matches[max]));
            return matches[max];
        }
        String msg = "Could not distinguish between " + matches.length + " components using " + toXMLString();
        throw new MultipleComponentsFoundException(msg, matches);
    }

    /** Return the order of the given component among the array given, sorted
     * by horizontal or vertical screen position.  All components with the
     * same effective value will have the same order.
     */
    static String getOrder(Component original, Component[] matchList, boolean horizontal) {
        Comparator<Component> c = horizontal ? HORDER_COMPARATOR : VORDER_COMPARATOR;
        Component[] matches = matchList.clone();
        Arrays.sort(matches, c);
        int order = 0;
        for (int i = 0; i < matches.length; i++) {
            // Only change the order magnitude if there is a difference
            // between consecutive objects. 
            if (i > 0 && c.compare(matches[i - 1], matches[i]) != 0) ++order;
            if (matches[i] == original) {
                return String.valueOf(order);
            }
        }
        return null;
    }

    /** Add sufficient information to the reference to distinguish it among
        the given components.
        Note that the ordering attributes can only be evaluated when looking
        at several otherwise identical components.
    */
    private void disambiguate(Component original, Component[] matches) throws ComponentNotFoundException,
            MultipleComponentsFoundException {
        Container parent = original.getParent();
        boolean retryOnFailure = true;
        String order = null;
        try {
            if (parent != null && getAttribute(TAG_PARENT) == null) {
                if (parent != finder.getComponentWindow(original)) {
                    ComponentReference ref = resolver.addComponent(parent);
                    setAttribute(TAG_PARENT, ref.getID());
                }
            } else if (getAttribute(TAG_HORDER) == null && (order = getOrder(original, matches, true)) != null) {
                setAttribute(TAG_HORDER, order);
            } else if (getAttribute(TAG_VORDER) == null && (order = getOrder(original, matches, false)) != null) {
                setAttribute(TAG_VORDER, order);
            } else {
                // Didn't add anything new, bail
                retryOnFailure = false;
            }
            // Try the lookup again to make sure it works this time
            Log.debug("Retrying lookup with new values");
            findInHierarchy(finder, getExactMatchWeight());
            Log.debug("Success!");
        } catch (MultipleComponentsFoundException multiples) {
            if (retryOnFailure) {
                disambiguate(original, multiples.getComponents());
            } else
                throw multiples;
        }
    }

    /** Return a measure of how well the given component matches the given
     * component reference.  The weight performs two functions; one is to
     * loosely match so that we can find a component even if some of its
     * attributes have changed.  The other is to distinguish between similar
     * components. <p>
     * In general, we want to match if we get any weight at all, and there's
     * only one component that matches.
     */
    int getMatchWeight(Component comp) {
        // Match weights may be positive or negative.  They should only be
        // negative if the attribute is highly unlikely to change.

        int weight = MW_FAILURE;

        if (null == comp) {
            return MW_FAILURE;
        }

        // FIXME might want to allow changing the class?  or should we just
        // ask the user to fix the script by hand?
        if (!isAssignableFrom(comp.getClass())) {
            return MW_FAILURE;
        }

        weight += MW_CLASS;
        // Exact class matches are better than non-exact matches
        if (getAttribute(TAG_CLASS).equals(comp.getClass().getName())) weight += MW_CLASS;

        String compTag = ComponentTester.getTag(comp);
        String refTag = getAttribute(TAG_TAG);
        if (null != compTag && null != refTag) {
            if (expressionMatch(refTag, compTag)) {
                weight += MW_TAG;
            }
        }


        // TODO Refactoring z.B. in Klasse TRENDGUIControlUtil
        // Kann alles heraus genommen werden, wenn alle Skripte I18N-Konvertiert

        boolean tmpTreatCompNameAsNull = false;
        if (comp.getClass().getSimpleName().equals("GButtonControl")) {
            Component tempParent = comp.getParent();
            if (tempParent != null) {
                tempParent = tempParent.getParent();
                if ((tempParent != null) && (tempParent instanceof JOptionPane)) {
                    String tempComponentName = comp.getName();

                    // Bei der alten Konvention hatten die Buttons keinen Namen
                    String myTagName = getAttribute(TAG_NAME);
                    boolean tempIsOldConvention =
                            ("Ja".equals(myTagName))
                                    || ("Nein".equals(myTagName))
                                    || ("Abbruch".equals(myTagName))
                                    || ("OptionPane.button".equals(myTagName));

                    if (tempIsOldConvention
                        && (("Yes".equals(tempComponentName)) || ("No".equals(tempComponentName)) || ("Cancel"
                                .equals(tempComponentName)))) {

                        /****
                         * TEMPHACK to fix FW-941: we do NOT set the comp name to null here! */
                        tmpTreatCompNameAsNull = true;

                        // comp.setName(null);
                    }
                }

            }
        }


        String compName = finder.getComponentName(comp);
        String refName = getAttribute(TAG_NAME);
        if (null != compName && null != refName) {
            if (tmpTreatCompNameAsNull) {
                System.out.println("Preventing Name expression match for OldConventionMode:"
                                   + compName
                                   + "<>"
                                   + refName);
            } else {
                if (expressionMatch(refName, compName)) {
                    weight += MW_NAME;
                } else {
                    weight -= MW_NAME;
                }
            }
        }

        if (null != getAttribute(TAG_INVOKER)) {
            ComponentReference iref = getInvokerReference();
            if ((comp instanceof JPopupMenu) && ((JPopupMenu)comp).getInvoker() == iref.findComponentInHierarchy()) {
                weight += MW_INVOKER;
            } else {
                // Invoking components aren't likely to change
                weight -= MW_INVOKER;
            }
        }

        if (null != getAttribute(TAG_PARENT)) {
            ComponentReference pref = getParentReference();
            Component parent = finder.getComponentParent(comp);
            if (parent != null) {
                if (!comp.isShowing() && !parent.isShowing()) {
                    if (pref.getMatchWeight(parent) >= pref.getExactMatchWeight()) weight += MW_PARENT;
                } else if (parent == pref.findComponentInHierarchy()) {
                    weight += MW_PARENT;
                }
                // Don't detract on parent mismatch, since changing a parent is
                // not that big a change (e.g. adding a scroll pane)
            } else {
                // Subtract if there should be a parent and there isn't...
                weight -= MW_PARENT;
            }
        }

        if (null != getAttribute(TAG_WINDOW)) {
            ComponentReference wref = getWindowReference();
            Window w = finder.getComponentWindow(comp);
            Log.debug("Checking window of " + toXMLString());

            /* abbot_ext_begin */
            if (null == w) {
                return MW_FAILURE;
            }
            /* abbot_ext_end */

            if (!comp.isShowing() && !w.isShowing()) {
                if (wref.getMatchWeight(w) >= wref.getExactMatchWeight()) weight += MW_WINDOW;
            } else if (w == wref.findComponentInHierarchy()) {
                if (Log.isClassDebugEnabled(ComponentReference.class))
                    Log.debug("Ref window " + wref + " for " + toXMLString() + " matches " + Robot.toString(w));
                weight += MW_WINDOW;
            } else {
                // Changing windows is a big change and not very likely
                if (Log.isClassDebugEnabled(ComponentReference.class))
                    Log.debug("Ref window "
                              + wref
                              + " for "
                              + toXMLString()
                              + " doesn't match actual window "
                              + Robot.toString(w));
                weight -= MW_WINDOW;
            }
        }

        String title = getAttribute(TAG_TITLE);
        if (null != title) {
            if (expressionMatch(title, finder.getComponentWindowTitle(comp))) {
                weight += MW_TITLE;
            }
            // Don't subtract on mismatch, since title changes are common
        }

        String idx = getAttribute(TAG_INDEX);
        if (null != idx) {
            Container parent = comp.getParent();
            if (null != parent) {
                Component[] children = parent.getComponents();
                for (int i = 0; i < children.length; ++i) {
                    if (children[i] == comp && expressionMatch(idx, String.valueOf(i))) {
                        weight += MW_INDEX;
                        break;
                    }
                }
            }
            // Don't subtract for index mismatch, since ordering changes are
            // common. 
        }

        if (comp instanceof Applet) {
            Applet applet = (Applet)comp;
            String params = getAttribute(TAG_PARAMS);
            if (null != params) {
                String params2 = encodeParams(applet);
                if (expressionMatch(params, params2)) weight += MW_PARAMS;
            }
            String docBase = getAttribute(TAG_DOCBASE);
            if (null != docBase) {
                java.net.URL url = applet.getDocumentBase();
                if (url != null && expressionMatch(docBase, url.toString())) weight += MW_DOCBASE;
            }
            // No negative weighting here
        }

        if (Log.isClassDebugEnabled(ComponentReference.class))
            Log.debug("Comparing " + Robot.toString(comp) + " to " + toXMLString() + " weight is " + weight);

        return weight;
    }

    /** Return the total weight required for an exact match. */
    private int getExactMatchWeight() {
        int weight = MW_CLASS; // 1
        if (getAttribute(TAG_NAME) != null) // 100
            weight += MW_NAME;
        if (getAttribute(TAG_TAG) != null) // 50
            weight += MW_TAG;
        if (getAttribute(TAG_INVOKER) != null) // 25
            weight += MW_INVOKER;
        if (getAttribute(TAG_PARENT) != null) // 25
            weight += MW_PARENT;
        if (getAttribute(TAG_WINDOW) != null) // 25
            weight += MW_WINDOW;
        if (getAttribute(TAG_TITLE) != null) // 10
            weight += MW_TITLE;
        if (getAttribute(TAG_INDEX) != null) // 25
            weight += MW_INDEX;
        if (getAttribute(TAG_PARAMS) != null) // 1
            weight += MW_PARAMS;
        if (getAttribute(TAG_DOCBASE) != null) // 1
            weight += MW_DOCBASE;

        Log.debug("Exact match weight for " + toXMLString() + " is " + weight);
        return weight;
    }

    /** Returns an existing component which matches this reference.  Returns
     * null if no match or multiple matches are found.
     */
    private Component findComponentInHierarchy() {
        Log.debug("Looking up " + toXMLString() + " in hierarchy");
        Component found = null;
        try {
            found = findInHierarchy(finder);
        } catch (MultipleComponentsFoundException mcf) {} catch (ComponentNotFoundException cnf) {}
        return found;
    }


    /* abbot_ext_begin */
    public static ComponentReference quickMatchExisting(Component comp, Collection<ComponentReference> existing,
            Script aScript) {

        ComponentReference createRef = new ComponentReference(aScript, comp);

        // Durchsuche alle Referenzen, ob sie schon vorhanden ist

        Iterator<ComponentReference> iter = existing.iterator();
        ComponentReference match = null;
        while (iter.hasNext()) {
            ComponentReference ref = iter.next();
            if (ref.equals(createRef)) {
                match = ref;
                break;
            }
        }

        return match;

    }

    /* abbot_ext_end */


    /** Match the given component against an existing set of references. */
    public static ComponentReference matchExisting(Component comp, Collection<ComponentReference> existing) {
        if (Log.isClassDebugEnabled(ComponentReference.class))
            Log.debug("Looking for " + Robot.toString(comp) + " in a group of existing references");
        Iterator<ComponentReference> iter = existing.iterator();
        ComponentReference match = null;
        while (iter.hasNext()) {
            ComponentReference ref = iter.next();
            if (comp == ref.findComponentInHierarchy()) {
                match = ref;
                break;
            }
        }
        Log.debug(match != null ? "Found" : "Not found");
        return match;
    }

    /** Return whether the given pattern matches the given string.  Performs
     * variable substitution on the pattern.
     */
    private boolean expressionMatch(String pattern, String actual) {
        pattern = ArgumentParser.substitute(resolver, pattern);
        return ExtendedComparator.stringsMatch(pattern, actual);
    }

    /** Convert the given applet's parameters into a simple String. */
    private String encodeParams(Applet applet) {
        // TODO: is there some other way of digging out the full set of
        // parameters that were passed the applet? b/c here we rely on the
        // applet having been properly written to tell us about supported
        // parameters.
        StringBuffer sb = new StringBuffer();
        String[][] info = applet.getParameterInfo();
        if (info == null) {
            // Default implementation of applet returns null
            return "null";
        }
        for (int i = 0; i < info.length; i++) {
            sb.append(info[i][0]);
            sb.append("=");
            String param = applet.getParameter(info[i][0]);
            sb.append(param != null ? param : "null");
            sb.append(";");
        }
        return sb.toString();
    }

    /** Using the given finder to read the current hierarchy, match this
        reference against an existing component.
    */
    public Component findInHierarchy(ComponentFinder aFinder) throws ComponentNotFoundException,
            MultipleComponentsFoundException {

        //abbot_ext_begin
        // Pr�fe, ob noch alte Konvention

        boolean tempCurrentConventionMode = ComponentReference.isOldConventionMode();


        if (AbbotI18NUtil.theInstance().checkIsOldConventionMode(this)) {
            ComponentReference.setOldConventionMode(true);
        } else {
            ComponentReference.setOldConventionMode(false);
        }

        String tempCurrentTag = getAttribute(ComponentReference.TAG_TAG);
        if ((tempCurrentTag != null)
            && ((tempCurrentTag.indexOf("CustomTreeLineTreeArea") != -1)
                || (tempCurrentTag.indexOf("under FTableControl") != -1) || (tempCurrentTag.startsWith("JPanel under")))

        ) {
            ComponentReference.setOldConventionMode(false);
        }


        //abbot_ext_end
        try {
            return findInHierarchy(aFinder, 1);
        } catch (ComponentNotFoundException e) {
            throw e;
        } catch (MultipleComponentsFoundException e) {
            throw e;
        } finally {
            ComponentReference.setOldConventionMode(tempCurrentConventionMode);
        }
    }

    //abbot_ext_begin
    boolean tagAlreadyTranslatedFromJava5toJava6 = false;

    //abbot_ext_end

    private Component findInHierarchy(ComponentFinder aFinder, int weight) throws ComponentNotFoundException,
            MultipleComponentsFoundException {
        Component match = null;
        Log.debug("Looking for " + toXMLString() + " minimum weight " + weight);

        Collection<Component> set = new HashSet<Component>();
        if (cachedLookup != null) {
            match = cachedLookup.get();
            if (match != null && !aFinder.isFiltered(match)) {
                if (match.isShowing()) {
                    Log.debug("Using cached lookup");
                    return match;
                }
                set.add(match);
            }
            cachedLookup = null;
        }

        //abbot_ext_begin
        // execute translation from java5 to java6 only if system is running under java6 and only once

        if (System.getProperty("java.version").startsWith("1.6")) {
            if (!tagAlreadyTranslatedFromJava5toJava6) {
                String tTag = getAttribute(TAG_TAG);
                if (tTag != null && tTag.indexOf("GChoiceControl$2") > -1) {
                    tTag = tTag.replace("GChoiceControl$2", "GChoiceControl$3");
                    setAttribute(TAG_TAG, tTag);
                }
                tagAlreadyTranslatedFromJava5toJava6 = true;
            }
        }
        //abbot_ext_end

        weight = findMatchesInHierarchy(aFinder, set, null, weight);
        Log.debug("Found " + set.size() + " matches");


        //abbot_ext_begin: Behandlung des neuen FTableControls von Daniel Schneller
        //TODO kann wieder herausgenommen werden, sobald alle Skripte umgestellt sind

        if (!ExtendedScriptEditor.getLastInstantiatedEditor().isRecording()) {
            String tempOriginalTag = getAttribute(Tags.TAG_TAG);
            String tempCRESMsg = "CRES: GIndexedCollectionControl$ListArea in Script: ";
            if (resolver instanceof Script) {
                Script tScript = (Script)resolver;
                tempCRESMsg += tScript.getDescription();
            } else if (resolver != null) {
                tempCRESMsg += "<unbekannter Typ> (" + resolver.toString() + ")";
            } else {
                tempCRESMsg += "null";
            }

            try {
                if ((set.size() != 1)
                    && (tempOriginalTag != null)
                    && (tempOriginalTag.startsWith("GIndexedCollectionControl$ListArea"))) {
                    String tempNewFTableListAreaName =
                            tempOriginalTag.replace("GIndexedCollectionControl$ListArea",
                                                    "FTableControl$ListAreaOhneCache");
                    setAttribute(Tags.TAG_TAG, tempNewFTableListAreaName);
                    Component newMatch = findInHierarchy(aFinder, weight);

                    if (newMatch != null) {
                        logger.warn("Ausgetauscht: " + tempCRESMsg);
                        return newMatch;
                    } else {
                        logger.warn("Nicht ausgetauscht: " + tempCRESMsg);
                        setAttribute(Tags.TAG_TAG, tempOriginalTag);
                    }
                }
            } catch (Exception e) {
                logger.warn("Nicht ausgetauscht: " + tempCRESMsg);
                setAttribute(Tags.TAG_TAG, tempOriginalTag);
            }
        }
        //abbot_ext_end

        if (set.size() == 1) {
            match = set.iterator().next();

        } else if (set.size() > 0) {
            // Distinguish between more than one match with the exact same
            // weight 
            match = bestMatch(set);
        }
        if (match == null) {
            String msg = "No component found which matches " + toXMLString();
            throw new ComponentNotFoundException(msg);
        }
        // This provides significant speedup when many similar components are
        // in play.
        cachedLookup = new WeakReference<Component>(match);
        return match;
    }

    /** Return the the set of all components under the given component's
     * hierarchy (inclusive) which match the given reference.
     */
    private int findMatchesInHierarchy(ComponentFinder aFinder, Collection<Component> currentSet, Component ancestor,
            int currentMaxWeight) {

        if (Log.isClassDebugEnabled(ComponentReference.class)) Log.debug("Scanning " + Robot.toString(ancestor));
        if (aFinder.isFiltered(ancestor)) {
            return currentMaxWeight;
        }

        if (ancestor == null) {
            // Examine all top-level components and their owned windows.
            Window[] windows = aFinder.getRootWindows();
            for (int f = 0; f < windows.length; f++) {
                currentMaxWeight = findMatchesInHierarchy(aFinder, currentSet, windows[f], currentMaxWeight);
            }
            return currentMaxWeight;
        }

        int weight = getMatchWeight(ancestor);
        if (weight > currentMaxWeight) {
            currentSet.clear();
            currentMaxWeight = weight;
            currentSet.add(ancestor);
        } else if (weight == currentMaxWeight) {
            currentSet.add(ancestor);
        }

        if (ancestor instanceof Container) {
            Component[] children = aFinder.getComponents((Container)ancestor);
            String title = getAttribute(TAG_TITLE);
            for (int i = 0; i < children.length; i++) {
                Component child = children[i];
                if (child instanceof Window) {
                    // Optimization:
                    // Skip this hierarchy if the frame titles don't match,
                    if (!((child instanceof Frame) || (child instanceof Dialog))
                        && ((title != null && !expressionMatch(title, aFinder.getComponentWindowTitle(child))))) {
                        if (Log.isClassDebugEnabled(ComponentReference.class))
                            Log.debug("Skipping window with wrong title " + Robot.toString(child));
                        continue;
                    }

                    // Skip this hierarchy if the window is not showing
                    if (!((Window)child).isShowing()) {
                        if (Log.isClassDebugEnabled(ComponentReference.class))
                            Log.debug("Skipping hidden window " + Robot.toString(child));
                        continue;
                    }
                }
                currentMaxWeight = findMatchesInHierarchy(aFinder, currentSet, child, currentMaxWeight);
            }
        }

        return currentMaxWeight;
    }

    private static Map<String, String> createAttributeMap(String[][] values) {
        Map<String, String> map = new TreeMap<String, String>();
        for (int i = 0; i < values.length; i++) {
            map.put(values[i][0], values[i][1]);
        }
        return map;
    }

    /** Since the horizontal ordering *must* be unique in order to be of any
        use, throw an exception if any two values are equal.
    */
    private static final Comparator<Component> HORDER_COMPARATOR = new Comparator<Component>() {

        @Override
        public int compare(Component o1, Component o2) {
            Component c1 = o1;
            Component c2 = o2;
            int x1 = -100000;
            int x2 = -100000;
            try {
                x1 = c1.getLocationOnScreen().x;
            } catch (Exception e) {}
            try {
                x2 = c2.getLocationOnScreen().x;
            } catch (Exception e) {}
            return x1 - x2;
        }
    };

    /** Since the vertical ordering *must* be unique in order to be of any
        use, throw an exception if any two values are equal.
    */
    private static final Comparator<Component> VORDER_COMPARATOR = new Comparator<Component>() {

        @Override
        public int compare(Component o1, Component o2) {
            Component c1 = o1;
            Component c2 = o2;
            int y1 = -100000;
            int y2 = -100000;
            try {
                y1 = c1.getLocationOnScreen().y;
            } catch (Exception e) {}
            try {
                y2 = c2.getLocationOnScreen().y;
            } catch (Exception e) {}
            return y1 - y2;
        }
    };

    /** @deprecated use getAttribute(TAG_NAME) instead. */
    @Deprecated
    public String getName() {
        return getAttribute(TAG_NAME);
    }

    /** @deprecated use getAttribute(TAG_TAG) instead. */
    @Deprecated
    public String getTag() {
        return getAttribute(TAG_TAG);
    }

    /** @deprecated use getAttribute(TAG_INVOKER) instead. */
    @Deprecated
    public String getInvokerID() {
        return getAttribute(TAG_INVOKER);
    }

    /** @deprecated use getAttribute(TAG_WINDOW) instead. */
    @Deprecated
    public String getWindowID() {
        return getAttribute(TAG_WINDOW);
    }

    /** @deprecated use getAttribute(TAG_TITLE) instead. */
    @Deprecated
    public String getTitle() {
        return getAttribute(TAG_TITLE);
    }

    /** @deprecated use getAttribute(TAG_INDEX) instead. */
    @Deprecated
    public int getIndex() {
        try {
            return Integer.parseInt(getAttribute(TAG_INDEX));
        } catch (Exception e) {
            return -1;
        }
    }


}
