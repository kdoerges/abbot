package abbot.script;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.IllegalComponentStateException;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import org.jdom2.CDATA;
import org.jdom2.Element;

import abbot.ComponentSearchException;
import abbot.Log;
import abbot.NoSuchReferenceException;
import abbot.Resolver;
import abbot.i18n.Strings;
import abbot.util.Properties;


/** Provides a method for communicating a message on the display.  May display
    for a reasonable delay or require user input to continue.<p>
    Usage:<br>
    <blockquote><code>
    &lt;annotation [userDismiss="true"] &gt;Text or HTML message&lt;/annotation&gt;<br>
    </code></blockquote>
    <p>
    Properties:<br>
    abbot.annotation.min_delay: minimum time to display an annotation<br>
    abbot.annotation.delay: per-word time to display an annotation<br>
 */

public class Annotation extends Step {

    private static final String TAG_ANNOTATION = "annotation";

    private static final String TAG_TITLE = "title";

    private static final String TAG_USER_DISMISS = "userDismiss";

    private static final String USAGE =
            "<annotation [title=\"...\"] [component=\"<component ID>\"] [x=XX y=YY] [width=WWW height=HHH] [userDismiss=\"true\"]>Text or HTML message</annotation>";

    private static final int WORD_SIZE = 6;

    private static final Color BACKGROUND = new Color((Color.yellow.getRed() + Color.white.getRed() * 3) / 4,
                                                      (Color.yellow.getGreen() + Color.white.getGreen() * 3) / 4,
                                                      (Color.yellow.getBlue() + Color.white.getBlue() * 3) / 4);

    private String title = null;

    private String componentID = null;

    private boolean userDismiss = false;

    private static int minDelay = 5000;

    private static int delayUnit = 250;

    private String text = "";

    private int x = -1;

    private int y = -1;

    private int width = -1;

    private int height = -1;

    private transient volatile AnnotationWindow window = null;

    private transient Point anchorPoint = null;

    static {
        minDelay = Properties.getProperty("abbot.annotation.min_delay", 0, 10000, minDelay);
        delayUnit = Properties.getProperty("abbot.annotation.delay_unit", 1, 5000, delayUnit);
    }

    public Annotation(Resolver resolver, Element el, Map attributes) throws InvalidScriptException {
        super(resolver, attributes);
        componentID = (String)attributes.get(TAG_COMPONENT);
        userDismiss = attributes.get(TAG_USER_DISMISS) != null;
        setTitle((String)attributes.get(TAG_TITLE));
        String xs = (String)attributes.get(TAG_X);
        String ys = (String)attributes.get(TAG_Y);
        if (xs != null && ys != null) {
            try {
                x = Integer.parseInt(xs);
                y = Integer.parseInt(ys);
            } catch (NumberFormatException nfe) {
                x = y = -1;
            }
        }
        String ws = (String)attributes.get(TAG_WIDTH);
        String hs = (String)attributes.get(TAG_HEIGHT);
        if (ws != null & hs != null) {
            try {
                width = Integer.parseInt(ws);
                height = Integer.parseInt(hs);
            } catch (NumberFormatException nfe) {
                width = height = -1;
            }
        }

        boolean cdataFound = false;
        Iterator iter = el.getContent().iterator();
        while (iter.hasNext()) {
            Object obj = iter.next();
            if (obj instanceof CDATA) {
                cdataFound = true;
                setText(((CDATA)obj).getText());
                break;
            }
        }
        if (!cdataFound) {
            setText(el.getText());
        }
    }

    public Annotation(Resolver resolver, String description) {
        super(resolver, description);
    }

    public boolean isShowing() {
        return window != null;
    }

    public void showAnnotation() {
        final Window win = getWindow();
        getFinder().filterComponent(win);
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                win.pack();
                Point where = null;
                if (anchorPoint != null) {
                    where = new Point(anchorPoint);
                }
                if (x != -1 && y != -1) {
                    if (where != null) {
                        where.x += x;
                        where.y += y;
                    } else {
                        where = new Point(x, y);
                    }
                }
                if (where != null) {
                    win.setLocation(where);
                }
                if (width != -1 && height != -1) {
                    win.setSize(new Dimension(width, height));
                }
                win.show();
            }
        });
    }

    public long getDelayTime() {
        long time = (getText().length() / WORD_SIZE) * delayUnit;
        return Math.max(time, minDelay);
    }

    /** Display a non-modal window. */
    @Override
    public void runStep() throws Throwable {
        showAnnotation();
        long start = System.currentTimeMillis();
        Log.debug("Waiting for " + getDelayTime() + "ms");
        while (window != null) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ie) {}
            if (!userDismiss) {
                long delta = System.currentTimeMillis() - start;
                if (delta > getDelayTime()) {
                    window.dispose();
                    window = null;
                }
            }
        }
    }

    private Window getWindow() {
        Component parent = null;
        if (window != null) {
            window.dispose();
            window = null;
        }
        anchorPoint = null;
        if (componentID != null) {
            try {
                parent = (Component)ArgumentParser.eval(getResolver(), componentID, Component.class);
                Point loc = parent.getLocationOnScreen();
                anchorPoint = new Point(loc.x, loc.y);
                while (!(parent instanceof Dialog) && !(parent instanceof Frame)) {
                    parent = parent.getParent();
                }
                window =
                        (parent instanceof Dialog) ? (title != null ? new AnnotationWindow((Dialog)parent, title)
                                : new AnnotationWindow((Dialog)parent)) : (title != null
                                ? new AnnotationWindow((Frame)parent, title) : new AnnotationWindow((Frame)parent));
            } catch (ComponentSearchException e) {
                // Ignore the exception and display it in global coords
                Log.warn(e);
            } catch (NoSuchReferenceException nsr) {
                // Ignore the exception and display it in global coords
                Log.warn(nsr);
            }
        }
        if (window == null) {
            window = (title != null) ? new AnnotationWindow(new Frame(), title) : new AnnotationWindow(new Frame());
        }
        JPanel pane = (JPanel)window.getContentPane();
        pane.setBackground(BACKGROUND);
        pane.setLayout(new BorderLayout());
        pane.setBorder(new EmptyBorder(4, 4, 4, 4));
        JLabel label = new JLabel(replaceNewlines(text));
        pane.add(label, BorderLayout.CENTER);
        if (userDismiss) {
            JPanel bottom = new JPanel(new BorderLayout());
            bottom.setBackground(BACKGROUND);
            JButton close = new JButton(Strings.get("Continue"));
            bottom.add(close, BorderLayout.EAST);
            close.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent ev) {
                    window.dispose();
                    window = null;
                }
            });
            pane.add(bottom, BorderLayout.SOUTH);
        }
        // If the user closes the window, make sure we continue execution
        window.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent we) {
                window.dispose();
                window = null;
            }
        });
        return window;
    }

    private String replaceNewlines(String text) {
        boolean needsHTML = false;
        String[] breaks = {"\r\n", "\n"};
        for (int i = 0; i < breaks.length; i++) {
            int index = text.indexOf(breaks[i]);
            while (index != -1) {
                needsHTML = true;
                text = text.substring(0, index) + "<br>" + text.substring(index + breaks[i].length());
                index = text.indexOf(breaks[i]);
            }
        }
        if (needsHTML && !text.startsWith("<html>")) {
            text = "<html>" + text + "</html>";
        }
        return text;
    }

    private void updateWindowSize(Window win) {
        if (window != win) return;
        Dimension size = win.getSize();
        width = size.width;
        height = size.height;
    }

    private void updateWindowPosition(Window win) {
        if (window != win) return;
        try {
            Point where = win.getLocationOnScreen();
            Log.debug("Position is now " + where);
            x = where.x;
            y = where.y;
            if (anchorPoint != null) {
                // Update the window location
                x -= anchorPoint.x;
                y -= anchorPoint.y;
            }
        } catch (IllegalComponentStateException e) {
            // Ignore it, the window is not visible
        }
    }

    @Override
    protected String getDefaultDescription() {
        String desc = "Annotation";
        if (!"".equals(getText())) {
            desc += ": " + getText();
        }
        return desc;
    }

    @Override
    public String getUsage() {
        return USAGE;
    }

    @Override
    public String getXMLTag() {
        return TAG_ANNOTATION;
    }

    @Override
    protected Element addContent(Element el) {
        return el.addContent(new CDATA(text));
    }

    @Override
    public Map getAttributes() {
        Map map = super.getAttributes();
        if (componentID != null) {
            map.put(TAG_COMPONENT, componentID);
        }
        if (userDismiss) {
            map.put(TAG_USER_DISMISS, "true");
        }
        if (title != null) {
            map.put(TAG_TITLE, title);
        }
        if (x != -1 || y != -1) {
            map.put(TAG_X, String.valueOf(x));
            map.put(TAG_Y, String.valueOf(y));
        }
        if (width != -1 || height != -1) {
            map.put(TAG_WIDTH, String.valueOf(width));
            map.put(TAG_HEIGHT, String.valueOf(height));
        }
        return map;
    }

    public boolean getUserDismiss() {
        return userDismiss;
    }

    public void setUserDismiss(boolean state) {
        userDismiss = state;
    }

    public String getRelativeTo() {
        return componentID;
    }

    public void setRelativeTo(String id) {
        componentID = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setDisplayLocation(Point pt) {
        if (pt != null) {
            x = pt.x;
            y = pt.y;
        } else {
            x = y = -1;
        }
    }

    public Point getDisplayLocation() {
        if (x != -1 || y != -1) return new Point(x, y);
        return null;
    }

    private class AnnotationWindow extends JDialog {

        public AnnotationWindow(Dialog parent, String title) {
            super(parent, title);
            addListener();
        }

        public AnnotationWindow(Dialog parent) {
            super(parent);
            addListener();
        }

        public AnnotationWindow(Frame parent, String title) {
            super(parent, title);
            addListener();
        }

        public AnnotationWindow(Frame parent) {
            super(parent);
            addListener();
        }

        // FIXME don't add listener until after the window is visible
        // otherwise we get extra resize/move events
        private void addListener() {
            addComponentListener(new ComponentAdapter() {

                @Override
                public void componentResized(ComponentEvent ce) {
                    updateWindowSize(AnnotationWindow.this);
                }

                @Override
                public void componentMoved(ComponentEvent ce) {
                    updateWindowPosition(AnnotationWindow.this);
                }
            });
        }
    }
}
