package abbot.script;

import java.awt.Component;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import abbot.*;
import abbot.script.parsers.Parser;
import abbot.tester.ComponentTester;
import abbot.tester.Robot;
import extensions.util.AbbotI18NUtil;


/** Provide parsing of a String into an array of appropriately typed
 * arguments.   Arrays are indicated by square brackets, and arguments are
 * separated by commas, e.g.<br>
 * An empty String array (length zero): "[]"<br>
 * Three arguments "one,two,three"<br>
 * An array of three arguments, with embedded comma: "[one\,one,two,three]"<br>
 * An argument with square brackets: "\[one\]"<br>
 * A single null argument: "null"<br>
 */

public class ArgumentParser {

    private ArgumentParser() {}

    private static final String ESC_COMMA = "--ESCAPED-COMMA--";

    private static final String ESC_LB = "--ESCAPED-LB--";

    private static final String ESC_RB = "--ESCAPED-RB--";

    /** Maps class names to their corresponding string parsers. */
    private static Map<Class, Parser> parsers = new HashMap<Class, Parser>();

    private static boolean isExtension(String name) {
        return name.indexOf(".extensions.") != -1;
    }

    private static Parser findParser(String name, Class targetClass) {
        Log.debug("Trying " + name + " for " + targetClass);
        try {
            Class cvtClass =
                    isExtension(name) ? Class.forName(name, true, targetClass.getClassLoader()) : Class.forName(name);
            Parser parser = (Parser)cvtClass.newInstance();
            if (cvtClass.getName().indexOf(".extensions.") == -1) parsers.put(targetClass, parser);
            return parser;
        } catch (InstantiationException ie) {
            Log.debug(ie);
        } catch (IllegalAccessException iae) {
            Log.debug(iae);
        } catch (ClassNotFoundException cnf) {
            Log.debug(cnf);
        }
        return null;
    }

    /** Set the parser for a given class.  Returns the old one, if any. */
    public static Parser setParser(Class cls, Parser parser) {
        Parser old = parsers.get(cls);
        parsers.put(cls, parser);
        return old;
    }

    /** Find a string parser for the given class.  Returns null if none
     * found.
     */
    public static Parser getParser(Class cls) {
        Parser parser = parsers.get(cls);
        // Load core testers with the current framework's class loader
        // context, and anything else in the context of the code under test
        if (parser == null) {
            String base = ComponentTester.simpleClassName(cls);
            String pkg = Parser.class.getPackage().getName();
            parser = findParser(pkg + "." + base + "Parser", cls);
            if (parser == null) {
                parser = findParser(pkg + ".extensions." + base + "Parser", cls);
            }
        }
        return parser;
    }

    /** Convert the given encoded String into an array of Strings.
     * Interprets strings of the format "[el1,el2,el3]" to be a single (array)
     * argument. <p>
     * Explicit commas and square brackets in arguments must be escaped by
     * preceding the character with a backslash ('\').  The strings
     * '(null)' and 'null' are interpreted as the value null.<p>
     * Explicit spaces should be protected by double quotes, e.g.
     * " an argument bounded by spaces ".
     */
    public static String[] parseArgumentList(String encodedArgs) {
        ArrayList<String> alist = new ArrayList<String>();
        if (encodedArgs == null || "".equals(encodedArgs)) return new String[0];
        encodedArgs = replace(encodedArgs, "\\,", ESC_COMMA);
        encodedArgs = replace(encodedArgs, "\\[", ESC_LB);
        encodedArgs = replace(encodedArgs, "\\]", ESC_RB);
        StringTokenizer st = new StringTokenizer(encodedArgs, ",");
        while (st.hasMoreTokens()) {
            String str = st.nextToken().trim();

            if ("\"\"".equals(str)) {
                str = "";
            } else if (str.startsWith("[")) {
                int openBracketCount = 1;
                if (str.endsWith("]")) {
                    --openBracketCount;
                } else
                    while (st.hasMoreTokens() && openBracketCount != 0) {
                        String next = st.nextToken().trim();
                        if (next.startsWith("[") && !next.endsWith("\\[")) {
                            ++openBracketCount;
                        } else if (next.endsWith("]") && !next.endsWith("\\]")) {
                            --openBracketCount;
                        }
                        str += "," + next;
                    }
                if (openBracketCount != 0) {
                    String msg = "Unterminated array '" + str + "'";
                    throw new IllegalArgumentException(msg);
                }
            }
            if ((str.startsWith("\"") && str.endsWith("\"")) || (str.startsWith("'") && str.endsWith("'"))) {
                str = str.substring(1, str.length() - 1);
            }

            // FIXME what if we want a string argument of "(null)/null"?
            if ("null".equals(str) || "(null)".equals(str)) {
                alist.add(null);
            } else {
                if (str.startsWith("[")) {
                    str = replace(str, ESC_COMMA, "\\,");
                    str = replace(str, ESC_RB, "\\]");
                    str = replace(str, ESC_LB, "\\[");
                } else {
                    str = replace(str, ESC_COMMA, ",");
                    str = replace(str, ESC_RB, "]");
                    str = replace(str, ESC_LB, "[");
                }
                alist.add(str);
            }
        }
        return alist.toArray(new String[alist.size()]);
    }

    private static ComponentTester tester = ComponentTester.getTester(Component.class);

    /** Performs property substitutions on the argument priort to evaluating
     * it.  Substitutions are not recursive. 
     */
    public static String substitute(Resolver resolver, String arg) {
        int i = 0;
        int marker = 0;
        StringBuffer sb = new StringBuffer();
        while ((i = arg.indexOf("${", marker)) != -1) {
            if (marker < i) {
                sb.append(arg.substring(marker, i));
                marker = i;
            }
            int end = arg.indexOf("}", i);
            if (end == -1) {
                break;
            }
            String name = arg.substring(i + 2, end);
            String value = resolver.getProperty(name);
            if (value == null) {
                value = System.getProperty(name);
            }
            if (value == null) {
                value = arg.substring(i, end + 1);
            }
            sb.append(value);
            marker = end + 1;
        }
        sb.append(arg.substring(marker));
        return sb.toString();
    }

    /** Convert the given string into the given class, if possible,
     * using any available parsers if conversion to basic types fails.
     * The Resolver could be a parser, but it would need to adapt
     * automatically to whatever is the current context.<p>
     * Performs property substitution on the argument prior to evaluating it.
     */
    public static Object eval(Resolver resolver, String arg, Class cls) throws IllegalArgumentException,
            NoSuchReferenceException, ComponentSearchException {

        // Preform property substitution
        arg = substitute(resolver, arg);

        Parser parser;
        Object result = null;
        try {
            if (arg == null) {
                result = null;
            } else if (cls.equals(Boolean.class) || cls.equals(boolean.class)) {
                result = Boolean.valueOf(arg);
            } else if (cls.equals(Short.class) || cls.equals(short.class)) {
                result = Short.valueOf(arg);
            } else if (cls.equals(Integer.class) || cls.equals(int.class)) {
                result = Integer.valueOf(arg);
            } else if (cls.equals(Long.class) || cls.equals(long.class)) {
                result = Long.valueOf(arg);
            } else if (cls.equals(Float.class) || cls.equals(float.class)) {
                result = Float.valueOf(arg);
            } else if (cls.equals(Double.class) || cls.equals(double.class)) {
                result = Double.valueOf(arg);
            } else if (cls.equals(ComponentReference.class)) {
                ComponentReference ref = resolver.getComponentReference(arg);
                if (ref == null)
                    throw new NoSuchReferenceException("The resolver " + resolver + " has no reference '" + arg + "'");
                result = ref;
            } else if (Component.class.isAssignableFrom(cls)) {
                ComponentReference ref = resolver.getComponentReference(arg);
                if (ref == null)
                    throw new NoSuchReferenceException("The resolver " + resolver + " has no reference '" + arg + "'");
                // Avoid requiring the user to wait for a component to become
                // available, in most cases.  In those cases where the
                // component creation is particularly slow, an explicit wait
                // can be added.
                // Note that this is not necessarily a wait for the component
                // to become visible, since menu items are not normally
                // visible even if they're available.
                result = waitForComponentAvailable(ref);
            } else if (cls.equals(String.class)) {
                result = unescapeBrackets(arg);
            } else if (cls.isArray() && arg.startsWith("[")) {
                String[] args = parseArgumentList(arg.substring(1, arg.length() - 1));
                Class base = cls.getComponentType();
                Object arr = Array.newInstance(base, args.length);
                for (int i = 0; i < args.length; i++) {
                    Object obj = eval(resolver, args[i], base);
                    Array.set(arr, i, obj);
                }
                result = arr;
            } else if ((parser = getParser(cls)) != null) {
                result = parser.parse(unescapeBrackets(arg));
            } else {
                String msg = "Can't convert '" + arg + "' into an instance of " + cls.getName();
                throw new IllegalArgumentException(msg);
            }
            return result;
        } catch (NumberFormatException nfe) {
            String msg = "Can't convert '" + arg + "' to " + cls.getName();
            throw new IllegalArgumentException(msg);
        }
    }

    /** Evaluate the given set of arguments into the given set of types. */
    public static Object[] eval(Resolver resolver, String[] args, Class[] params) throws IllegalArgumentException,
            NoSuchReferenceException, ComponentSearchException {
        Object[] plist = new Object[params.length];
        for (int i = 0; i < plist.length; i++) {
            String arg = args[i];
            plist[i] = eval(resolver, arg, params[i]);
        }
        return plist;
    }

    static String unescapeBrackets(String arg) {
        return replace(replace(arg, "\\[", "["), "\\]", "]");
    }

    /** Replace all instances in the given String of s1 with s2. */
    public static String replace(String str, String s1, String s2) {
        StringBuffer sb = new StringBuffer(str);
        int index = 0;
        while ((index = sb.toString().indexOf(s1, index)) != -1) {
            sb.delete(index, index + s1.length());
            sb.insert(index, s2);
            index += s2.length();
        }
        return sb.toString();
    }


    //abbot_ext_begin

    private static Component waitForComponentAvailable(final ComponentReference ref) throws ComponentSearchException {
        final ComponentFinder finder = DefaultComponentFinder.getFinder();

        try {
            tester.wait(new Condition() {

                public boolean test() {
                    AbbotI18NUtil.theInstance().setLastFoundComponent(null);
                    try {
                        Component tempFoundComponent = ref.findInHierarchy(finder);
                        AbbotI18NUtil.theInstance().setLastFoundComponent(tempFoundComponent);
                    } catch (ComponentNotFoundException e) {
                        return false;
                    } catch (MultipleComponentsFoundException m) {}
                    return true;
                }

                @Override
                public String toString() {
                    return ref + " to become available";
                }
            }, Robot.componentDelay);
        } catch (WaitTimedOutError wto) {
            String msg = "Could not find " + ref + ": " + Step.toXMLString(ref);
            throw new ComponentNotFoundException(msg);
        }


        Component tempFoundComponent = AbbotI18NUtil.theInstance().getLastFoundComponent();

        if (tempFoundComponent == null) {
            throw new ComponentNotFoundException("Component not available: " + ref.toString());
        }

        // Falls gew�nscht, wird die Referenz I18N-f�hig gemacht
        if ((tempFoundComponent != null) && (AbbotI18NUtil.theInstance().getPerformI18NConversion())) {
            Component tempRealComponent = AbbotI18NUtil.theInstance().checkI18N(tempFoundComponent, ref);
            return tempRealComponent;
        }

        else {
            return tempFoundComponent;
        }
    }

    //abbot_ext_end

}
