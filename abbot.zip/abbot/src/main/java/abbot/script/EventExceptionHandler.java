package abbot.script;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import abbot.ExitException;
import abbot.Log;
import abbot.util.EventDispatchExceptionHandler;


public class EventExceptionHandler extends EventDispatchExceptionHandler {

	private static final Logger logger = LoggerFactory.getLogger(EventExceptionHandler.class); 
	
    @Override
    protected void exceptionCaught(Throwable thr) {
        if (thr.getClass().getName().equals(ExitException.class.getName())) {
            Log.warn("Application attempted exit from the event " + "dispatch thread, ignoring it", thr);
        } else if (thr instanceof NullPointerException
                   && Log.getStack(Log.FULL_STACK, thr).indexOf("createHierarchyEvents") != -1) {
            // java 1.3 hierarchy listener bug, most likely
            Log.debug("Apparent hierarchy NPE bug:\n" + Log.getStack(Log.FULL_STACK, thr));
        } else {
            logger.error("Unexpected exception while dispatching events:", thr);
        }
    }
}
