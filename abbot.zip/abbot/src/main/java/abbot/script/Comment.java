package abbot.script;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.jdom2.Element;

import testframework.testrunner.RTVariablesSingleton;
import abbot.Resolver;

import com.obi.test.tregs.abbot.component.AbbotProperties;

import extensions.system.AbbotService;


/** Represents a comment.  No other function. */
public class Comment extends Step {


    private static final String USAGE = "<!-- [text] -->";

    public Comment(Resolver resolver, Map<String, String> attributes) {
        super(resolver, attributes);
    }

    public Comment(Resolver resolver, String description) {
        super(resolver, description);
    }

    /** Default to whitespace. */
    @Override
    public String getDefaultDescription() {
        return "";
    }

    @Override
    public String toString() {
        return "# " + getDescription();
    }

    @Override
    public String getUsage() {
        return USAGE;
    }

    /** This is only used to generate the title label for the editor. */
    @Override
    public String getXMLTag() {
        return TAG_COMMENT;
    }

    @Override
    public Element toXML() {
        throw new RuntimeException("Comments are not elements");
    }

    /** Main run step. 
     * @throws Throwable*/
    @Override
    protected void runStep() throws Throwable {

        /* abbot_ext begin */


        if (getDescription().startsWith(AbbotService.PRINTDIALOG_COMMENT)) {
            int index = getDescription().indexOf('=');
            if (index != -1) {
                String value = getDescription().substring(index + 1);
                boolean print = true;
                if (value.equalsIgnoreCase("cancel")) {
                    print = false;
                }

                AbbotService.processWindowsPrintDialog(this.getResolver(), print);
                return;

            }

        }

        if (getDescription().startsWith(AbbotService.SETVARIABLE_COMMENT)) {

            List<String> varNameAndValueList = getSetVariableNameAndValue();
            if (varNameAndValueList != null) {
                String key = varNameAndValueList.get(0);
                String value = varNameAndValueList.get(1);
                RTVariablesSingleton.theInstance().setVariable(key, value);
            }

            return;

        }


        if (getDescription().startsWith(AbbotService.LOADVARIABLES_COMMENT)) {
            int index = getDescription().indexOf('=');
            if (index != -1) {
                String varFilename = getDescription().substring(index + 1);
                RTVariablesSingleton.theInstance().load(varFilename, true);
            }

            return;
        }


        // Sorgt daf�r, dass Screenshots gemacht werden
        if (makeScreenshot()) {
            AbbotService.makeScreenshot((Script)getResolver(), this);
        }
        /* abbot_ext end */

    }


    public List<String> getSetVariableNameAndValue() {
        int index = getDescription().indexOf(' ');
        if (index != -1) {
            String keyValuePair = getDescription().substring(index + 1);

            int indexAssign = keyValuePair.indexOf('=');

            String key = keyValuePair.substring(0, indexAssign);
            String value = keyValuePair.substring(indexAssign + 1);

            List<String> result = new ArrayList<String>();
            result.add(key);
            result.add(value);

            return result;


        } else {
            return null;
        }

    }


    /**
     * Liefert true zur�ck, falls ein Screenshot durchgef�hrt werden soll
     */
    protected boolean makeScreenshot() {


        return AbbotProperties.theInstance().getMakeScreenshots();

    }

    /**
     * Liefert true zur�ck, falls es sich um einen ausf�hbaren Kommentar handelt
     */
    public boolean isExecutable() {

        if (isSetVariableComment()) {
            return true;
        }

        if (isLoadVariablesComment()) {
            return true;
        }

        return false;
    }

    /**
     * Liefert true zur�ck, falls es sich um Kommentar zum Setzen einer Variablen handelt
     */
    public boolean isSetVariableComment() {

        String descr = getDescription();

        boolean isSetVariableComment = (descr.startsWith(AbbotService.SETVARIABLE_COMMENT));
        return isSetVariableComment;
    }


    /**
     * Liefert true zur�ck, falls es sich um Kommentar zum Laden einer Variablenbelegung handelt
     */
    public boolean isLoadVariablesComment() {

        String descr = getDescription();

        boolean isLoadVariablesComment = (descr.startsWith(AbbotService.LOADVARIABLES_COMMENT));
        return isLoadVariablesComment;
    }


}
