package abbot.script;

import java.util.Map;

import abbot.Resolver;

import com.obi.test.tregs.abbot.component.AbbotProperties;

import extensions.docgenerator.DocumentText;
import extensions.docgenerator.MessageText;


/* abbot_ext begin */


/* abbot_ext end */

/** Encapsulate capture of a value.  Usage:<br>
 * <blockquote><code>
 * &lt;sample property="..." method="assertXXX" [class="..."]&gt;<br>
 * &lt;sample property="..." method="(get|is|has)XXX" component="component_id"&gt;<br>
 * </code></blockquote>
 * The <b>sample</b> step stores the value found from the given method
 * <a href="{@docRoot}/abbot/tester/ComponentTester.html">ComponentTester</a>
 * class; the class tag is required for methods based on a class derived from
 * ComponentTester; the class tag indicates the Component class, not hte
 * Tester class (teh appropriate tester class will be derived automatically).
 * The second format indicates a property sample on the given component.
 * In both cases, the result of the invocation will be saved in the current
 * Resolver as a property with the given property name.
 */

public class Sample extends PropertyCall {

    private static final String USAGE = "<sample property=... component=... method=.../>\n"
                                        + "<sample property=... method=... [class=...]/>";

    private String propertyName = null;

    public Sample(Resolver resolver, Map<String, String> attributes) {
        super(resolver, attributes);
        propertyName = attributes.get(TAG_PROPERTY);
    }

    /** Component property sample. */
    public Sample(Resolver resolver, String description, String methodName, String[] args, String id, String propName) {
        super(resolver, description, methodName, args, id);
        propertyName = propName;
    }

    /** Static method property sample. */
    public Sample(Resolver resolver, String description, String className, String methodName, String[] args,
            String propName) {
        super(resolver, description, className, methodName, args);
        propertyName = propName;
    }

    /**
     * @SuppressWarnings("unchecked") kann man wohl nicht machen, kommt aus Abbot selbst
     * {@inheritDoc}
     * @see abbot.script.PropertyCall#getAttributes()
     */
    @Override
    @SuppressWarnings("unchecked")
    public Map<String, String> getAttributes() {
        Map<String, String> map = super.getAttributes();
        if (propertyName != null) {
            map.put(TAG_PROPERTY, propertyName);
        }
        return map;
    }

    @Override
    protected String getDefaultDescription() {

        /* abbot_ext begin */
        if (AbbotProperties.theInstance().getUseStepDescription()) {
            String udgDesc = DocumentText.getInstance().getDescriptionForSample(this);
            if (!MessageText.getInstance().isWarning(udgDesc)) {
                return udgDesc;
            } else {
                return (getPropertyName() + "=" + super.getDefaultDescription() + " " + udgDesc);
            }
        }
        ;
        /* abbot_ext end */

        return getPropertyName() + "=" + super.getDefaultDescription();
    }

    @Override
    public String getUsage() {
        return USAGE;
    }

    @Override
    public String getXMLTag() {
        return TAG_SAMPLE;
    }

    public void setPropertyName(String name) {
        propertyName = name;
    }

    public String getPropertyName() {
        return propertyName;
    }

    /** Store the results of the invocation in the designated property. */
    @Override
    protected Object invoke() throws Throwable {
        Object obj = super.invoke();
        if (propertyName != null) {
            // FIXME string-encode arrays
            String value = obj == null ? "(null)" : obj.toString();
            getResolver().setProperty(propertyName, value);
        }
        return obj;
    }


}
