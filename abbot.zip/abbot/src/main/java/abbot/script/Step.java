package abbot.script;

import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.text.MessageFormat;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.XMLOutputter;

import abbot.*;
import abbot.i18n.Strings;
import abbot.tester.ComponentTester;

import com.obi.test.tregs.abbot.component.AbbotProperties;

import extensions.util.TRENDGUIControlUtil;


/* abbot_ext end */

/**
 * Provides access to one step (line) from a script.  A Step is the basic
 * unit of execution.  All derived classes should have a tag "sampleStep" with 
 * a corresponding class abbot.script.SampleStep.  The class must supply at
 * least a Constructor with the signature SampleStep(Resolver, Map).  If
 * the step has contents (e.g. Sequence), then it should also provide
 * SampleStep(Resolver, Element, Map).
 */
public abstract class Step implements Tags, XMLifiable, Serializable {

    private String description = null;

    private Resolver resolver;

    /** Error encountered on parse. */
    private Throwable invalidScriptError = null;

    /* abbot_ext begin */
    private long execTime = 0;

    /* abbot_ext end */

    public Step(Resolver resolver, Map<String, String> attributes) {
        this(resolver, "");
        Log.debug("Instantiating " + getClass());
        if (Log.expectDebugOutput) {
            Iterator<String> iter = attributes.keySet().iterator();
            while (iter.hasNext()) {
                String key = iter.next();
                Log.debug(key + "=" + attributes.get(key));
            }
        }
        parseStepAttributes(attributes);
    }

    public Step(Resolver resolver, String description) {
        // Kind of a hack; a Script is its own resolver
        if (resolver == null) {
            if (!(this instanceof Resolver)) {
                throw new Error("Resolver must be provided");
            }
            resolver = (Resolver)this;
        } else if (this instanceof Resolver) {
            resolver = (Resolver)this;
        }
        this.resolver = resolver;
        if ("".equals(description)) description = null;
        this.description = description;
    }

    /* abbot_ext begin */

    /**
     * Liefert ggf. den Fehler zur�ck, der bspw. beim Parsen des Skriptes aufgetreten ist
     */
    public Throwable getScriptError() {
        return invalidScriptError;
    }

    /* abbot_ext begin */

    public void setExecutionTime(long t) {
        this.execTime = t;
    }

    public long getExecutionTime() {
        return this.execTime;
    }

    /* abbot_ext end */

    protected final void parseStepAttributes(Map<String, String> attributes) {
        Log.debug("Parsing attributes for " + getClass());
        description = attributes.get(TAG_DESC);
    }

    /** Main run method.  Should <b>never</b> be run on the event dispatch
     * thread, although no check is explicitly done here.
     */
    public final void run() throws Throwable {
        if (invalidScriptError != null) throw invalidScriptError;
        Log.debug("Running " + toString());
        runStep();
    }

    /** Implement the step's behavior here. */
    protected abstract void runStep() throws Throwable;

    public String getDescription() {
        /* abbot_ext begin */
        String desc = "";

        if (description != null) {
            if ((AbbotProperties.theInstance().getPerformanceLogSupport())
                & ((this instanceof Sequence) | (this instanceof Call))
                & (!(this instanceof Launch))
                & (!(this instanceof Script))) {
                desc = ("[" + ((new Long(this.getExecutionTime())).floatValue() / 1000) + " s] " + description);
            } else {
                desc = description;
            }
        } else {
            if ((AbbotProperties.theInstance().getPerformanceLogSupport())
                & ((this instanceof Sequence) | (this instanceof Call))
                & (!(this instanceof Launch))
                & (!(this instanceof Script))) {
                desc =
                        ("[" + ((new Long(this.getExecutionTime())).floatValue() / 1000) + " s] " + getDefaultDescription());
            } else {
                desc = getDefaultDescription();
            }
        }

        return desc;
        /* abbot_ext end */
    }

    public void setDescription(String desc) {
        description = desc;
    }

    /** Define the XML tag to use for this script step. */
    public abstract String getXMLTag();

    /** Provide a usage String for this step. */
    public abstract String getUsage();

    /** Return a reasonable default description for this script step.
        This value is used in the absence of an explicit description. 
     */
    protected abstract String getDefaultDescription();

    /** For use by subclasses when an error is encountered during parsing. 
     * Should only be used by the XML parsing ctors.
     */
    protected void setScriptError(Throwable thr) {
        if (invalidScriptError == null) {
            invalidScriptError = thr;
        } else {
            /* abbot_ext begin */
            String tempDescription = "";
            Resolver tempResolver = getResolver();
            if ((tempResolver != null) && (tempResolver instanceof Script)) {
                tempDescription =
                        tempDescription
                                + "Script: "
                                + ((Script)tempResolver).getName()
                                + " ("
                                + ((Script)tempResolver).getFilename()
                                + ") \r\n";
            }

            tempDescription = tempDescription + "Step: " + getDefaultDescription() + "; " + getBaseDescription();

            Log.warn(tempDescription);
            /* abbot_ext begin */

            Log.warn("More than one script error encountered: " + thr);
            Log.warn("Already have: " + invalidScriptError);
        }
    }

    /** Throw an invalid script exception describing the proper script
     * usage.  This should be used by derived classes whenever parsing
     * indicates invalid input.
     */
    protected void usage() {
        usage(null);
    }

    /** Store an invalid script exception describing the proper script
     * usage.  This should be used by derived classes whenever parsing
     * indicates invalid input.  
     */
    protected void usage(String details) {
        String msg = getUsage();
        if (details != null) {
            MessageFormat mf = new MessageFormat(Strings.get("UsageDetails"));
            msg = mf.format(new Object[] {msg, details});
        }
        setScriptError(new InvalidScriptException(msg));
    }

    /** Attributes to save in script. */
    public Map<String, String> getAttributes() {

        Map<String, String> map = new TreeMap<String, String>();
        if (description != null)
        /* abbot_ext begin */
        // auskommentiert, da ansonsten die manuell eingegebene Description
        // zu einer Action nicht im XML-File abgespeichert wurde
        // Ist aber nochmal zu �berpr�fen !
        //            && !description.equals(getDefaultDescription()))
            /* abbot_ext end */
            map.put(TAG_DESC, description);
        return map;
    }

    /** Resolve the given name into a component. */
    protected java.awt.Component resolve(String name) throws NoSuchReferenceException, ComponentNotFoundException,
            MultipleComponentsFoundException {
        ComponentReference ref = resolver.getComponentReference(name);
        if (ref != null) {
            return getFinder().findComponent(ref);
        }
        throw new NoSuchReferenceException(name);
    }

    public ComponentFinder getFinder() {
        return DefaultComponentFinder.getFinder();
    }

    public Resolver getResolver() {
        return resolver;
    }

    /** Override if the step actually has some contents.  In most cases, it
     * won't.
     */
    protected Element addContent(Element el) {
        return el;
    }

    protected Element addAttributes(Element el) {
        Map<String, String> atts = getAttributes();
        Iterator<String> iter = atts.keySet().iterator();
        while (iter.hasNext()) {
            String key = iter.next();
            String value = atts.get(key);
            el.setAttribute(key, value);
        }
        return el;
    }

    @Override
    public String toEditableString() {
        return toXMLString(this);
    }

    /** Provide a one-line XML string representation. */
    public static String toXMLString(XMLifiable obj) {
        // Comments are the only things that aren't actually elements...
        if (obj instanceof Comment) {
            return "<!-- " + ((Comment)obj).getDescription() + " -->";
        }
        Element el = obj.toXML();
        StringWriter writer = new StringWriter();
        try {
            XMLOutputter outputter = new XMLOutputter();
            outputter.output(el, writer);
        } catch (IOException io) {
            Log.warn(io);
        }
        return writer.toString();
    }

    /** Convert the object to XML.  */
    @Override
    public Element toXML() {
        return addAttributes(addContent(new Element(getXMLTag())));
    }

    /** Create a new step from an in-line XML string. */
    public static Step createStep(Resolver resolver, String str) throws InvalidScriptException {
        StringReader reader = new StringReader(str);
        try {
            SAXBuilder builder = new SAXBuilder();
            Document doc;

            //abbot_ext_begin
            // ge�ndert f�r jdom 1.1.1
            try {
                doc = builder.build(reader);
            } catch (IOException e) {
                throw new InvalidScriptException(e.toString());
            }
            //abbot_ext_end
            Element el = doc.getRootElement();
            return createStep(resolver, el);
        } catch (JDOMException e) {
            throw new InvalidScriptException(e.getMessage());
        }
    }

    /**
     * @SuppressWarnings("unchecked") Das Verhalten von Element.getAttributes() k�nnen wir nicht �ndern
     * @param el
     * @return
     */
    @SuppressWarnings("unchecked")
    protected static Map<String, String> createAttributeMap(Element el) {
        Log.debug("Creating attribute map for " + el);
        Map<String, String> attributes = new TreeMap<String, String>();
        Iterator<Attribute> iter = el.getAttributes().iterator();
        while (iter.hasNext()) {
            Attribute att = iter.next();
            attributes.put(att.getName(), att.getValue());
        }
        return attributes;
    }

    /**
     * Factory method, equivalent to a "fromXML" for step creation.  Looks for
     * a class with the same name as the XML tag, with the first letter
     * capitalized.  For example, &lt;call /&gt; is abbot.script.Call.
     */
    public static Step createStep(Resolver resolver, Element el) throws InvalidScriptException {
        String tag = el.getName();
        Map<String, String> attributes = createAttributeMap(el);
        String name = tag.substring(0, 1).toUpperCase() + tag.substring(1);
        if (tag.equals(TAG_WAIT)) {
            attributes.put(TAG_WAIT, "true");
            name = "Assert";
        }
        try {
            name = "abbot.script." + name;
            Log.debug("Instantiating " + name);
            Class cls = Class.forName(name, true, Thread.currentThread().getContextClassLoader());
            try {
                // Steps with contents require access to the XML element
                Class[] argTypes = new Class[] {Resolver.class, Element.class, Map.class};
                Constructor ctor = cls.getConstructor(argTypes);
                return (Step)ctor.newInstance(new Object[] {resolver, el, attributes});
            } catch (NoSuchMethodException nsm) {
                // All steps must support this ctor
                Class[] argTypes = new Class[] {Resolver.class, Map.class};
                Constructor ctor = cls.getConstructor(argTypes);
                return (Step)ctor.newInstance(new Object[] {resolver, attributes});
            }
        } catch (ClassNotFoundException cnf) {
            MessageFormat mf = new MessageFormat(Strings.get("UnknownTag"));
            throw new InvalidScriptException(mf.format(new Object[] {tag}));
        } catch (InvocationTargetException ite) {
            throw new InvalidScriptException(ite.getTargetException().getMessage());
        } catch (Exception exc) {
            throw new InvalidScriptException(exc.getMessage());
        }
    }

    protected String simpleClassName(Class cls) {
        return ComponentTester.simpleClassName(cls);
    }

    /** Return a description of this script step. */
    @Override
    public String toString() {
        return getDescription();
    }

    /** Returns the Class corresponding to the given class name.  Provides
     * just-in-time classname resolution to ensure loading by the proper class
     * loader. <p>
     * NOTE: only works if the app under test has already been launched.
     */
    public Class resolveClass(String className) throws InvalidScriptException {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        try {
            return Class.forName(className, true, cl);
        } catch (ClassNotFoundException cnf) {
            // Unrecoverable; script must be fixed
            MessageFormat mf = new MessageFormat(Strings.get("ClassNotFound"));
            throw new InvalidScriptException(mf.format(new Object[] {className}));
        }
    }

    /** Look up an appropriate ComponentTester given an arbitrary class.
     * If the class is derived from abbot.tester.ComponentTester, instantiate
     * one; if it is derived from java.awt.Component, return a matching Tester.
     * Otherwise return abbot.tester.ComponentTester.<p>
     * The class is looked up based on the appropriate context for the Step.
     */
    protected ComponentTester resolveTester(String compClassName) throws InvalidScriptException {

        /* abbot_ext_begin */

        // Die TREND-Control haben eigene Tester
        ComponentTester tempTRENDComponentTester =
                TRENDGUIControlUtil.theInstance().getTRENDComponentTester(compClassName);

        if (tempTRENDComponentTester != null) {
            return tempTRENDComponentTester;
        }


        /* abbot_ext_end */


        Class testedClass = resolveClass(compClassName);
        ComponentTester tester = ComponentTester.getTester(java.awt.Component.class);
        if (ComponentTester.class.isAssignableFrom(testedClass)) {
            try {
                tester = (ComponentTester)testedClass.newInstance();
            } catch (Exception e) {
                throw new InvalidScriptException(e.getMessage());
            }
        } else if (java.awt.Component.class.isAssignableFrom(testedClass)) {
            tester = ComponentTester.getTester(testedClass);
        }
        Log.debug("Tester for "
                  + testedClass.getName()
                  + " is "
                  + tester.getClass()
                  + " ("
                  + tester.getClass().getClassLoader()
                  + ")");
        return tester;
    }

    private void writeObject(ObjectOutputStream out) throws IOException {
        // NOTE: this is only to avoid drag/drop errors
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        // NOTE: this is only to avoid drag/drop errors
    }


    /* abbot_ext begin */
    /* Return the value of the attribute "desc". */
    public String getAttributeDesc() {
        return description;
    }


    public void setResolver(Resolver aResolver) {
        resolver = aResolver;
    }


    public String getBaseDescription() {
        return description;
    }
    /* abbot_ext end */


}
