package abbot.tester;

import java.awt.Component;

import javax.swing.JLabel;


public class JLabelTester extends JComponentTester {

    @Override
    public String deriveTag(Component comp) {
        String tag = stripHTML(((JLabel)comp).getText());
        if (tag == null || "".equals(tag)) {
            tag = super.deriveTag(comp);
        }
        return tag;
    }
}
