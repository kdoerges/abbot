package abbot.tester;

import java.awt.event.*;
import java.util.*;

import javax.swing.KeyStroke;

import abbot.Log;

/** Map characters to the keycodes (and modifiers) required to generate
 * them.<p>
 * FIXME OSX generates key_typed events for control and alt characters; other
 * platforms might as well, so there needs to be a keystroke map entry for
 * those characters.
 */ 

public class KeyStrokeMap {

    /** Map of Characters to keycode KeyStrokes. */
    // FIXME this is ugly, but I don't think java otherwise supports a mapping
    // unless we were to explicitly send all keycodes with all modifiers and
    // check the results, which takes a long time
    private static HashMap keycodes = generateKeyStrokeMappings();
    private static HashMap chars = generateCharMappings();

    /** No instantiations. */
    private KeyStrokeMap() { }

    /** Return the keycode-based KeyStroke corresponding to the given
     * character, as best we can guess it. 
     */
    public static KeyStroke getKeyStroke(char ch) {
        return (KeyStroke)keycodes.get(new Character(ch));
    }

    /** Given a keycode and modifiers, return the equivalent character.
     * Defined properly for US keyboards only.  Please contribute your own.
     */
    public static char getChar(KeyStroke ks) {
        Character ch = (Character)chars.get(ks);
        if (ch != null)
            return ch.charValue();
        return KeyEvent.CHAR_UNDEFINED;
    }

    private static HashMap generateCharMappings() {
        HashMap map = new HashMap();
        Iterator iter = keycodes.keySet().iterator();
        while (iter.hasNext()) {
            Object key = iter.next();
            map.put(keycodes.get(key), key);
        }
        return map;
    }

    /**
     * Generate the mapping between characters and key codes.   This is
     * invoked exactly once per VM invocation.  We don't need complete
     * coverage here, since this is primarily used to compute the events
     * required to generate user-entered text (as opposed to shortcut or
     * accelerator mappings).
     */
    private static HashMap generateKeyStrokeMappings() {
        // character, keycode, modifiers
        int shift = InputEvent.SHIFT_MASK;
        int alt = InputEvent.ALT_MASK;
        int altg = InputEvent.ALT_GRAPH_MASK;
        int ctrl = InputEvent.CTRL_MASK;
        int meta = InputEvent.META_MASK;
        // These are assumed to be standard across all keyboards (?)
        int[][] universalMappings = {
            { '', KeyEvent.VK_ESCAPE, 0 }, // No escape sequence exists
            { '\b', KeyEvent.VK_BACK_SPACE, 0 },
            { '', KeyEvent.VK_DELETE, 0 }, // FIXME is there an escape code?
            { '\n', KeyEvent.VK_ENTER, 0 },
            { '\r', KeyEvent.VK_ENTER, 0 },
        };
        // Add to these as needed; note that this is based on a US keyboard
        // mapping. 
        int[][] mappings = {
            { ' ', KeyEvent.VK_SPACE, 0, },
            { '\t', KeyEvent.VK_TAB, 0, },
            { '~', KeyEvent.VK_BACK_QUOTE, shift, },
            { '`', KeyEvent.VK_BACK_QUOTE, 0, },
            { '!', KeyEvent.VK_1, shift, },
            { '@', KeyEvent.VK_2, shift, },
            { '#', KeyEvent.VK_3, shift, },
            { '$', KeyEvent.VK_4, shift, },
            { '%', KeyEvent.VK_5, shift, },
            { '^', KeyEvent.VK_6, shift, },
            { '&', KeyEvent.VK_7, shift, },
            { '*', KeyEvent.VK_8, shift, },
            { '(', KeyEvent.VK_9, shift, },
            { ')', KeyEvent.VK_0, shift, },
            { '-', KeyEvent.VK_MINUS, 0, },
            { '_', KeyEvent.VK_MINUS, shift, },
            { '=', KeyEvent.VK_EQUALS, 0, },
            { '+', KeyEvent.VK_EQUALS, shift, },
            { '[', KeyEvent.VK_OPEN_BRACKET, 0, },
            { '{', KeyEvent.VK_OPEN_BRACKET, shift, },
            // NOTE: The following does NOT produce a left brace
            //{ '{', KeyEvent.VK_BRACELEFT, 0, },
            { ']', KeyEvent.VK_CLOSE_BRACKET, 0, },
            { '}', KeyEvent.VK_CLOSE_BRACKET, shift, },
            { '|', KeyEvent.VK_BACK_SLASH, shift, },
            { ';', KeyEvent.VK_SEMICOLON, 0, },
            { ':', KeyEvent.VK_SEMICOLON, shift, },
            { ',', KeyEvent.VK_COMMA, 0, },
            { '<', KeyEvent.VK_COMMA, shift, },
            { '.', KeyEvent.VK_PERIOD, 0, },
            { '>', KeyEvent.VK_PERIOD, shift, },
            { '/', KeyEvent.VK_SLASH, 0, },
            { '?', KeyEvent.VK_SLASH, shift, },
            { '\\', KeyEvent.VK_BACK_SLASH, 0, },
            { '|', KeyEvent.VK_BACK_SLASH, shift, },
            { '\'', KeyEvent.VK_QUOTE, 0, },
            { '"', KeyEvent.VK_QUOTE, shift, },
        };
        HashMap map = new HashMap();
        // Universal mappings
        for (int i=0;i < universalMappings.length;i++) {
            int[] entry = universalMappings[i];
            KeyStroke stroke = KeyStroke.getKeyStroke(entry[1], entry[2]);
            map.put(new Character((char)entry[0]), stroke);
        }

        // If the locale is not en_US/GB, provide only a very basic map and
        // rely on key_typed events instead
        Locale locale = Locale.getDefault();
        if (!Locale.US.equals(locale) && !Locale.UK.equals(locale)) {
            Log.debug("Not US: " + locale);
            return map;
        }

        // Basic symbol/punctuation mappings
        for (int i=0;i < mappings.length;i++) {
            int[] entry = mappings[i];
            KeyStroke stroke = KeyStroke.getKeyStroke(entry[1], entry[2]);
            map.put(new Character((char)entry[0]), stroke);
        }
        // Lowercase
        for (int i='a';i <= 'z';i++) {
            KeyStroke stroke = 
                KeyStroke.getKeyStroke(KeyEvent.VK_A + i - 'a', 0);
            map.put(new Character((char)i), stroke);
            // control characters
            stroke = KeyStroke.getKeyStroke(KeyEvent.VK_A + i - 'a', ctrl);
            Character key = new Character((char)(i - 'a' + 1));
            // Make sure we don't overwrite something already there
            if (map.get(key) == null) {
                map.put(key, stroke);
            }
        }
        // Capitals
        for (int i='A';i <= 'Z';i++) {
            KeyStroke stroke = 
                KeyStroke.getKeyStroke(KeyEvent.VK_A + i - 'A', shift);
            map.put(new Character((char)i), stroke);
        }
        // digits
        for (int i='0';i <= '9';i++) {
            KeyStroke stroke = 
                KeyStroke.getKeyStroke(KeyEvent.VK_0 + i - '0', 0);
            map.put(new Character((char)i), stroke);
        }
        return map;
    }
}
