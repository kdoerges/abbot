package abbot.tester;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.Arrays;

import javax.accessibility.AccessibleContext;
import javax.swing.*;

import abbot.AssertionFailedError;
import abbot.Log;


// FIXME may need to override key/focus actions to scroll prior to sending the
// events, similar to how click is overridden here
public class JComponentTester extends ContainerTester {

    /** This property is a duplicate of the one in JLabel, which we can't
     * access.
     */
    private static final String LABELED_BY_PROPERTY = "labeledBy";

    /** Derive a tag for identifying this component.  */
    @Override
    public String deriveTag(Component comp) {
        JComponent jComp = ((JComponent)comp);
        String tag = null;
        // If label.setLabelFor has been used, then this component has
        // a label; use its text
        JLabel label = (JLabel)((JComponent)comp).getClientProperty(LABELED_BY_PROPERTY);
        if (label != null && label.getText() != null && label.getText().length() > 0) {
            tag = label.getText();
        }


        //abbot_ext_begin
        // Da JTabbedPanes (und damit auch GPropertySheets) unter Java6 anscheinend einen accessibleContext haben 
        // und dadurch der ComponentTester ein anderes Tag erzeugt,
        // wird f�r die Kompatibilit�t Java5/Java6 diese Information bei JTabbedPanes nicht ber�cksichtigt
        // TODO Analysieren, woher das kommt

        if (tag == null || "".equals(tag)) {
            if (!(comp instanceof JTabbedPane)) {
                AccessibleContext context = jComp.getAccessibleContext();
                tag = deriveAccessibleTag(context);
            }
        }
        //abbot_ext_end
        if (tag == null || "".equals(tag)) {
            tag = super.deriveTag(comp);
        }
        return tag;
    }

    /** Click in the given part of the component, scrolling the component if
     * necessary to make the point visible.  Performing the scroll here
     * obviates the need for all derived classes to remember to do it for
     * actions involving clicks.
     */
    @Override
    public void mousePress(Component comp, int x, int y, int buttons) {
        if (comp instanceof JComponent) {
            scrollToVisible(comp, x, y);
        }
        super.mousePress(comp, x, y, buttons);
    }

    /**
     * Scrolls the component so that the coordinate x and y are visible.  Has
     * no effect if the component has no JViewport ancestor.
     *
     * @param comp the Component to scroll
     * @param x    the x coordinate to be visible
     * @param y    the y coordinate to be visible
     */
    protected void scrollToVisible(Component comp, int x, int y) {
        Rectangle rect = new Rectangle(x, y, 1, 1);
        scrollToVisible(comp, rect);
    }

    /**
     * Scrolls the component so that the given rectangle is visible.  Has no
     * effect if the component has no JViewport ancestor.
     *
     * NOTE: if you are invoking this method directly, you <b>must</b> wait
     * for idle before checking its results.
     *
     * @param comp the Component to scroll
     * @param rect the Rectangle to make visible.
     */
    protected void scrollToVisible(final Component comp, final Rectangle rect) {
        if (!((JComponent)comp).getVisibleRect().contains(rect)) {
            // FIXME Ideally, should use mouse clicks/drags on scrollbars to
            // get the appropriate effect.  For now, do it the easy way.
            // NOTE: absolutely MUST wait for idle in order for the scroll to
            // finish, and the UI to update so that the next action goes
            // to the proper location within the scrolled component.
            invokeAndWait(new Runnable() {

                public void run() {
                    Log.debug("Scrolling rect to visible: " + rect);
                    ((JComponent)comp).scrollRectToVisible(rect);
                }
            });
        }
    }

    /** Make sure the given rectangle is visible.  Note that this may have no
     * effect if the component is not actually in a scroll pane.
     */
    public void actionScrollToVisible(Component comp, int x, int y) {
        scrollToVisible(comp, x, y);
    }

    /** Make sure the given rectangle is visible.  Note that this may have no
     * effect if the component is not actually in a scroll pane.
     */
    public void actionScrollToVisible(Component comp, int x, int y, int width, int height) {
        scrollToVisible(comp, new Rectangle(x, y, width, height));
    }

    /** Invoke an action from the component's action map. */
    public void actionActionMap(Component comp, String name) {
        JComponent jc = (JComponent)comp;
        ActionMap am = jc.getActionMap();
        // On OSX/1.3.1, some action map keys are actions instead of strings.
        // On XP/1.4.1, all action map keys are strings.
        // If we can't look it up with the string key we saved, check all the
        // actions for a corresponding name.
        Object action = am.get(name);
        if (action == null) {
            Object[] keys = am.allKeys();
            for (int i = 0; i < keys.length; i++) {
                Object value = am.get(keys[i]);
                if ((value instanceof Action)) {
                    String aname = (String)((Action)value).getValue(Action.NAME);
                    if (aname != null && aname.equals(name)) {
                        action = value;
                        break;
                    }
                }
            }
        }
        if (action == null) {
            String available = "Available actions are the following:";
            Object[] names = am.allKeys();
            Arrays.sort(names, new java.util.Comparator<Object>() {

                public int compare(Object o1, Object o2) {
                    String n1 = o1.toString();
                    String n2 = o2.toString();
                    return n1.compareTo(n2);
                }
            });
            for (int i = 0; i < names.length; i++) {
                available += "\n" + names[i];
                if (!(names[i] instanceof String)) available += " (" + names[i].getClass() + ")";
            }
            throw new AssertionFailedError("No such action '" + name + "'. " + available);
        }
        InputMap im = jc.getInputMap();
        KeyStroke[] events = im.allKeys();
        for (int i = 0; i < events.length; i++) {
            KeyStroke ks = events[i];
            Object key = im.get(ks);
            // If the key is an action (OSX/1.3.1), grab the action name
            // instead 
            Log.debug("ks=" + ks + " key=" + key);
            if (key instanceof Action) {
                key = ((Action)key).getValue(Action.NAME);
            }
            if (name.equals(key)) {
                Log.debug("Generating keystroke " + ks + " for action " + name);
                if (ks.getKeyCode() == KeyEvent.VK_UNDEFINED)
                    keyStroke(ks.getKeyChar());
                else
                    key(ks.getKeyCode(), ks.getModifiers());
                waitForIdle();
                return;
            }
        }
        throw new ActionFailedException("No input event found for action key '" + name + "'");
    }
}
