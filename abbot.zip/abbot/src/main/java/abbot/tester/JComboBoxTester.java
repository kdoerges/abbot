package abbot.tester;

import java.awt.Component;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JList;

import abbot.Log;
import abbot.i18n.*;
import abbot.util.ExtendedComparator;

public class JComboBoxTester extends JComponentTester {

    private JListTester listTester = new JListTester();

    /** Return an array of strings that represent the combo box list. 
     * Note that the current selection might not be included, since it's
     * possible to have a custom (edited) entry there that is not included in
     * the default contents.
     */
    public String[] getContents(JComboBox cb) {
        ArrayList list = new ArrayList();
        for (int i=0;i < cb.getItemCount();i++) {
            list.add(cb.getItemAt(i).toString());
        }
        return (String[])list.toArray(new String[list.size()]);
    }

    public void actionSelectIndex(Component comp, final int index) {
        final JComboBox cb = (JComboBox)comp;
        int current = cb.getSelectedIndex();
        if (current == index)
            return;

        if (getEventMode() == EM_PROG) {
            invokeAndWait(new Runnable() {
                public void run() {
                    cb.setSelectedIndex(index);
                }
            });
        }
        else {
            // activate it
            // NOTE: if the index is out of range, the selected item will be
            // at one end of the list.
            click(cb);
            JList list = findComboList(cb);
            listTester.actionSelectIndex(list, index);
        }
    }

    /** Find the JList in the popup raised by this combo box. */
    public JList findComboList(JComboBox cb) {
        Component comp = getFinder().findActivePopupMenu(cb);
        if (comp == null) {
            long now = System.currentTimeMillis();
            while ((comp = getFinder().findActivePopupMenu(cb)) == null) {
                if (System.currentTimeMillis() - now > popupDelay)
                    throw new ActionFailedException(Strings.get("tester.JComboBox.popup_not_found"));
                sleep();
            }
        }
        
        while (!(comp instanceof javax.swing.JList)) {
            Component[] children =
                getFinder().getComponents((java.awt.Container)comp);
            for (int i=0;i < children.length;i++) {
                if (children[i] instanceof java.awt.Container) {
                    comp = children[i];
                    break;
                }
                else if (children[i] instanceof JList) {
                    comp = children[i];
                    break;
                }
            }
        }
        return (JList)comp;
    }

    /** If the value looks meaningful, return it, otherwise return null. */
    public String getValueAsString(JComboBox combo,
                                   JList list,
                                   Object item, int index) {
        String value = item.toString();
        // If the value is the default Object.toString method (which
        // returns <class>@<pointer value>), try to find something better.
        if (value.startsWith(item.getClass().getName() + "@")) {
            Component c = combo.getRenderer().
                getListCellRendererComponent(list, item, index, true, true);
            if (c instanceof javax.swing.JLabel)
                return ((javax.swing.JLabel)c).getText();
            return null;
        }
        return value;
    }

    public void actionSelectItem(Component comp, String item) {
        JComboBox cb = (JComboBox)comp;
        Object obj = cb.getSelectedItem();
        if (obj != null && ExtendedComparator.stringsMatch(item, obj.toString()))
            return;

        int index = -1;
        for (int i=0;i < cb.getItemCount();i++) {
            obj = cb.getItemAt(i);
            Log.debug("Comparing against '" + obj.toString() + "'");
            if (ExtendedComparator.stringsMatch(item, obj.toString())) {
                actionSelectIndex(comp, i);
                return;
            }
        }
        // While actions are supposed to represent real user actions, it's
        // possible that the current environment does not match sufficiently,
        // so we need to throw an appropriate exception that can be used to
        // diagnose the problem.
        throw new ActionFailedException(Strings.get("tester.JComboBox.item_not_found",
                                                    new Object[] { item }));
    }
}
