package abbot.tester;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuComponent;
import java.awt.MenuContainer;
import java.awt.MenuItem;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.HierarchyEvent;
import java.awt.event.InputEvent;
import java.awt.event.InputMethodEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.PaintEvent;
import java.awt.event.WindowEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.StringTokenizer;

import javax.accessibility.AccessibleAction;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import testframework.testrunner.RTVariablesSingleton;
import testframework.testrunner.TREGSSystemVariables;
import abbot.ComponentFinder;
import abbot.Condition;
import abbot.DefaultComponentFinder;
import abbot.Log;
import abbot.Platform;
import abbot.Reflector;
import abbot.WaitTimedOutError;
import abbot.i18n.Strings;
import abbot.util.AWT;
import abbot.util.Properties;

import com.obi.test.tregs.abbot.component.AbbotProperties;

import extensions.util.EventQueueUtil;
import extensions.util.RobotUtil;


/** Provide a higher level of abstraction for user input (A Better Robot).
    The Robot's operation may be affected by the following properties:<br>
    <pre><code>abbot.robot.auto_delay</code></pre><br>
    Set this to a value representing the millisecond count in between
    generated events.  Usually just set to 100-200 if you want to slow down
    the playback to simulate actual user input.  The default is zero delay.<br>
    <pre><code>abbot.robot.mode</code></pre><br>
    Set this to either "robot" or "awt" to designate the desired mode of event
    generation.  "robot" uses java.awt.Robot to generate events, while "awt"
    stuffs events directly into the AWT event queue.<br>
    <pre><code>abbot.robot.event_post_delay</code></pre><br>
    This is the maximum number of ms it takes the system to post an AWT event
    in response to a Robot-generated event.
    <pre><code>abbot.robot.default_delay</code></pre><br>
    Base delay setting, acts as default value for the next two.
    <pre><code>abbot.robot.popup_delay</code></pre><br>
    Set this to the maximum time to wait for a menu to appear or be generated.
    <pre><code>abbot.robot.component_delay</code></pre><br>
    Set this to the maximum time to wait for a Component to become available.
    <p>
    NOTE: Only use invokeAndWait when a subsequent robot-level action is being
    applied to the results of a prior action (e.g. focus, deiconify, menu
    selection).  Otherwise, don't introduce a mandatory delay.
    <p>
    NOTE: If a robot action isn't reproduced properly, you may need to
    introduce either additional events or extra delay.  Adding enforced delay
    for a given platform is preferable to additional events, so always try
    that first, but be sure to restrict it to the platform in question.
    <p>
    TODO: adjust numlock/capslock state on startup so that we are in a known
    state. 
 */

public class Robot {

    private static final Logger logger = LoggerFactory.getLogger(Robot.class);

    /** Use java.awt.Robot to generate events. */
    protected static int EM_ROBOT = 0;

    /** Post events to the AWT event queue. */
    protected static int EM_AWT = 1;

    /** Use programmatic control where possible (only partly implemented). */
    protected static int EM_PROG = 2;

    public static final int MULTI_CLICK_INTERVAL = 200; // a guess

    public static final int BUTTON_MASK = (InputEvent.BUTTON1_MASK | InputEvent.BUTTON2_MASK | InputEvent.BUTTON3_MASK);

    private static final Toolkit toolkit = Toolkit.getDefaultToolkit();

    public static final int POPUP_MASK = AWT.getPopupMask();

    public static final String POPUP_MODIFIER = getMouseModifiers(POPUP_MASK);

    public static final boolean POPUP_ON_PRESS = AWT.getPopupOnPress();

    public static final int TERTIARY_MASK = AWT.getTertiaryMask();

    public static final String TERTIARY_MODIFIER = getMouseModifiers(TERTIARY_MASK);

    public static final int MENU_SHORTCUT_MASK = toolkit.getMenuShortcutKeyMask();

    public static final String MENU_SHORTCUT_MODIFIER = getKeyModifiers(MENU_SHORTCUT_MASK);

    public static final String MENU_SHORTCUT_KEYCODE = getKeyCode(maskToKeyCode(MENU_SHORTCUT_MASK));

    private static boolean OUTCODE_BIGGER;

    /** Return whether this is the tertiary button, considering primary to be
     * button1 and secondary to be the popup trigger button.
     */
    public static boolean isTertiaryButton(int mods) {
        return ((mods & BUTTON_MASK) != InputEvent.BUTTON1_MASK) && ((mods & POPUP_MASK) == 0);
    }

    /** OS X using screenMenuBar actually uses an AWT menu as the live
        component.  The JXXX components exist, but are not effectively
        active. 
    */
    protected static final boolean useScreenMenuBar() {
        // Ideally we'd install a menu and check where it ended up
        return Platform.isOSX()
               && (Boolean.getBoolean("com.apple.macos.useScreenMenuBar") || Boolean
                       .getBoolean("apple.laf.useScreenMenuBar"));
    }

    /** Base delay setting. */
    public static int defaultDelay = Properties.getProperty("abbot.robot.default_delay", 0, 60000, 30000);

    /** Delay before checking for idle.  This allows the system a little time
        to put a native event onto the AWT event queue. */
    private static int eventPostDelay = Properties.getProperty("abbot.robot.event_post_delay", 0, 1000, 100);

    /** Delay before failing to find a popup menu that should appear. */
    protected static int popupDelay = Properties.getProperty("abbot.robot.popup_delay", 0, 60000, defaultDelay);

    /** Delay before failing to find a component that should be visible. */
    public static int componentDelay = Properties.getProperty("abbot.robot.component_delay", 0, 60000, defaultDelay);

    /** With decreased robot auto delay, OSX popup menus don't activate
     * properly.  Indicate the minimum delay for proper operation (determined
     * experimentally). 
     */
    private static final int subMenuDelay = Platform.isOSX() ? 100 : 0;

    /** How events are generated. */
    private static int eventMode = EM_ROBOT;

    /** Current input state.  This will either be that of the AWT event queue
     * or of the robot, depending on the dispatch mode. 
     * Note that the robot state may be different from that seen by the AWT
     * event queue, since robot events may be as yet unprocessed.
     */
    protected static InputState state = new InputState();

    protected int dragMask = 0;

    // FIXME add one per graphics device?
    /** The robot used to generate events. */
    private static java.awt.Robot robot = null;

    /** Suitable delay for most cases; tests have been run safely at this
        value.  Should definitely be less than the double-click threshold.
        (The default value, zero, causes half the tests to fail on linux).
        FIXME need to find a value between 0 and 100 (100 is kinda slow).
        30 works (almost) for w32/linux, but OSX 10.1.5 text input lags (50 is 
        minimum). <p>
        As platforms are tested at 0 delay, adjust this value.<p>
        OSX test run time was reduced from 130s to 96s.<p>
        Not sure it's worth tracking down all the robot bugs and working
        around them.
    */
    private static final int DEFAULT_DELAY = getPreferredRobotAutoDelay();

    private static final int SLEEP_INTERVAL = 10;

    private static int autoDelay = DEFAULT_DELAY;

    public static int getAutoDelay() {
        return autoDelay;
    }

    static {
        String mode = System.getProperty("abbot.robot.mode", "robot");
        autoDelay = Properties.getProperty("abbot.robot.auto_delay", -1, 60000, autoDelay);
        try {
            robot = new java.awt.Robot();
            if (autoDelay != -1) {
                robot.setAutoDelay(autoDelay);
            } else {
                autoDelay = robot.getAutoDelay();
                Log.warn("Using delay of " + autoDelay);
            }
        } catch (java.awt.AWTException exc) {
            // no robot available, send AWT events
            System.err.println("No Robot available, falling back to AWT mode: " + exc.getMessage());
            robot = null;
        }
        if (mode.equals("awt") || robot == null) {
            eventMode = EM_AWT;
        }
        // Detect whether Rectangle.contains agrees with Rectangle.outcode
        // 1.4.1 considers width/height to be inside the rect when checking
        // the outcode 
        Point p = new Point(10, 10);
        Rectangle r = new Rectangle(0, 0, 10, 10);
        OUTCODE_BIGGER = r.outcode(p) == 0 && !r.contains(p);
    }

    /** Returns the current event-generation mode. */
    public static int getEventMode() {
        return eventMode;
    }

    /** Set the event-generation mode. */
    static void setEventMode(int mode) {
        eventMode = mode;
    }

    public static int getEventPostDelay() {
        return eventPostDelay;
    }

    public static void setEventPostDelay(int delay) {
        eventPostDelay = Math.min(1000, Math.max(0, delay));
    }

    /** Allow this to be adjusted, mostly for testing. */
    public static void setAutoDelay(int ms) {
        ms = Math.min(60000, Math.max(0, ms));
        if (eventMode == EM_ROBOT) robot.setAutoDelay(ms);
        autoDelay = ms;
        Log.debug("Auto delay set to " + ms);
    }

    /** 
     * Move the mouse to the given location, in screen coordinates.  
     * NOTE: in robot mode, you may need to invoke this with a little jitter.
     * There are some conditions where a single mouse move will not
     * generate the necessary enter event on a component (typically a
     * dialog with an OK button) before a mousePress.  See also click().
     * NOTE: does 1.4+ need jitter?
     */
    private void mouseMove(int x, int y) {
        if (eventMode == EM_ROBOT) {
            Log.debug("ROBOT: Mouse move: (" + x + "," + y + ")");
            robot.mouseMove(x, y);
        } else {
            // Can't stuff an AWT event for an arbitrary location
        }
    }

    /** Send a button press event. */
    public void mousePress(int buttons) {
        if (eventMode == EM_ROBOT) {
            Log.debug("ROBOT: Mouse press: " + getMouseModifiers(buttons));
            // OSX 1.4.1 accidentally swaps mb2 and mb3; fix it here
            robot.mousePress(buttons);
        } else {
            Component c = state.getMouseComponent();
            if (c == null) {
                Log.warn("Mouse press outside of available frames");
                return;
            }
            Point where = state.getMouseLocation();
            postMousePressEvent(c, where.x, where.y, buttons);
        }
    }

    /** Send a button release event for button 1. */
    public void mouseRelease() {
        mouseRelease(MouseEvent.BUTTON1_MASK);
    }

    /** Send a button release event. */
    public void mouseRelease(int buttons) {
        if (eventMode == EM_ROBOT) {
            Log.debug("ROBOT: Mouse release: " + getMouseModifiers(buttons));
            robot.mouseRelease(buttons);
        } else {
            Component source =
                    state.isDragging() ? state.getDragSource() : (lastMousePress != null ? lastMousePress
                            .getComponent() : state.getMouseComponent());
            if (source == null) {
                Log.warn("Mouse release outside of available frames");
                return;
            }
            Point where = state.getMouseLocation();
            postMouseReleaseEvent(source, where.x, where.y, buttons);
        }
    }

    /** Move keyboard focus to the given component.  Note that the component
        may not yet have focus when this method returns.
    */
    public void focus(Component comp) {
        focus(comp, false);
    }

    private class FocusWatcher extends FocusAdapter {

        public volatile boolean focused = false;

        private final Component component;

        public FocusWatcher(Component c) {
            component = c;
            c.addFocusListener(this);
            focused = c.hasFocus();
        }

        @Override
        public void focusGained(FocusEvent f) {
            focused = true;
        }

        @Override
        public void focusLost(FocusEvent f) {
            focused = false;
        }
    }

    /** Move keyboard focus to the given component. */
    public void focus(final Component comp, boolean wait) {
        if (comp.hasFocus()) {
            return;
        }
        Log.debug("Focus change");
        FocusWatcher fw = new FocusWatcher(comp);
        mouseMove(comp); // for pointer focus
        waitForIdle();
        // Make sure the correct window is in front
        Component fowner = findFocusOwner();
        ComponentFinder finder = DefaultComponentFinder.getFinder();
        Window w1 = fowner == null ? null : finder.getComponentWindow(fowner);
        Window w2 = finder.getComponentWindow(comp);
        if (w1 != w2) {
            activate(w2);
            waitForIdle();
        }
        // NOTE: while it would be nice to have a robot method instead of
        // requesting focus, clicking to change focus may have 
        // side effects 
        invokeAndWait(new Runnable() {

            @Override
            public void run() {
                comp.requestFocus();
            }
        });
        try {
            if (wait) {
                long start = System.currentTimeMillis();
                while (!fw.focused && !(comp instanceof Window && ((Window)comp).getFocusOwner() != null)) {
                    if (System.currentTimeMillis() - start > componentDelay) {
                        String msg = Strings.get("tester.Robot.focus_failed", new Object[] {toString(comp)});
                        throw new ActionFailedException(msg);
                    }
                }
            }
        } finally {
            comp.removeFocusListener(fw);
        }
    }

    /** Run the given action on the event dispatch thread.  This should be
     * used for any non-read-only methods invoked directly on a GUI
     * component. 
     * NOTE: if you want to use the results of the action, use invokeAndWait
     * instead. 
     */
    public void invokeAction(Runnable action) {
        EventQueue.invokeLater(action);
    }

    /** Run the given action on the event dispatch thread, but don't return
        until it's been run.
    */
    public void invokeAndWait(Runnable action) {
        EventQueue.invokeLater(action);
        waitForIdle();
    }

    /** Send a key press event. */
    public void keyPress(int keycode) {
        if (eventMode == EM_ROBOT) {
            Log.debug("ROBOT: key press " + getKeyCode(keycode));
            robot.keyPress(keycode);
        } else {
            postKeyEvent(KeyEvent.KEY_PRESSED, state.getModifiers(), keycode, KeyEvent.CHAR_UNDEFINED);
        }
    }

    /** Send a key release event. */
    public void keyRelease(int keycode) {
        if (eventMode == EM_ROBOT) {
            Log.debug("ROBOT: key release " + getKeyCode(keycode));
            robot.keyRelease(keycode);
        } else {
            int mods = state.getModifiers();
            if (isModifier(keycode)) mods &= ~keyCodeToMask(keycode);
            postKeyEvent(KeyEvent.KEY_RELEASED, mods, keycode, KeyEvent.CHAR_UNDEFINED);
        }
    }

    private void postKeyEvent(int id, int modifiers, int keycode, char ch) {
        Component c = findFocusOwner();
        if (c != null) {
            postEvent(c, new KeyEvent(c, id, System.currentTimeMillis(), modifiers, keycode, ch));
        } else {
            Log.warn("No component has focus, key press discarded");
        }
    }

    /** Sleep for a little bit, measured in UI time. */
    public void sleep() {
        delay(SLEEP_INTERVAL);
    }

    /** Sleep the given duration of ms. */
    public void delay(int ms) {
        if (eventMode == EM_ROBOT)
            robot.delay(ms);
        else {
            try {
                Thread.sleep(ms);
            } catch (InterruptedException ie) {}
        }
    }

    /**
     * Wait for an idle AWT event queue.  Note that this is different from
     * the implementation of the robot wait for idle, which may have events on
     * the queue when it returns.  Do <b>NOT</b> use this method if there are
     * animations or other continual refreshes happening, since in that case
     * it may never return.
     */
    public void waitForIdle() {
        if (eventPostDelay > autoDelay) {
            delay(eventPostDelay - autoDelay);
        }


        //Abbot_Ext_Begin
        try {
            EventQueueUtil.theInstance().waitForIdleAndClear();
        } catch (Exception e) {
            logger.error("Waiting for empty event queue failed: " + e.getMessage());
        }
        //Abbot_Ext_End    
    }

    /** Sample the color at the given point on the screen. */
    public Color sample(int x, int y) {
        return robot.getPixelColor(x, y);
    }

    /** Capture the contents of the given rectangle. */
    /* NOTE: Text components (and maybe others with a custom cursor) will
     * capture the cursor.  May want to move the cursor out of the component
     * bounds, although this might cause issues where the component is
     * responding visually to mouse movement. 
     * Is this an OSX bug?
     */
    public BufferedImage capture(Rectangle bounds) {
        return robot.createScreenCapture(bounds);
    }

    /** Capture the contents of the given component, sans any border or
     * insets.  This should only be used on components that do not use a LAF
     * UI, or the results will not be consistent across platforms.
     */
    public BufferedImage capture(Component comp) {
        return capture(comp, true);
    }

    /** Capture the contents of the given component, optionally including the
     * border and/or insets.  This should only be used on components that do
     * not use a LAF UI, or the results will not be consistent across
     * platforms. 
     */
    public BufferedImage capture(Component comp, boolean ignoreBorder) {
        Rectangle bounds = new Rectangle(comp.getSize());
        Point loc = new Point(comp.getLocationOnScreen());
        bounds.x = loc.x;
        bounds.y = loc.y;
        Log.debug("Component bounds " + bounds);
        // Make sure we don't sample the decorating space
        if (ignoreBorder && (comp instanceof Container)) {
            Insets insets = ((Container)comp).getInsets();
            bounds.x += insets.left;
            bounds.y += insets.top;
            bounds.width -= insets.left + insets.right;
            bounds.height -= insets.top + insets.bottom;
            Log.debug("Component insets " + insets);
            Log.debug("Component bounds " + bounds);
        }
        return capture(bounds);
    }

    // Bug workaround support
    protected void jitter(Component comp, int x, int y) {
        mouseMove(comp, (x > 0 ? x - 1 : x + 1), y);
    }

    // Bug workaround support
    protected void jitter(int x, int y) {
        mouseMove((x > 0 ? x - 1 : x + 1), y);
    }

    /** Move the pointer to the center of the given component. */
    public void mouseMove(Component comp) {
        mouseMove(comp, comp.getWidth() / 2, comp.getHeight() / 2);
    }

    /** Wait the given number of ms for the component to be showing and
        ready.  Returns false if the operation times out. */
    private boolean waitForComponent(Component c, long delay) {
        if (!isReadyForInput(c)) {
            Log.debug("Waiting for component to show");
            long start = System.currentTimeMillis();
            while (!isReadyForInput(c)) {
                if (System.currentTimeMillis() - start > delay) {
                    return false;
                }
                sleep();
            }
        }
        return true;
    }

    /** Move the pointer to the given coordinates relative to the given
     * component.
     */
    public void mouseMove(Component comp, int x, int y) {
        if (!waitForComponent(comp, componentDelay)) {
            String msg = "Can't obtain position of component " + toString(comp);
            throw new ComponentNotShowingException(msg);
        }
        if (eventMode == EM_ROBOT) {
            try {
                Point point = comp.getLocationOnScreen();
                if (point != null) {
                    point.translate(x, y);
                    mouseMove(point.x, point.y);
                }
            } catch (java.awt.IllegalComponentStateException e) {}
        } else {
            Component source = comp;
            int id = MouseEvent.MOUSE_MOVED;
            // When dragging, the event source is always the target of the
            // original mouse press.
            if (state.isDragging()) {
                id = MouseEvent.MOUSE_DRAGGED;
                source = state.getDragSource();
            }
            Component current = state.getMouseComponent();
            if (current != comp) {
                simulateMouseExitEnter(state.getMouseComponent(), state.getMouseLocation(), comp, new Point(x, y));
            }
            // Adjust the drag coordinates if necessary
            if (source != comp) {
                Point target = source.getLocationOnScreen();
                Point offset = comp.getLocationOnScreen();
                x += offset.x - target.x;
                y += offset.y - target.y;
            }
            postEvent(source,
                      new MouseEvent(source, id, System.currentTimeMillis(), state.getModifiers(), x, y, state
                              .getClickCount(), false));
        }
    }

    /** Move the mouse appropriately to get from the source to the
        destination.  Enter/exit events will be generated where appropriate.
    */
    public void dragOver(Component dst, int x, int y) {
        mouseMove(dst, (x > 1) ? x - 1 : x + 1, y);
        mouseMove(dst, x, y);
    }

    /** Begin a drag operation using button 1. */
    public void drag(Component src, int sx, int sy) {
        drag(src, sx, sy, InputEvent.BUTTON1_MASK);
    }


    /** Begin a drag operation using the given button mask. */
    public void drag(Component src, int sx, int sy, int buttons) {
        // OSX 10(1.3.1), 5(1.4.1)
        // Linux/X11: delay+16
        int DRAG_THRESHOLD = Platform.isWindows() || Platform.isMacintosh() ? 10 : 16;
        int DRAG_DELAY = Properties.getProperty("abbot.robot.drag_delay", 0, 60000, Platform.isX11() ? 100 : 0);
        mousePress(src, sx, sy, buttons);
        dragMask = buttons;
        if (DRAG_DELAY > autoDelay) delay(DRAG_DELAY);
        if (Platform.isWindows() || Platform.isMacintosh()) {
            mouseMove(src, sx + DRAG_THRESHOLD, sy + DRAG_THRESHOLD);
        } else {
            mouseMove(src, sx + DRAG_THRESHOLD / 2, sy + DRAG_THRESHOLD / 2);
            mouseMove(src, sx + DRAG_THRESHOLD, sy + DRAG_THRESHOLD);
            mouseMove(src, sx + DRAG_THRESHOLD / 2, sy + DRAG_THRESHOLD / 2);
            mouseMove(src, sx, sy);
        }
    }

    /** End a drag operation, releasing the mouse button over the given target
        location.
    */
    public void drop(Component target, int x, int y) {
        // Delay between final move and drop to ensure drop ends.
        int DROP_DELAY = Properties.getProperty("abbot.robot.drop_delay", 0, 60000, Platform.isWindows() ? 200 : 0);

        // All motion events are relative to the drag source
        if (!state.isDragging()) throw new ActionFailedException("There is no drag in effect");
        dragOver(target, x, y);
        if (DROP_DELAY > autoDelay) delay(DROP_DELAY - autoDelay);
        mouseRelease(dragMask);
        dragMask = 0;
    }

    // Work around a bug in java.awt.Rectangle.outcode, which considers
    // width/height to be within the rectangle, when Rectangle.contains does
    // not. 
    private int outcode(Rectangle rect, int x, int y) {
        if (OUTCODE_BIGGER) rect = new Rectangle(rect.x, rect.y, rect.width - 1, rect.height - 1);
        return rect.outcode(x, y);
    }

    /** Return the point of intersection on the border of given rectangle with
     * the line specified by the two points, or null if there is no
     * intersection.  If the line is colinear with an edge some point along
     * the edge will be chosen.<p>
     * Note that rect.contains does not include coordinates on
     * the width, height, boundary, but those values are sometimes used in
     * enter/exit events.<p>
     */
    Point getBorderIntersection(Rectangle rect, Point p1, Point p2) {
        Point inside, outside;
        Point isect = new Point();
        if (rect.contains(p1)) {
            inside = p1;
            if (!rect.contains(p2)) {
                outside = p2;
            } else {
                throw new IllegalArgumentException("Both " + p1 + " and " + p2 + " are within " + rect);
            }
        } else if (rect.contains(p2)) {
            outside = p1;
            inside = p2;
        } else {
            throw new IllegalArgumentException("Neither " + p1 + " nor " + p2 + " is within " + rect);
        }

        // y = mx + b, x = (y - b)/m
        boolean vertical = (outside.x == inside.x);
        boolean horizontal = (outside.y == inside.y);
        float dy = (float)outside.y - inside.y;
        float dx = (float)outside.x - inside.x;
        float m = vertical ? 0 : dy / dx;
        float b = vertical ? 0 : outside.y - m * outside.x;
        // Figure out which side of the rectangle it intersects
        int code = outcode(rect, outside.x, outside.y);
        if (((code & Rectangle2D.OUT_LEFT) != 0 && rect.contains(0, Math.round(b))) || code == Rectangle2D.OUT_LEFT) {
            isect.x = 0;
            isect.y = Math.round(b);
        } else if (((code & Rectangle2D.OUT_RIGHT) != 0 && rect.contains(rect.width - 1,
                                                                         Math.round(m * (rect.width - 1) + b)))
                   || code == Rectangle2D.OUT_RIGHT) {
            isect.x = rect.width;
            isect.y = Math.round(m * isect.x + b);
        } else if ((code & Rectangle2D.OUT_TOP) != 0) {
            isect.y = 0;
            isect.x = horizontal ? (inside.x + outside.x) / 2 : (vertical ? inside.x : Math.round(-b / m));
        } else if ((code & Rectangle2D.OUT_BOTTOM) != 0) {
            isect.y = rect.height;
            isect.x = horizontal ? (inside.x + outside.x) / 2 : (vertical ? inside.x : Math.round((isect.y - b) / m));
        } else {
            throw new IllegalArgumentException("Both "
                                               + outside
                                               + " and "
                                               + inside
                                               + " are within "
                                               + rect
                                               + " (code was "
                                               + code
                                               + ")");
        }

        return isect;
    }

    /** Generate a mouse enter for the destination component, and optionally
     * an exit from the source component, as if the pointer were actually
     * moved from the source point to the destination.
     */
    private void simulateMouseExitEnter(Component src, Point from, Component dst, Point to) {
        Point srcLoc = (src != null) ? new Point(src.getLocationOnScreen()) : state.getMouseLocationOnScreen();
        Point dstLoc = new Point(dst.getLocationOnScreen());
        if (src != null) {
            Point dstPoint = new Point(to);
            dstPoint.translate(dstLoc.x - srcLoc.x, dstLoc.y - srcLoc.y);
            Rectangle bounds = new Rectangle(0, 0, src.getWidth(), src.getHeight());
            // The destination may be a descendent of the source
            if (bounds.contains(dstPoint)) {
                Log.debug("No exit event when moving to a child component");
            } else {
                if (!bounds.contains(from)) {
                    // If for some reason, "from" is not within the current
                    // component (may happen when mouse tracking is not very
                    // accurate), pick an arbitrary location within it.
                    from = new Point(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2);
                }
                Point exit = getBorderIntersection(bounds, from, dstPoint);
                postEvent(src,
                          new MouseEvent(src,
                                         MouseEvent.MOUSE_EXITED,
                                         System.currentTimeMillis(),
                                         state.getModifiers(),
                                         exit.x,
                                         exit.y,
                                         0,
                                         false));
            }
            // Convert FROM to be relative to the destination
            from.translate(srcLoc.x - dstLoc.x, srcLoc.y - dstLoc.y);
        } else {
            Log.debug("No exit event when no previous component available");
            // Convert FROM to be relative to the destination
            from = state.getMouseLocationOnScreen();
            from.translate(-dstLoc.x, -dstLoc.y);
        }
        Rectangle bounds = new Rectangle(0, 0, dst.getWidth(), dst.getHeight());
        // Make sure "from" is outside the component, and that "to"
        // is within it.
        if (bounds.contains(from)) from = new Point(bounds.x - 1, bounds.y - 1);
        if (!bounds.contains(to)) to = new Point(0, 0);
        Point entry = getBorderIntersection(bounds, from, to);
        postEvent(dst, new MouseEvent(dst,
                                      MouseEvent.MOUSE_ENTERED,
                                      System.currentTimeMillis(),
                                      state.getModifiers(),
                                      entry.x,
                                      entry.y,
                                      0,
                                      false));
    }

    /** Type the given keycode with no modifiers. */
    public void key(int keycode) {
        key(keycode, 0);
    }

    /** Press or release the appropriate modifiers corresponding to the given
        mask.
    */
    public void setModifiers(int modifiers, boolean press) {
        boolean altGraph = (modifiers & InputEvent.ALT_GRAPH_MASK) != 0;
        boolean shift = (modifiers & InputEvent.SHIFT_MASK) != 0;
        boolean alt = (modifiers & InputEvent.ALT_MASK) != 0;
        boolean ctrl = (modifiers & InputEvent.CTRL_MASK) != 0;
        boolean meta = (modifiers & InputEvent.META_MASK) != 0;
        if (press) {
            if (altGraph) keyPress(KeyEvent.VK_ALT_GRAPH);
            if (alt) keyPress(KeyEvent.VK_ALT);
            if (shift) keyPress(KeyEvent.VK_SHIFT);
            if (ctrl) keyPress(KeyEvent.VK_CONTROL);
            if (meta) keyPress(KeyEvent.VK_META);
        } else {
            // For consistency, release in the reverse order of press
            if (meta) keyRelease(KeyEvent.VK_META);
            if (ctrl) keyRelease(KeyEvent.VK_CONTROL);
            if (shift) keyRelease(KeyEvent.VK_SHIFT);
            if (alt) keyRelease(KeyEvent.VK_ALT);
            if (altGraph) keyRelease(KeyEvent.VK_ALT_GRAPH);
        }
    }

    /** Type the given keycode with the given modifiers.  Modifiers is a mask
     * from the available InputEvent masks.
     */
    public void key(int keycode, int modifiers) {
        key(KeyEvent.CHAR_UNDEFINED, keycode, modifiers);
    }

    private void key(char ch, int keycode, int modifiers) {
        Log.debug("key keycode=" + getKeyCode(keycode) + " mod=" + getKeyModifiers(modifiers));
        boolean isModifier = true;
        switch (keycode) {
        case KeyEvent.VK_ALT_GRAPH:
            modifiers |= InputEvent.ALT_GRAPH_MASK;
            break;
        case KeyEvent.VK_ALT:
            modifiers |= InputEvent.ALT_MASK;
            break;
        case KeyEvent.VK_SHIFT:
            modifiers |= InputEvent.SHIFT_MASK;
            break;
        case KeyEvent.VK_CONTROL:
            modifiers |= InputEvent.CTRL_MASK;
            break;
        case KeyEvent.VK_META:
            modifiers |= InputEvent.META_MASK;
            break;
        default:
            isModifier = false;
            break;
        }
        setModifiers(modifiers, true);
        if (!isModifier) {
            keyPress(keycode);
            keyRelease(keycode);
            if (eventMode == EM_AWT) {
                if (ch == KeyEvent.CHAR_UNDEFINED) {
                    KeyStroke ks = KeyStroke.getKeyStroke(keycode, modifiers);
                    ch = KeyStrokeMap.getChar(ks);
                }
                if (ch != KeyEvent.CHAR_UNDEFINED) {
                    postKeyEvent(KeyEvent.KEY_TYPED, modifiers, KeyEvent.VK_UNDEFINED, ch);
                }
            }
        }
        setModifiers(modifiers, false);
        if (hasKeyStrokeGenerationBug()) delay(100);
    }

    /**
     * Type the given character.  Note that this sends the key to whatever
     * component currently has the focus.
     */
    // FIXME should this be renamed to "key"?
    public void keyStroke(char ch) {
        KeyStroke ks = KeyStrokeMap.getKeyStroke(ch);
        if (ks == null) {
            // No mapping, stuff a key_typed instead
            Log.debug("No key mapping for '" + ch + "'");
            Component focus = findFocusOwner();
            if (focus == null) {
                Log.warn("No component has focus, keystroke discarded", Log.FULL_STACK);
            } else {
                // FIXME need to somehow derive the proper key down/up
                // keycodes which will properly generate this event
                // If it wasn't in our keystroke map, it means we have no
                // idea... 
                // KEY_PRESSED
                // KEY_RELEASED
                KeyEvent ke =
                        new KeyEvent(focus,
                                     KeyEvent.KEY_TYPED,
                                     System.currentTimeMillis(),
                                     0,
                                     KeyEvent.VK_UNDEFINED,
                                     ch);
                // Allow any pending robot events to complete; otherwise we
                // might stuff the typed event before previous robot-generated
                // events are posted.
                if (eventMode == EM_ROBOT) waitForIdle();
                postEvent(focus, ke);
            }
        } else {
            int keycode = ks.getKeyCode();
            int mod = ks.getModifiers();
            Log.debug("Char '" + ch + "' generated by keycode=" + keycode + " mod=" + mod);
            key(ch, keycode, mod);
        }
    }

    /** Type the given string. */
    public void keyString(String str) {


        //Abbot_Ext_Begin

        boolean tempFastPlayback = false;

        String tempSpeedPlayback =
                RTVariablesSingleton.theInstance().getVariable(TREGSSystemVariables.SCRIPTSERVER_SPEED_PLAYBACK);


        if (TREGSSystemVariables.SCRIPTSERVER_SPEED_PLAYBACK_FAST.equals(tempSpeedPlayback)) {
            tempFastPlayback = true;
        } else if (TREGSSystemVariables.SCRIPTSERVER_SPEED_PLAYBACK_NORMAL.equals(tempSpeedPlayback)) {
            tempFastPlayback = false;
        } else {
            tempFastPlayback =
                    AbbotProperties.SPEED_PLAYBACK_FAST.equals(AbbotProperties.theInstance().getSpeedPlayback());
        }


        Component focus = null;
        boolean tempKeyStringPerformed = false;

        if (tempFastPlayback) {
            focus = findFocusOwner();
            if (focus == null) {
                tempKeyStringPerformed = false;
            } else {
                tempKeyStringPerformed = RobotUtil.theInstance().fastKeyString(focus, str);
            }

        }


        if (!tempKeyStringPerformed) {
            char[] ch = str.toCharArray();
            for (int i = 0; i < ch.length; i++) {
                keyStroke(ch[i]);
            }
        }
        //Abbot_Ext_END

    }

    public void mousePress(Component comp) {
        mousePress(comp, comp.getWidth() / 2, comp.getHeight() / 2);
    }

    public void mousePress(Component comp, int mask) {
        mousePress(comp, comp.getWidth() / 2, comp.getHeight() / 2, mask);
    }

    public void mousePress(Component comp, int x, int y) {
        mousePress(comp, x, y, InputEvent.BUTTON1_MASK);
    }

    /** Mouse down in the given part of the component.  All other mousePress
        methods must eventually invoke this one.
    */
    public void mousePress(Component comp, int x, int y, int mask) {
        if (eventMode == EM_ROBOT && hasRobotMotionBug()) {
            jitter(comp, x, y);
        }
        mouseMove(comp, x, y);
        if (eventMode == EM_ROBOT)
            mousePress(mask);
        else {
            postMousePressEvent(comp, x, y, mask);
        }
    }

    /** Post a mouse press event to the AWT event queue for the given
        component.
    */
    private void postMousePressEvent(Component comp, int x, int y, int mask) {
        long when = state.getLastEventTime();
        long now = System.currentTimeMillis();
        int count = state.getClickCount();
        count = (now - when < MULTI_CLICK_INTERVAL) ? count + 1 : 1;
        postEvent(comp, new MouseEvent(comp,
                                       MouseEvent.MOUSE_PRESSED,
                                       now,
                                       state.getKeyModifiers() | mask,
                                       x,
                                       y,
                                       count,
                                       POPUP_ON_PRESS && (mask & POPUP_MASK) != 0));
    }

    /** Post a mouse release event to the AWT event queue for the given
        component.
    */
    private void postMouseReleaseEvent(Component c, int x, int y, int mask) {
        long now = System.currentTimeMillis();
        int count = state.getClickCount();
        postEvent(c, new MouseEvent(c,
                                    MouseEvent.MOUSE_RELEASED,
                                    now,
                                    state.getKeyModifiers() | mask,
                                    x,
                                    y,
                                    count,
                                    !POPUP_ON_PRESS && (mask & POPUP_MASK) != 0));
    }

    /** Click in the center of the given component.  This is not static b/c it
     * sometimes needs to be redefined (i.e. JComponent to scroll before
     * clicking).
     */
    public void click(Component comp) {
        click(comp, comp.getWidth() / 2, comp.getHeight() / 2);
    }

    public void click(Component comp, int mask) {
        click(comp, comp.getWidth() / 2, comp.getHeight() / 2, mask);
    }

    public void click(Component comp, int x, int y) {
        click(comp, x, y, InputEvent.BUTTON1_MASK);
    }

    public void click(Component comp, int x, int y, int mask) {
        click(comp, x, y, mask, 1);
    }

    /** Click in the given part of the component.  All other click methods
     * must eventually invoke this one.
     */
    public void click(Component comp, int x, int y, int mask, int count) {
        Log.debug("Click at (" + x + "," + y + ") on " + toString(comp));
        int keyModifiers = mask & ~BUTTON_MASK;
        mask &= BUTTON_MASK;
        setModifiers(keyModifiers, true);
        // Adjust the auto-delay to ensure we actually get a multiple click
        // In general clicks have to be less than 200ms apart, although the
        // actual setting is not readable by java that I'm aware of.
        int oldDelay = getAutoDelay();
        if (count > 1 && oldDelay * 2 > 200) setAutoDelay(50);
        mousePress(comp, x, y, mask);
        while (count-- > 1) {
            mouseRelease(mask);
            mousePress(mask);
        }
        setAutoDelay(oldDelay);
        mouseRelease(mask);
        setModifiers(keyModifiers, false);
    }

    private MenuItem findMenuItem(MenuContainer mc, String label) {
        MenuItem result = null;
        if (mc instanceof MenuBar) {
            for (int i = 0; i < ((MenuBar)mc).getMenuCount(); i++) {
                Menu menu = ((MenuBar)mc).getMenu(i);
                result = findMenuItem(menu, label);
                if (result != null) break;
            }
        } else if (mc instanceof Menu) {
            for (int i = 0; i < ((Menu)mc).getItemCount(); i++) {
                MenuItem mi = ((Menu)mc).getItem(i);
                if (mi instanceof MenuContainer) {
                    result = findMenuItem((MenuContainer)mi, label);
                    if (result != null) break;
                } else if (label.equals(mi.getLabel())) {
                    result = mi;
                    break;
                }
            }
        }
        return result;
    }

    /** Find and select the given AWT menu item.  Note that this method
     * doesn't require referencing the MenuComponent directly as a parameter.
     */
    public void selectAWTMenuItemByLabel(Frame frame, String label) {
        MenuBar mb = frame.getMenuBar();
        if (mb == null) throw new IllegalArgumentException("No MenuBar on " + toString(frame));
        MenuItem mi = findMenuItem(mb, label);
        if (mi == null) throw new IllegalArgumentException("No MenuItem '" + label + "' found on " + toString(frame));
        selectAWTMenuItem(mi);
    }

    /** Find and select the given AWT popup menu item.  */
    public void selectAWTPopupMenuItemByLabel(Component invoker, String label) {
        // FIXME don't know how to do this; it may not even be possible.
        throw new ActionFailedException(Strings.get("tester.Robot.awt_popup_failed", new Object[] {label}));
    }

    private void fireAccessibleAction(final AccessibleAction action, String name) {
        if (action != null && action.getAccessibleActionCount() == 1) {
            invokeAction(new Runnable() {

                @Override
                public void run() {
                    action.doAccessibleAction(0);
                }
            });
        } else {
            throw new ActionFailedException("Can't access menu component " + name);
        }
    }

    /** Select an AWT menu item.  */
    public void selectAWTMenuItem(MenuComponent item) {
        // Can't do this through coordinates because MenuComponents don't
        // store any of that information
        fireAccessibleAction(item.getAccessibleContext().getAccessibleAction(), toString(item));
    }

    /** Select an AWT popup menu item. */
    public void selectAWTPopupMenuItem(MenuComponent item) {
        // Can't do this through coordinates because MenuComponents don't
        // store any of that information
        fireAccessibleAction(item.getAccessibleContext().getAccessibleAction(), toString(item));
    }

    /** IS the given component ready for robot input? */
    protected boolean isReadyForInput(Component c) {
        if (eventMode == EM_AWT) return c.isShowing();
        ComponentFinder finder = DefaultComponentFinder.getFinder();
        return finder.isShowing(c);
    }

    private boolean isOnJMenuBar(Component item) {
        if (item instanceof javax.swing.JMenuBar) return true;
        Component parent = DefaultComponentFinder.getFinder().getComponentParent(item);
        return parent != null && isOnJMenuBar(parent);
    }

    /** Find and select the given menu item. */
    public void selectMenuItem(Component item) {
        Log.debug("Selecting menu item " + toString(item));
        ComponentFinder finder = DefaultComponentFinder.getFinder();
        Component parent = item.getParent();
        JPopupMenu parentPopup = null;
        if (parent instanceof JPopupMenu) {
            parentPopup = (JPopupMenu)parent;
            parent = ((JPopupMenu)parent).getInvoker();
        }
        boolean inMenuBar = parent instanceof javax.swing.JMenuBar;
        boolean isMenu = item instanceof javax.swing.JMenu;

        if (isOnJMenuBar(item) && useScreenMenuBar()) {
            // Use accessibility action instead
            fireAccessibleAction(item.getAccessibleContext().getAccessibleAction(), toString(item));
            return;
        }

        // If our parent is a menu, activate it first, if it's not already.
        if (parent instanceof javax.swing.JMenuItem) {
            if (parentPopup == null || !parentPopup.isShowing()) {
                Log.debug("Opening parent menu " + toString(parent));
                selectMenuItem(parent);
            }
        }

        // Make sure the appropriate window is in front
        if (inMenuBar) {
            final Window win = finder.getComponentWindow(parent);
            if (win != null) {
                // Make sure the window is in front, or its menus may be
                // obscured by another window.
                invokeAndWait(new Runnable() {

                    @Override
                    public void run() {
                        win.toFront();
                    }
                });
                mouseMove(win);
            }
        }

        // Activate the item
        if (isMenu && !inMenuBar) {
            // Submenus only require a mouse-over to activate
            if (subMenuDelay > autoDelay) {
                delay(subMenuDelay - autoDelay);
            }
            Log.debug("Moving over menu item " + toString(item));
            mouseMove(item);
        } else {
            // Top-level menus and menu items must be clicked on
            click(item);
            waitForIdle();
        }

        // If this item is a menu, make sure its popup is showing before we
        // return 
        if (isMenu) {
            JPopupMenu popup = ((javax.swing.JMenu)item).getPopupMenu();
            if (!waitForComponent(popup, popupDelay)) {
                String msg = "Clicking on '" + ((javax.swing.JMenu)item).getText() + "' never produced a popup menu";
                throw new ComponentMissingException(msg);
            }
            // for OSX 1.4.1; isShowing set before popup is available
            if (subMenuDelay > autoDelay) {
                delay(subMenuDelay - autoDelay);
            }
        }
    }

    /** Attempt to display a popup menu at center of the component. */
    public Component showPopupMenu(Component invoker) {
        return showPopupMenu(invoker, invoker.getWidth() / 2, invoker.getHeight() / 2);
    }

    /** Attempt to display a popup menu at the given coordinates. */
    public Component showPopupMenu(Component invoker, int x, int y) {
        String where = " at (" + x + "," + y + ")";
        Log.debug("Invoking popup " + where);
        click(invoker, x, y, POPUP_MASK);

        Component popup = DefaultComponentFinder.getFinder().findActivePopupMenu(invoker);
        if (popup == null) {
            String msg = "No popup responded to " + POPUP_MODIFIER + where + " on " + toString(invoker);
            throw new ComponentMissingException(msg);
        }
        return popup;
    }

    /** Activate the given window. */
    public void activate(final Window win) {
        // ACTIVATE means window got keyboard focus.
        // FIXME maybe do some titlebar clicking, if reliable
        invokeAndWait(new Runnable() {

            @Override
            public void run() {
                win.toFront();
            }
        });
        // For pointer-focus systems
        mouseMove(win);
    }

    protected Point getCloseLocation(Container c) {
        Dimension size = c.getSize();
        Insets insets = c.getInsets();
        if (Platform.isOSX()) {
            return new Point(insets.left + 15, insets.top / 2);
        } else {
            return new Point(size.width - insets.right - 10, insets.top / 2);
        }
    }

    /** Invoke the window close operation. */
    public void close(Window comp) {
        // Move to a corner and "pretend" to use the window manager control
        Point p = getCloseLocation(comp);
        mouseMove(comp, p.x, p.y);
        postEvent(comp, new WindowEvent(comp, WindowEvent.WINDOW_CLOSING));
    }

    protected Point getMoveLocation(Container c) {
        Dimension size = c.getSize();
        Insets insets = c.getInsets();
        return new Point(size.width / 2, insets.top / 2);
    }

    /** Move the given Frame/Dialog to the requested location. */
    public void move(Container comp, int newx, int newy) {
        Point loc = new Point(comp.getLocationOnScreen());
        moveBy(comp, newx - loc.x, newy - loc.y);
    }

    /** Move the given Window by the given amount. */
    public void moveBy(final Container comp, final int dx, final int dy) {
        final Point loc = new Point(comp.getLocationOnScreen());
        boolean userMovable = userMovable(comp);
        if (userMovable) {
            Point p = getMoveLocation(comp);
            mouseMove(comp, p.x, p.y);
            mouseMove(comp, p.x + dx, p.y + dy);
        }
        invokeAndWait(new Runnable() {

            @Override
            public void run() {
                comp.setLocation(new Point(loc.x + dx, loc.y + dy));
            }
        });
        if (userMovable) {
            Point p = getMoveLocation(comp);
            mouseMove(comp, p.x, p.y);
        }
    }

    protected Point getResizeLocation(Container c) {
        Dimension size = c.getSize();
        Insets insets = c.getInsets();
        return new Point(size.width - insets.right / 2, size.height - insets.bottom / 2);
    }

    /** Return whether it is possible for the user to move the given
        component.
    */
    protected boolean userMovable(Component comp) {
        return comp instanceof Dialog || comp instanceof Frame || canMoveWindows();
    }

    /** Return whether it is possible for the user to resize the given
        component.
    */
    protected boolean userResizable(Component comp) {
        if (comp instanceof Dialog) return ((Dialog)comp).isResizable();
        if (comp instanceof Frame) return ((Frame)comp).isResizable();
        // most X11 window managers allow arbitrary resizing
        return canResizeWindows();
    }

    /** Resize the given Frame/Dialog to the given size.  */
    public void resize(Container comp, int width, int height) {
        Dimension size = comp.getSize();
        resizeBy(comp, width - size.width, height - size.height);
    }

    /** Resize the given Frame/Dialog by the given amounts.  */
    public void resizeBy(final Container comp, final int dx, final int dy) {
        // Fake the pointer motion like we're resizing
        boolean userResizable = userResizable(comp);
        if (userResizable) {
            Point p = getResizeLocation(comp);
            mouseMove(comp, p.x, p.y);
            mouseMove(comp, p.x + dx, p.y + dy);
        }
        invokeAndWait(new Runnable() {

            @Override
            public void run() {
                comp.setSize(comp.getWidth() + dx, comp.getHeight() + dy);
            }
        });
        if (userResizable) {
            Point p = getResizeLocation(comp);
            mouseMove(comp, p.x, p.y);
        }
    }

    /** Identify the coordinates of the iconify button where we can, returning
     * null if we can't.
     */
    protected Point getIconifyLocation(Container c) {
        Dimension size = c.getSize();
        Insets insets = c.getInsets();
        // We know the exact layout of the window manager frames for w32 and
        // OSX.  Currently no way of detecting the WM under X11.  Maybe we
        // could send a WM message (WM_ICONIFY)?
        Point loc = new Point();
        if (Platform.isOSX()) {
            loc.x = 35;
            loc.y = insets.top / 2;
        } else if (Platform.isWindows()) {
            int offset = Platform.isWindowsXP() ? 64 : 45;
            loc.x = size.width - offset - insets.right;
            loc.y = insets.top / 2;
        }
        return loc;
    }

    /** Identify the coordinates of the maximize button where possible,
        returning null if not.
    */
    protected Point getMaximizeLocation(Container c) {
        // We know the exact layout of the window manager frames for w32 and
        // OSX. 
        Point loc = getIconifyLocation(c);
        if (Platform.isOSX()) {
            loc.x += 25;
        } else if (Platform.isWindows()) {
            loc.x -= 20;
        }
        return loc;
    }

    /** Iconify the given Frame.  Don't support iconification of Dialogs at
     * this point (although maybe should).
     */
    public void iconify(final Frame frame) {
        Point loc = getIconifyLocation(frame);
        if (loc != null) {
            mouseMove(frame, loc.x, loc.y);
        }
        invokeAction(new Runnable() {

            @Override
            public void run() {
                frame.setState(Frame.ICONIFIED);
            }
        });
    }

    public void deiconify(Frame frame) {
        normalize(frame);
    }

    public void normalize(final Frame frame) {
        invokeAction(new Runnable() {

            @Override
            public void run() {
                frame.setState(Frame.NORMAL);
            }
        });
    }

    /** Make the window full size.  On 1.3.1, this is not reversible. */
    public void maximize(final Frame frame) {
        Point loc = getMaximizeLocation(frame);
        if (loc != null) {
            mouseMove(frame, loc.x, loc.y);
        }
        invokeAction(new Runnable() {

            @Override
            public void run() {
                // If the maximize is unavailable, set to full screen size
                // instead. 
                try {
                    final int MAXIMIZED_BOTH = 6;
                    Boolean b =
                            (Boolean)Toolkit.class.getMethod("isFrameStateSupported", new Class[] {int.class})
                                    .invoke(toolkit, new Object[] {new Integer(MAXIMIZED_BOTH)});
                    if (b.booleanValue()) {
                        Frame.class.getMethod("setExtendedState", new Class[] {int.class,})
                                .invoke(frame, new Object[] {new Integer(MAXIMIZED_BOTH)});
                    } else {
                        throw new RuntimeException("Platform won't maximize");
                    }
                } catch (Exception e) {
                    Log.debug("Maximize not supported: " + e);
                    Rectangle rect = frame.getGraphicsConfiguration().getBounds();
                    frame.setLocation(rect.x, rect.y);
                    frame.setSize(rect.width, rect.height);
                }
            }
        });
    }

    /** Send the given event as appropriate to the event-generation mode. */
    public void sendEvent(AWTEvent event) {
        // Modifiers are ignored, assuming that an event will be
        // sent that causes modifiers to be sent appropriately.  
        if (eventMode == EM_ROBOT) {
            int id = event.getID();
            Log.debug("Sending event id " + id);
            if (id >= MouseEvent.MOUSE_FIRST && id <= MouseEvent.MOUSE_LAST) {
                MouseEvent me = (MouseEvent)event;
                Component comp = me.getComponent();
                if (id == MouseEvent.MOUSE_MOVED) {
                    mouseMove(comp, me.getX(), me.getY());
                } else if (id == MouseEvent.MOUSE_DRAGGED) {
                    mouseMove(comp, me.getX(), me.getY());
                } else if (id == MouseEvent.MOUSE_PRESSED) {
                    mouseMove(comp, me.getX(), me.getY());
                    mousePress(me.getModifiers() & BUTTON_MASK);
                } else if (id == MouseEvent.MOUSE_ENTERED) {
                    mouseMove(comp, me.getX(), me.getY());
                } else if (id == MouseEvent.MOUSE_EXITED) {
                    mouseMove(comp, me.getX(), me.getY());
                } else if (id == MouseEvent.MOUSE_RELEASED) {
                    mouseMove(comp, me.getX(), me.getY());
                    mouseRelease(me.getModifiers() & BUTTON_MASK);
                }
            } else if (id >= KeyEvent.KEY_FIRST && id <= KeyEvent.KEY_LAST) {
                KeyEvent ke = (KeyEvent)event;
                if (id == KeyEvent.KEY_PRESSED) {
                    keyPress(ke.getKeyCode());
                } else if (id == KeyEvent.KEY_RELEASED) {
                    keyRelease(ke.getKeyCode());
                }
            } else {
                Log.warn("Event not supported: " + event);
            }
        } else {
            // Post the event to the appropriate AWT event queue
            postEvent((Component)event.getSource(), event);
        }
    }

    /** Return the symbolic name of the given event's ID. */
    public static String getEventID(AWTEvent event) {
        // Optimize here to avoid field name lookup overhead
        switch (event.getID()) {
        case MouseEvent.MOUSE_MOVED:
            return "MOUSE_MOVED";
        case MouseEvent.MOUSE_DRAGGED:
            return "MOUSE_DRAGGED";
        case MouseEvent.MOUSE_PRESSED:
            return "MOUSE_PRESSED";
        case MouseEvent.MOUSE_CLICKED:
            return "MOUSE_CLICKED";
        case MouseEvent.MOUSE_RELEASED:
            return "MOUSE_RELEASED";
        case MouseEvent.MOUSE_ENTERED:
            return "MOUSE_ENTERED";
        case MouseEvent.MOUSE_EXITED:
            return "MOUSE_EXITED";
        case KeyEvent.KEY_PRESSED:
            return "KEY_PRESSED";
        case KeyEvent.KEY_TYPED:
            return "KEY_TYPED";
        case KeyEvent.KEY_RELEASED:
            return "KEY_RELEASED";
        case WindowEvent.WINDOW_OPENED:
            return "WINDOW_OPENED";
        case WindowEvent.WINDOW_CLOSING:
            return "WINDOW_CLOSING";
        case WindowEvent.WINDOW_CLOSED:
            return "WINDOW_CLOSED";
        case WindowEvent.WINDOW_ICONIFIED:
            return "WINDOW_ICONIFIED";
        case WindowEvent.WINDOW_DEICONIFIED:
            return "WINDOW_DEICONIFIED";
        case WindowEvent.WINDOW_ACTIVATED:
            return "WINDOW_ACTIVATED";
        case WindowEvent.WINDOW_DEACTIVATED:
            return "WINDOW_DEACTIVATED";
        case ComponentEvent.COMPONENT_MOVED:
            return "COMPONENT_MOVED";
        case ComponentEvent.COMPONENT_RESIZED:
            return "COMPONENT_RESIZED";
        case ComponentEvent.COMPONENT_SHOWN:
            return "COMPONENT_SHOWN";
        case ComponentEvent.COMPONENT_HIDDEN:
            return "COMPONENT_HIDDEN";
        case FocusEvent.FOCUS_GAINED:
            return "FOCUS_GAINED";
        case FocusEvent.FOCUS_LOST:
            return "FOCUS_LOST";
        case HierarchyEvent.HIERARCHY_CHANGED:
            return "HIERARCHY_CHANGED";
        case HierarchyEvent.ANCESTOR_MOVED:
            return "ANCESTOR_MOVED";
        case HierarchyEvent.ANCESTOR_RESIZED:
            return "ANCESTOR_RESIZED";
        case PaintEvent.PAINT:
            return "PAINT";
        case PaintEvent.UPDATE:
            return "UPDATE";
        case ActionEvent.ACTION_PERFORMED:
            return "ACTION_PERFORMED";
        case InputMethodEvent.CARET_POSITION_CHANGED:
            return "CARET_POSITION_CHANGED";
        case InputMethodEvent.INPUT_METHOD_TEXT_CHANGED:
            return "INPUT_METHOD_TEXT_CHANGED";
        default:
            return Reflector.getFieldName(event.getClass(), event.getID(), "");
        }
    }

    public static Class getCanonicalClass(Class refClass) {
        // Don't use classnames from anonymous inner classes...
        // Don't use classnames from platform LAF classes...
        String className = refClass.getName();
        while (className.indexOf("$") != -1
               || className.startsWith("javax.swing.plaf")
               || className.startsWith("com.apple.mrj")) {
            refClass = refClass.getSuperclass();
            className = refClass.getName();
        }
        return refClass;
    }

    /** Provides a more concise representation of the component than the
     * default Component.toString().
     */
    // FIXME getTag has too much overhead to be calling this frequently
    public static String toString(Component comp) {
        if (comp == null) return "(null)";

        Class cls = comp.getClass();
        if (cls.getName().startsWith("javax.swing.SwingUtilities")) return Strings.get("SwingDefaultFrame");

        ComponentFinder finder = DefaultComponentFinder.getFinder();
        String name = finder.getComponentName(comp);
        if (name == null) name = ComponentTester.getTag(comp);
        String classDesc = simpleClassName(cls);
        Class coreClass = getCanonicalClass(cls);
        String coreClassName = coreClass.getName();
        while (!coreClassName.startsWith("java.awt.")
               && !coreClassName.startsWith("javax.swing.")
               && !coreClassName.startsWith("java.applet.")) {
            coreClass = coreClass.getSuperclass();
            coreClassName = coreClass.getName();
        }
        if (!coreClass.equals(comp.getClass())) {
            classDesc += "/" + simpleClassName(coreClass);
        }

        if (name == null)
            name = classDesc + " instance";
        else
            name = "'" + name + "' (" + classDesc + ")";
        return name;
    }

    /** Provide a string representation of the given component (Component or
     * MenuComponent.
     */
    public static String toString(Object obj) {
        if (obj instanceof Component)
            return toString((Component)obj);
        else if (obj instanceof MenuBar)
            return "MenuBar";
        else if (obj instanceof MenuItem) return ((MenuItem)obj).getLabel();
        return obj.toString();
    }

    /** Provide a more concise representation of the event than the default
     * AWTEvent.toString().
     */
    public static String toString(AWTEvent event) {
        String name = toString(event.getSource());
        String desc = getEventID(event);
        if (event.getID() == KeyEvent.KEY_PRESSED || event.getID() == KeyEvent.KEY_RELEASED) {
            KeyEvent ke = (KeyEvent)event;
            desc += " (" + getKeyCode(ke.getKeyCode());
            if (ke.getModifiers() != 0) {
                desc += "/" + getKeyModifiers(ke.getModifiers());
            }
            desc += ")";
        } else if (event.getID() == InputMethodEvent.INPUT_METHOD_TEXT_CHANGED) {
            desc += " (" + ((InputMethodEvent)event).getCommittedCharacterCount() + ")";
        } else if (event.getID() == KeyEvent.KEY_TYPED) {
            char ch = ((KeyEvent)event).getKeyChar();
            int mods = ((KeyEvent)event).getModifiers();
            desc += " ('" + ch + (mods != 0 ? "/" + getKeyModifiers(mods) : "") + "')";
        } else if (event.getID() >= MouseEvent.MOUSE_FIRST && event.getID() <= MouseEvent.MOUSE_LAST) {
            MouseEvent me = (MouseEvent)event;
            if (me.getModifiers() != 0) {
                desc += " <" + getMouseModifiers(me.getModifiers());
                if (me.getClickCount() > 1) {
                    desc += "," + me.getClickCount();
                }
                desc += ">";
            }
            desc += " (" + me.getX() + "," + me.getY() + ")";
        } else if (event.getID() == HierarchyEvent.HIERARCHY_CHANGED) {
            HierarchyEvent he = (HierarchyEvent)event;
            long flags = he.getChangeFlags();
            String type = "";
            String bar = "";
            if ((flags & HierarchyEvent.SHOWING_CHANGED) != 0) {
                type += (he.getComponent().isShowing() ? "" : "!") + "SHOWING";
                bar = "|";
            }
            if ((flags & HierarchyEvent.PARENT_CHANGED) != 0) {
                type += bar + "PARENT:" + toString(he.getComponent().getParent());
                bar = "|";
            }
            if ((flags & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0) {
                type += bar + "DISPLAYABILITY";
            }
            desc += " (" + type + ")";
        }
        return desc + " on " + name;
    }

    /** Return the numeric event ID corresponding to the given string. */
    public static int getEventID(Class cls, String id) {
        return Reflector.getFieldValue(cls, id);
    }

    /** Convert the string representation into the actual modifier mask. */
    public static int getModifiers(String mods) {
        int value = 0;
        if (mods != null && !mods.equals("")) {
            StringTokenizer st = new StringTokenizer(mods, "| ");
            while (st.hasMoreTokens()) {
                String flag = st.nextToken();
                if (POPUP_MODIFIER.equals(flag))
                    value |= POPUP_MASK;
                else if (TERTIARY_MODIFIER.equals(flag))
                    value |= TERTIARY_MASK;
                else if (!flag.equals("0")) value |= Reflector.getFieldValue(InputEvent.class, flag);
            }
        }
        return value;
    }

    private static String getModifiers(int flags, boolean isKey, boolean isMouse) {
        // On a mac, ALT+BUTTON1 means BUTTON2; META+BUTTON1 means BUTTON3
        int macModifiers = InputEvent.CTRL_MASK | InputEvent.ALT_MASK | InputEvent.META_MASK;
        boolean isMacButton = isMouse && Platform.isMacintosh() && (flags & macModifiers) != 0;
        String mods = "";
        String or = "";
        if ((flags & InputEvent.ALT_GRAPH_MASK) != 0) {
            mods += or + "ALT_GRAPH_MASK";
            or = "|";
            flags &= ~InputEvent.ALT_GRAPH_MASK;
        }
        if ((flags & InputEvent.BUTTON1_MASK) != 0 && !isMacButton) {
            mods += or + "BUTTON1_MASK";
            or = "|";
            flags &= ~InputEvent.BUTTON1_MASK;
        }
        // Mask for ALT is the same as MB2
        if ((flags & InputEvent.ALT_MASK) != 0 && !isMacButton && !isMouse) {
            mods += or + "ALT_MASK";
            or = "|";
            flags &= ~InputEvent.ALT_MASK;
        }
        // Mac uses ctrl modifier to get MB2
        if ((flags & InputEvent.CTRL_MASK) != 0 && !isMacButton) {
            mods += or + "CTRL_MASK";
            or = "|";
            flags &= ~InputEvent.CTRL_MASK;
        }
        // Mask for META is the same as MB3
        if ((flags & InputEvent.META_MASK) != 0 && !isMacButton && !isMouse) {
            mods += or + "META_MASK";
            or = "|";
            flags &= ~InputEvent.META_MASK;
        }
        if ((flags & POPUP_MASK) != 0) {
            mods += or + "POPUP_MASK";
            or = "|";
            flags &= ~POPUP_MASK;
        }
        if ((flags & TERTIARY_MASK) != 0) {
            mods += or + "TERTIARY_MASK";
            or = "|";
            flags &= ~TERTIARY_MASK;
        }
        if ((flags & InputEvent.SHIFT_MASK) != 0) {
            mods += or + "SHIFT_MASK";
            or = "|";
            flags &= ~InputEvent.SHIFT_MASK;
        }
        // Empty strings are confusing and invisible; make it explicit
        if ("".equals(mods)) mods = "0";
        return mods;
    }

    public static String getKeyModifiers(int flags) {
        return getModifiers(flags, true, false);
    }

    public static String getMouseModifiers(int flags) {
        return getModifiers(flags, false, true);
    }

    /** Convert the integer modifier flags into a string representation. */
    public static String getModifiers(InputEvent event) {
        return getModifiers(event.getModifiers(), event instanceof KeyEvent, event instanceof MouseEvent);
    }

    public static String getKeyCode(int keycode) {
        return Reflector.getFieldName(KeyEvent.class, keycode, "VK_");
    }

    public static int getKeyCode(String code) {
        return Reflector.getFieldValue(KeyEvent.class, code);
    }

    /** Is the given component on a popup? */
    public static boolean isOnPopup(Component comp) {
        boolean isPopup = abbot.util.AWT.isTransientPopup(comp);
        return isPopup || (comp.getParent() != null && isOnPopup(comp.getParent()));
    }

    /** Strip the package from the class name. */
    public static String simpleClassName(Class cls) {
        String name = cls.getName();
        int dot = name.lastIndexOf(".");
        return name.substring(dot + 1, name.length());
    }

    public static boolean isModifier(int keycode) {
        switch (keycode) {
        case KeyEvent.VK_META:
        case KeyEvent.VK_ALT:
        case KeyEvent.VK_ALT_GRAPH:
        case KeyEvent.VK_CONTROL:
        case KeyEvent.VK_SHIFT:
            return true;
        default:
            return false;
        }
    }

    public static int keyCodeToMask(int code) {
        switch (code) {
        case KeyEvent.VK_META:
            return InputEvent.META_MASK;
        case KeyEvent.VK_ALT:
            return InputEvent.ALT_MASK;
        case KeyEvent.VK_ALT_GRAPH:
            return InputEvent.ALT_GRAPH_MASK;
        case KeyEvent.VK_CONTROL:
            return InputEvent.CTRL_MASK;
        case KeyEvent.VK_SHIFT:
            return InputEvent.SHIFT_MASK;
        default:
            throw new IllegalArgumentException("Keycode is not a modifier: " + code);
        }
    }

    /** Convert the given modifier event mask to the equivalent key code. */
    public static int maskToKeyCode(int mask) {
        switch (mask) {
        case InputEvent.META_MASK:
            return KeyEvent.VK_META;
        case InputEvent.ALT_MASK:
            return KeyEvent.VK_ALT;
        case InputEvent.ALT_GRAPH_MASK:
            return KeyEvent.VK_ALT_GRAPH;
        case InputEvent.CTRL_MASK:
            return KeyEvent.VK_CONTROL;
        case InputEvent.SHIFT_MASK:
            return KeyEvent.VK_SHIFT;
        default:
            throw new IllegalArgumentException("Unrecognized mask '" + mask + "'");
        }
    }

    private AWTEvent lastEventPosted = null;

    private MouseEvent lastMousePress = null;

    /** Post the given event to the corresponding event queue for the given
        component. */
    protected void postEvent(Component comp, AWTEvent ev) {
        Log.debug("POST: " + toString(ev));
        // Force an update of the input state, so that we're in synch
        // internally.  Otherwise we might post more events before this
        // one gets processed and end up using stale values for those events.
        state.update(ev);
        comp.getToolkit().getSystemEventQueue().postEvent(ev);
        delay(autoDelay);
        AWTEvent prev = lastEventPosted;
        lastEventPosted = ev;
        if (ev.getID() == MouseEvent.MOUSE_PRESSED) lastMousePress = (MouseEvent)ev;

        // Generate a click if there are no events between press/release
        // Unfortunately, I can only guess how the VM generates them
        if (eventMode == EM_AWT && ev.getID() == MouseEvent.MOUSE_RELEASED && prev.getID() == MouseEvent.MOUSE_PRESSED) {
            MouseEvent me = (MouseEvent)ev;
            AWTEvent click =
                    new MouseEvent(comp,
                                   MouseEvent.MOUSE_CLICKED,
                                   System.currentTimeMillis(),
                                   me.getModifiers(),
                                   me.getX(),
                                   me.getY(),
                                   me.getClickCount(),
                                   false);
            postEvent(comp, click);
        }
    }

    /** Wait for the given Condition to return true.  The default timeout may
     * be changed by setting abbot.robot.default_delay.
     * @throws WaitTimedOutError if the default timeout (30s) is exceeded. 
     */
    public void wait(Condition condition) {
        wait(condition, defaultDelay);
    }

    /** Wait for the given Condition to return true, waiting for timeout ms.
     * @throws WaitTimedOutError if the timeout is exceeded. 
     */
    public void wait(Condition condition, long timeout) {
        wait(condition, timeout, SLEEP_INTERVAL);
    }

    /** Wait for the given Condition to return true, waiting for timeout ms,
     * polling at the given interval.
     * @throws WaitTimedOutError if the timeout is exceeded. 
     */
    public void wait(Condition condition, long timeout, int interval) {
        long start = System.currentTimeMillis();
        while (!condition.test()) {
            if (System.currentTimeMillis() - start > timeout) {
                String msg = "Timed out waiting for " + condition;
                throw new WaitTimedOutError(msg);
            }
            delay(interval);
        }
    }

    private static java.util.List<String> bugList = null;

    private static boolean gotBug1Event = false;

    /** Check for all known robot-related bugs that will affect Abbot
     * operation.  Returns a String for each bug detected on the current
     * system. 
     */
    public static String[] bugCheck(final Window window) {
        if (bugList == null) {
            bugList = new java.util.ArrayList<String>();
            if (Platform.isWindows() && Platform.getJavaVersionNumber() < Platform.JAVA_1_4) {
                Log.debug("Checking for w32 bugs");
                final int x = window.getWidth() / 2;
                final int y = window.getHeight() / 2;
                final int mask = InputEvent.BUTTON2_MASK;
                MouseAdapter ma = new MouseAdapter() {

                    @Override
                    public void mouseClicked(MouseEvent ev) {
                        Log.debug("Got " + Robot.toString(ev));
                        gotBug1Event = true;
                        // w32 acceleration bug
                        if (ev.getSource() != window || ev.getX() != x || ev.getY() != y) {
                            bugList.add(Strings.get("Bug1"));
                        }
                        // w32 mouse button mapping bug
                        if ((ev.getModifiers() & mask) != mask) {
                            bugList.add(Strings.get("Bug2"));
                        }
                    }
                };
                window.addMouseListener(ma);
                Robot tRobot = new Robot();
                tRobot.click(window, x, y, mask);
                tRobot.waitForIdle();
                window.removeMouseListener(ma);
                window.toFront();
                // Bogus acceleration may mean the event goes entirely
                // elsewhere 
                if (!gotBug1Event) {
                    bugList.add(0, Strings.get("Bug1"));
                }
            }
        }
        return bugList.toArray(new String[bugList.size()]);
    }

    public void resetPointer() {
        if (eventMode == EM_ROBOT) {
            Dimension d = toolkit.getScreenSize();
            mouseMove(d.width / 2, d.height / 2);
            mouseMove(d.width / 2 - 1, d.height / 2 - 1);
        }
    }

    /** Return the Component which currently owns the focus. */
    public static Component findFocusOwner() {
        Window[] wl = DefaultComponentFinder.getFinder().getWindows();
        Component focus = null;
        for (int i = 0; i < wl.length && focus == null; i++) {
            focus = wl[i].getFocusOwner();
        }
        return focus;
    }

    /** Prior to 1.4.1, hierarchy events are only sent if listeners are added
        to a given component.
     */
    public static boolean hasHierarchyEventGenerationBug() {
        return Platform.getJavaVersionNumber() < Platform.JAVA_1_4;
    }

    /** OSX prior to 1.4 has really crappy key input handling. */
    public static boolean hasKeyStrokeGenerationBug() {
        return Platform.isOSX() && Platform.getJavaVersionNumber() < Platform.JAVA_1_4;
    }

    /** Do we get multiple clicks even when the individual clicks are on
     * different frames?
     */
    // Will we get incorrectly get multiple clicks on rapid robot clicks?
    // frame1->click,frame2->click 
    // frame1->click,frame1->hide/show,frame1->click
    public static boolean hasMultiClickFrameBug() {
        // w32 (1.3.02) will count it even if it was on a different component!
        // w32 (1.3.1_06) same
        // w32 (1.4.1_02) same (sporadic)
        // OSX (1.3.x, 1.4.1) has the same problem
        // Haven't seen it on linux
        return Platform.isWindows() || Platform.isOSX() || Platform.getJavaVersionNumber() < Platform.JAVA_1_3;
    }

    /** OS X (as of 1.3.1, v10.1.5), will sometimes send a click to the wrong
        component after a mouse move.  This continues to be an issue in 1.4.1
        <p>
        Linux x86 (1.3.1) has a similar problem, although it manifests it at
        different times (need a bug test case for this one).
        <p>
        Solaris and HPUX probably share code with the linux VM implementation,
        so the bug there is probably identical.
        <p>
    */
    // FIXME add tests to determine presence of bug.
    public static boolean hasRobotMotionBug() {
        return Platform.isOSX()
               || (!Platform.isWindows() && Platform.getJavaVersionNumber() < Platform.JAVA_1_4)
               || Boolean.getBoolean("abbot.robot.need_jitter");
    }

    /** Returns whether it is possible to resize windows that are not an
        instance of Frame or Dialog.  Most X11 window managers will allow
        this, but stock Macintosh and Windows do not.
    */
    public static boolean canResizeWindows() {
        return !Platform.isWindows() && !Platform.isMacintosh();
    }

    /** Returns whether it is possible to move windows that are not an
        instance of Frame or Dialog.  Most X11 window managers will allow
        this, but stock Macintosh and Windows do not.
    */
    public static boolean canMoveWindows() {
        return !Platform.isWindows() && !Platform.isMacintosh();
    }

    /** Returns the appropriate auto delay for robot-generated events. */
    public static int getPreferredRobotAutoDelay() {
        if (Platform.isWindows() || Platform.isOSX() || Platform.isLinux()) return 0;
        return 50;
    }
}
