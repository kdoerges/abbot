package abbot.tester;

import java.awt.Component;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JTree;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

/** Provide operations on a JTree component. */
// TODO: multi-select
public class JTreeTester extends JComponentTester {

    /** Convert the given row to an x,y coordinate.
        @throws ActionFailedException if the row is not available.
     */
    protected Point rowToPoint(Component c, int row) {
        JTree tree = (JTree)c;
        TreePath path = tree.getPathForRow(row);
        if (path == null)
            throw new ActionFailedException("Row " + row + " is not visible");
        Rectangle rect = tree.getPathBounds(path);
        return new Point(rect.x + rect.width/2, rect.y + rect.height/2);
    }

    /** Select the given row.  If the row is already selected, does nothing. */
    public void actionSelectRow(Component tree, int row) {
        if (((JTree)tree).getLeadSelectionRow() == row)
            return;
        actionClickRow(tree, row);
    }

    /** Simple click on the given row. */
    public void actionClickRow(Component tree, int row) {
        actionClickRow(tree, row, "BUTTON1_MASK", 1);
    }

    /** Click with modifiers on the given row. */
    public void actionClickRow(Component tree, int row, String modifiers) {
        actionClickRow(tree, row, modifiers, 1);
    }

    /** Multiple click on the given row. */
    public void actionClickRow(Component c, int row,
                               String modifiers, int count) {
        Point pt = rowToPoint(c, row);
        actionClick(c, pt.x, pt.y, modifiers, count);
    }

    TreePath convertPath(TreeModel model, TreePath path) {
        return convertPath(model, model.getRoot(), path.getPath());
    }

    /** Given a TreePath of Strings, return the equivalent TreePath for the
        given JTree.  If necessary, expands nodes in the tree until the
        requested path is fully visible. 
    */
    private TreePath convertPath(TreeModel model, Object obj, Object[] objs) {
        // The given array is a tree path of Strings, not node objects, so it
        // must be converted to existing tree objects first.  Fail if any of
        // them are not found.
        if (objs.length == 1) {
            if (obj.toString().equals(objs[0].toString())) {
                return new TreePath(obj);
            }
        }
        else {
            Object[] subs = new Object[objs.length-1];
            System.arraycopy(objs, 1, subs, 0, subs.length);
            int count = model.getChildCount(obj);
            for (int i=0;i < count;i++) {
                if (!obj.toString().equals(objs[0].toString()))
                    continue;
                Object child = model.getChild(obj, i);
                TreePath path = convertPath(model, child, subs);
                if (path != null) {
                    // Get the converted path
                    subs = path.getPath();
                    System.arraycopy(subs, 0, objs, 1, subs.length);
                    objs[0] = obj;
                    return new TreePath(objs);
                }
            }
        }
        return null;
    }

    /** Return the TreePath sans the last element, or null if there's only one
     * element.
     */
    protected TreePath makeParentPath(TreePath path) {
        Object[] objs = path.getPath();
        if (objs.length == 1) {
            return null;
        }
        Object[] pobjs = new Object[objs.length - 1];
        System.arraycopy(objs, 0, pobjs, 0, pobjs.length);
        return new TreePath(pobjs);
    }

    /** Returns whether action was taken. */
    protected boolean makeVisible(Component c, TreePath path) {
        JTree tree = (JTree)c;
        if (!tree.isVisible(path)) {
            // Make the parent visible, then toggle the parent
            TreePath parent = makeParentPath(path);
            if (makeVisible(tree, parent)) {
                waitForIdle();
            }
            actionToggleRow(tree, tree.getRowForPath(parent));
            return true;
        }
        return false;
    }

    /** Ensure all elements of the given path are visible. */
    public void actionMakeVisible(Component c, TreePath path) {
        JTree tree = (JTree)c;
        if (makeVisible(tree, path)) {
            waitForIdle();
        }
    }

    /** Select the given path, expanding parent nodes if necessary. */
    public void actionSelectPath(Component c, TreePath path) {
        JTree tree = (JTree)c;
        TreeModel model = tree.getModel();
        TreePath actual = convertPath(model, path);
        if (actual == null) {
            throw new ActionFailedException("Path " + path + " not found");
        }
        actionMakeVisible(tree, actual);
        int row = tree.getRowForPath(actual);
        if (row == -1) {
            throw new ActionFailedException("Row for path " + actual
                                            + " not found");
        }
        actionSelectRow(tree, row);
    }

    /** Find the center of the expand control for the given row. */
    /*
    protected Point getExpandControlLocation(Component c, int row) {
        JTree tree = (JTree)c;
        BasicTreeUI ui = (BasicTreeUI)tree.getUI();
        Icon icon = tree.isExpanded(row)
            ? ui.getExpandedIcon() : ui.getCollapsedIcon();
        int width = icon.getIconWidth();
        int height = icon.getIconHeight();
        // FIXME not done yet
        return new Point(0, 0);
    }
    */

    /** Change the open/closed state of the given row, if possible. */
    public void actionToggleRow(Component c, int row) {
        JTree tree = (JTree)c;
        //Point pt = getExpandControlLocation(tree, row);
        // FIXME click once on the expand icon instead of relying on the click
        // count on the row itself
        actionClickRow(tree, row, "BUTTON1_MASK",
                       tree.getToggleClickCount());
    }

    /** Select a popup menu item at the given row. */
    public void actionSelectPopupMenuItemAtRow(Component c, int row,
                                               String item) {
        Point pt = rowToPoint(c, row);
        actionSelectPopupMenuItem(c, pt.x, pt.y, item);
    }

    /** Activate a popup menu item at the given row. */
    public void actionShowPopupMenuAtRow(Component c, int row) {
        Point pt = rowToPoint(c, row);
        actionShowPopupMenu(c, pt.x, pt.y);
    }
}
