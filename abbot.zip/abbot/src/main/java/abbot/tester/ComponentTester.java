package abbot.tester;

import java.awt.Component;
import java.awt.Frame;
import java.awt.Window;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.accessibility.AccessibleContext;
import javax.accessibility.AccessibleIcon;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import testframework.testrunner.RTVariablesSingleton;
import util.GUIUtil;
import abbot.BugReport;
import abbot.ComponentFinder;
import abbot.ComponentNotFoundException;
import abbot.Condition;
import abbot.DefaultComponentFinder;
import abbot.Log;
import abbot.MultipleComponentsFoundException;
import abbot.Regexp;
import abbot.WaitTimedOutError;
import abbot.script.ComponentReference;
import extensions.system.TestScriptRunner;
import extensions.util.AbbotI18NUtil;


/** Provide basic actions and assertions for anything of class Component.
    Derive from this class to implement actions and assertions specific to
    a given component class.  Actions are generally user-driven actions such
    as menu selection, table selection, popup menus, etc.  Assertions are
    either independent of any component (and should be implemented in this
    class), or take a component as the first argument, and perform some check
    on that component.  Testers for any classes found in the JRE should be in
    the <code>abbot.tester</code> package.  Extensions (testers for any
    Component subclasses not found in the JRE) must be in the
    <code>abbot.tester.extensions</code> package and be named the name of
    the Component subclass followed by "Tester".  For example, the
    javax.swing.JButton tester class is
    <code>abbot.tester.JButtonTester</code>, and a tester for org.me.MyButton
    would be <code>abbot.tester.extensions.MyButton</code>.  
    <p> 
    All actions should have the following signature:<br>
    <code>public void actionWhat(Component c, ...);</code><br>
    It is essential that the argument is of type Component; if you use a more
    derived class then the actual invocation becomes ambiguous since method
    parsing doesn't attempt to determine which identically-named method is the
    most-derived.
    NOTE: All actions should ensure that the actions they trigger are finished
    or will be finished before subsequent operations before returning.

    All assertions should have one of the following signatures:<br>
    <code>public boolean assertWhat(...);</code>
    <code>public boolean assertWhat(Component c, ...);</code><p>

    <br>FIXME need an explanation about how this assert (which returns boolean)
    is different from the Assert, which will throw<br>

    Property checks may also be implemented in cases where the component
    "property" might not be readily available or easily comparable, e.g.
    see <code>JPopupMenuTester.getMenuLabels()</code>.<br>
    <code>public Object getProperty(Component c);</code>
    <code>public boolean isProperty(Component c);</code><p>

    Be careful not to name any support methods with the property signature,
    since these are scanned dynamically to populate the editor's action
    menus.<p>

    There are two sets of event-generating methods.  The internal, protected
    methods inherited from abbot.tester.Robot are for normal programmatic use
    within derived Tester classes.  No event queue synchronization should be
    performed except when modifying a component.<p>

    The public actionX functions are meant to be invoked from a script or
    directly from a hand-written test.  These actions are distinguished by
    name and number of arguments, but <b>not</b> by argument type.  Therefore
    you should be very careful when overloading actionX method names.  The
    actionX methods will be synchronized with the event dispatch thread when
    invoked, so you should only do synchronization with waitForIdle when
    performing several consecutively dependent steps.<p>

    Add-on tester classes should set the following system properties so that
    the actions provided by their tester can be properly displayed in the
    script editor.  For an action "actionWiggle" provided by class
    abbot.tester.extensions.ExtendedTester, the following properties 
    should be defined:<br>
    <ul>
    <li><code>actionWiggle.menu</code> short name for Insert menu
    <li><code>actionWiggle.desc</code> short description
    <li><code>actionWiggle.icon</code> icon for the action
    <li><code>ExtendedTester.actionWiggle.args</code> javadoc-style description of method
    </ul>
    The simple class name is required for the args property to avoid
    collisions with other Testers which may have the same method.
    <p>
*/
public class ComponentTester extends Robot {

    private static final Logger logger = LoggerFactory.getLogger(ComponentTester.class);

    /** Maps class names to their corresponding Tester object. */
    private static Map<String, ComponentTester> testers = new ConcurrentHashMap<String, ComponentTester>();

    /** Establish the given ComponentTester as the one to use for the given
     * class.  This may be used to override the default tester for a given
     * core class.  Note that this will only work with components loaded by
     * the framework class loader, not those loaded by the class loader for
     * the code under test.
     */
    public static void setTester(Class forClass, ComponentTester tester) {
        testers.put(forClass.getName(), tester);
    }

    /** Return the appropriate Tester for the given object. */
    public static ComponentTester getTester(Component comp) {
        return comp != null ? getTester(comp.getClass()) : getTester(Component.class);
    }

    /** Find the corresponding Tester object for the given component class,
        chaining up the inheritance tree if no specific tester is found for
        that class.<p>
        The abbot tester package is searched first, followed by the tester
        extensions package.
    */
    public static ComponentTester getTester(Class componentClass) {
        String className = componentClass.getName();
        ComponentTester tester = testers.get(className);
        if (tester == null) {
            if (!Component.class.isAssignableFrom(componentClass)) {
                String msg = "Class " + className + " is not derived from java.awt.Component";
                throw new IllegalArgumentException(msg);
            }
            Log.debug("Looking up tester for " + componentClass);
            String testerName = simpleClassName(componentClass) + "Tester";
            Package pkg = ComponentTester.class.getPackage();
            String pkgName = "";
            if (pkg == null) {
                Log.warn("ComponentTester.class has null package: "
                         + ComponentTester.class.getClassLoader()
                         + ", "
                         + Thread.currentThread().getContextClassLoader());
                pkgName = "abbot.tester";
            } else {
                pkgName = pkg.getName();
            }
            if (className.startsWith("javax.swing.") || className.startsWith("java.awt.")) {
                tester = findTester(pkgName + "." + testerName, componentClass);
            }
            if (tester == null) {
                tester = findTester(pkgName + ".extensions." + testerName, componentClass);
                if (tester == null) {
                    tester = getTester(componentClass.getSuperclass());
                }
            }
            if (tester != null && !tester.isExtension()) {
                // Only cache it if it's part of the standard framework,
                // but cache it for every level that we looked up, so we
                // don't repeat the effort.
                testers.put(componentClass.getName(), tester);
            }
        }

        return tester;
    }

    /** Return whether this tester is an extension. */
    public final boolean isExtension() {
        return getClass().getName().startsWith("abbot.tester.extensions");
    }

    /** Look up the given class, using special class loading rules to maintain
        framework consistency. */
    private static Class resolveClass(String testerName, Class componentClass) throws ClassNotFoundException {
        // Extension testers must be loaded in the context of the code under
        // test.
        Class cls;
        if (testerName.startsWith("abbot.tester.extensions")) {
            cls = Class.forName(testerName, true, componentClass.getClassLoader());
        } else {
            cls = Class.forName(testerName);
        }
        Log.debug("Loaded class " + testerName + " with " + cls.getClassLoader());
        return cls;
    }

    /** Look up the given class with a specific class loader. */
    private static ComponentTester findTester(String testerName, Class componentClass) {
        ComponentTester tester = null;
        Class testerClass = null;
        try {
            testerClass = resolveClass(testerName, componentClass);
            tester = (ComponentTester)testerClass.newInstance();
        } catch (InstantiationException ie) {
            Log.warn(ie);
        } catch (IllegalAccessException iae) {
            Log.warn(iae);
        } catch (ClassNotFoundException cnf) {
            //Log.debug("Class " + testerName + " not found");
        } catch (ClassCastException cce) {
            throw new BugReport("Class loader conflict: environment "
                                + ComponentTester.class.getClassLoader()
                                + " vs. "
                                + testerClass.getClassLoader());
        }

        return tester;
    }

    protected ComponentFinder getFinder() {
        return DefaultComponentFinder.getFinder();
    }

    /** Derive a tag from the given accessible context if possible, or return
     * null.
     */
    protected String deriveAccessibleTag(AccessibleContext context) {
        String tag = null;
        if (context != null) {
            if (context.getAccessibleName() != null) {
                tag = context.getAccessibleName();
            }
            if ((tag == null || "".equals(tag))
                && context.getAccessibleIcon() != null
                && context.getAccessibleIcon().length > 0) {
                AccessibleIcon[] icons = context.getAccessibleIcon();
                tag = icons[0].getAccessibleIconDescription();
                if (tag != null) {
                    tag = tag.substring(tag.lastIndexOf("/") + 1);
                    tag = tag.substring(tag.lastIndexOf("\\") + 1);
                }
            }
        }
        return tag;
    }

    /** Default methods to use to derive a component-specific tag.  These are
     * things that will probably be useful in a custom component if the method
     * is supported.
     */
    private static final String[] tagMethods = {"getLabel", "getTitle", "getText"};

    /** Return a reasonable identifier for the given component. */
    public static String getTag(Component comp) {
        return getTester(comp.getClass()).deriveTag(comp);
    }

    /** Provide a String that is fairly distinct for the given component.  For
     * a generic component, attempt to look up some common patterns such as a
     * title or label.  Derived classes should absolutely override this method
     * if such a String exists.<p>
     * Don't use component names as tags.<p>
     */
    public String deriveTag(Component comp) {
        Method m;
        String tag = null;


        if (ComponentReference.isOldConventionMode()) {
            // Try a few default methods
            for (int i = 0; i < tagMethods.length; i++) {
                // Don't use getText on text components
                if (((comp instanceof javax.swing.text.JTextComponent) || (comp instanceof java.awt.TextComponent))
                    && "getText".equals(tagMethods[i])) {
                    continue;
                }
                try {
                    m = comp.getClass().getMethod(tagMethods[i], new Class[] {});
                    String tmp = (String)m.invoke(comp, new Object[] {});
                    // Don't ever use empty strings for tags
                    if (tmp != null && !"".equals(tmp)) {
                        tag = tmp;
                        break;
                    }
                } catch (Exception e) {}
            }

        }
        // In the absence of any other tag, try to derive one from something
        // recognizable on one of its ancestors.
        if (tag == null || "".equals(tag)) {
            Component parent = comp.getParent();
            if (parent != null) {
                String ptag = getTag(parent);
                if (ptag != null && !"".equals(tag)) {
                    // Don't use the tag if it's simply the window title; that
                    // doesn't provide any extra information.
                    if (!ptag.endsWith(" Root Pane")) {
                        StringBuffer buf = new StringBuffer(ptag);
                        int under = ptag.indexOf(" under ");
                        if (under != -1) buf = buf.delete(0, under + 7);
                        buf.insert(0, " under ");
                        buf.insert(0, simpleClassName(comp.getClass()));
                        tag = buf.toString();
                    }
                }
            }
        }

        return tag;
    }

    /**
     * Wait for an idle AWT event queue.  Will return when there are no more
     * events on the event queue.
     */
    public void actionWaitForIdle() {
        waitForIdle();
    }

    /** Delay the given number of ms. */
    public void actionDelay(int ms) {
        delay(ms);
    }

    public void actionSelectAWTMenuItemByLabel(Frame frame, String label) {
        selectAWTMenuItemByLabel(frame, label);
    }

    public void actionSelectAWTPopupMenuItemByLabel(Component invoker, String label) {
        selectAWTPopupMenuItemByLabel(invoker, label);
    }

    // FIXME support both menu versions - press & drag vs click & move
    // FIXME do actionSelectMenuItemByName in addition to by component
    // FIXME do actionSelectMenuItemByPath (for dynamics) which follows labels
    /** Select the given menu item. */
    public void actionSelectMenuItem(Component item) {
        Log.debug("Attempting to select menu item " + toString(item));
        selectMenuItem(item);
    }

    /** Pop up a menu at the given location on the given component;
        Select the given item.
     */
    public void actionSelectPopupMenuItem(Component invoker, String itemName) {
        actionSelectPopupMenuItem(invoker, invoker.getWidth() / 2, invoker.getHeight() / 2, itemName);
    }

    /** Pop up a menu at the given location on the given component;
        Select the given item.
     */
    public void actionSelectPopupMenuItem(Component invoker, int x, int y, String itemName) {
        if (x == -1) x = invoker.getWidth() / 2;
        if (y == -1) y = invoker.getHeight() / 2;
        Log.debug("Attempting to select popup menu item " + itemName + " on " + toString(invoker));
        Component popup = showPopupMenu(invoker, x, y);
        Component item = getFinder().findMenuItemByName(popup, itemName);
        if (item == null) throw new ComponentMissingException("Can't find menu item '" + itemName + "'");
        selectMenuItem(item);
        waitForIdle();
    }

    /** Pop up a menu in the center of the given component. */
    public void actionShowPopupMenu(Component invoker) {
        showPopupMenu(invoker);
    }

    /** Pop up a menu at the given location on the given component. */
    public void actionShowPopupMenu(Component invoker, int x, int y) {
        showPopupMenu(invoker, x, y);
    }

    /** Click on the center of the component. */
    public void actionClick(Component comp) {
        actionClick(comp, comp.getWidth() / 2, comp.getHeight() / 2);
    }

    /** Click on the component at the given location. */
    public void actionClick(Component comp, int x, int y) {
        actionClick(comp, x, y, "BUTTON1_MASK");
    }

    /** Click on the component at the given location.  The buttons string
     * should be the InputEvent field name for the desired masks, e.g.
     * "BUTTON1_MASK|CTRL_MASK".
     */
    public void actionClick(Component comp, int x, int y, String buttons) {
        actionClick(comp, x, y, buttons, 1);
    }

    /** Click on the component at the given location.  The buttons string
     * should be the InputEvent field name for the desired masks, e.g.
     * "BUTTON1_MASK|CTRL_MASK".  This variation provides for multiple
     * clicks.
     */
    public void actionClick(Component comp, int x, int y, String buttons, int count) {
        click(comp, x, y, getModifiers(buttons), count);
        waitForIdle();
    }

    /**
     * Used only for modifier keys.  Otherwise, use actionKeyStroke
     * instead.
     */
    public void actionKeyPress(String kc) {
        keyPress(getKeyCode(kc));
        waitForIdle();
    }

    /**
     * Usually used only for modifier keys.  Otherwise, use actionKeyStroke
     * instead.
     */
    public void actionKeyRelease(String kc) {
        keyRelease(getKeyCode(kc));
        waitForIdle();
    }

    /**
     * Send the given keystroke, which must be the KeyEvent field name of a
     * KeyEvent VK_ constant to the program.  Sends a key down/up, with no
     * modifiers.  Note that this does not affect the current focus.
     */
    public void actionKeyStroke(String kc) {
        actionKeyStroke(kc, "0");
    }

    /**
     * Send the given keystroke, which must be the KeyEvent field name of a
     * KeyEvent VK_ constant to the program.  Sends a key down/up, with the
     * given modifiers, which should be the InputEvent field name modifier
     * masks optionally ORed together with "|".  Note that this does not
     * affect the current focus.<p>
     * NOTE: on OSX, the wait for idle is not sufficient to process the entire
     * keystroke.
     */
    public void actionKeyStroke(String kc, String mods) {
        int keycode = getKeyCode(kc);
        int modifiers = getModifiers(mods);
        if (Robot.hasKeyStrokeGenerationBug()) {
            int oldDelay = getAutoDelay();
            setAutoDelay(50);
            key(keycode, modifiers);
            setAutoDelay(oldDelay);
            delay(100);
        } else {
            key(keycode, modifiers);
        }
        waitForIdle();
    }

    /** Send events required to generate the given string. */
    public void actionKeyString(String string) {
        keyString(string);
        // FIXME waitForIdle isn't always sufficient on OSX with key events
        if (Robot.hasKeyStrokeGenerationBug()) {
            delay(100);
        }
        waitForIdle();
    }

    /** Set the focus on to the given component. */
    public void actionFocus(final Component comp) {
        focus(comp, true);
    }

    /** Perform a drag action.  Derived classes should provide more specific
     * identifiers for what is being dragged, e.g. actionDragTableCell or
     * actionDragListElement.
     */
    public void actionDrag(Component dragSource, int sx, int sy) {
        actionDrag(dragSource, sx, sy, "BUTTON1_MASK");
    }

    /** Perform a drag action.  Derived classes should provide more specific
     * identifiers for what is being dragged, e.g. actionDragTableCell or
     * actionDragListElement.   The modifiers represents the set of active
     * button modifiers when the drop is made.
     */
    public void actionDrag(Component dragSource, int sx, int sy, String modifiers) {
        drag(dragSource, sx, sy, getModifiers(modifiers));
        waitForIdle();
    }

    /** Perform a basic drop action (implicitly causing a preceding mouse
     * drag).  The modifiers represents the set of active modifiers when the
     * drop is made.
     */
    public void actionDrop(Component dropTarget, int x, int y) {
        drop(dropTarget, x, y);
        waitForIdle();
    }


    /** Return whether the component's contents matches the given image. */
    public boolean assertImage(Component comp, java.io.File fileImage, boolean ignoreBorder) {
        java.awt.image.BufferedImage img = capture(comp, ignoreBorder);
        return new ImageComparator().compare(img, fileImage) == 0;
    }

    /** Returns whether a Window corresponding to the given String is
     * showing.  The string may be a plain String or regular expression and
     * may match either the window title (for Frames or Dialogs) or its
     * Component name. 
     */
    public boolean assertFrameShowing(String identifier) {
        Log.debug("Looking for '" + identifier + "'");
        try {

            //abbot_ext_begin

            Window w = null;

            boolean tempIsVariableIdentifier = (identifier.startsWith("$") && (identifier.endsWith("$")));
            if (tempIsVariableIdentifier) {
                // Spezielle Darstellung f�r Dialoge, die mit dialog.. oder win.. beginnen
                String tempMatchIdentifier = identifier.substring(1, identifier.length() - 1);
                w = findWindowByMatchName(tempMatchIdentifier);
                if (w == null) {
                    String msg = "Window '" + identifier + "' does not exist or is not showing";
                    throw new ComponentNotFoundException(msg);
                }
            } else {
                w = getFinder().findWindow(identifier);
            }
            Log.debug("Found " + toString(w) + " for " + identifier);


            if ((AbbotI18NUtil.theInstance().getPerformI18NConversion()) && (!tempIsVariableIdentifier)) {
                AbbotI18NUtil.theInstance()
                        .checkI18NOptionPane(TestScriptRunner.getLastActiveInstance(), identifier, w);
            }
            //abbot_ext_end
            return true;
        } catch (ComponentNotFoundException e) {
            Log.debug(e);
            return false;
        } catch (MultipleComponentsFoundException m) {
            // Might not be the one you want, but that's what the docs say
            return true;
        }
    }


    private Window findWindowByMatchName(String match) {
        Window[] windows = getFinder().getWindows();
        for (int i = 0; i < windows.length; i++) {
            Window w = windows[i];
            if (w.isShowing()) {
                String name = w.getName();
                if ((match != null) && (name != null) && (Regexp.stringMatch(match, name))) {
                    return w;
                }
            }
        }
        return null;
    }


    /** Convenience wait for a window to be displayed.  The given string may
     * be a plain String or regular expression and may match either the window
     * title (for Frames and Dialogs) or its Component name.  This method is
     * provided as a convenience for hand-coded tests, since scripts will use
     * a wait step instead.<p>
     * The property abbot.robot.component_delay affects the default timeout.
     */
    public void waitForFrameShowing(final String identifier) {
        wait(new Condition() {

            @Override
            public boolean test() {
                return assertFrameShowing(identifier);
            }

            @Override
            public String toString() {
                return identifier + " to show";
            }
        }, componentDelay);
    }

    /** Return whether the Component represented by the given
        ComponentReference is available.
    */
    public boolean assertComponentShowing(ComponentReference ref) {
        try {
            Component c = ref.findInHierarchy(getFinder());
            return getFinder().isShowing(c);
        } catch (Exception e) {
            return false;
        }
    }

    /** Wait for the Component represented by the given ComponentReference to
        become available.  The timeout is affected by
        abbot.robot.component_delay, which defaults to 30s. 
    */
    public void waitForComponentShowing(final ComponentReference ref) {
        wait(new Condition() {

            @Override
            public boolean test() {
                return getTester(Component.class).assertComponentShowing(ref);
            }

            @Override
            public String toString() {
                return ref + " to show";
            }
        }, componentDelay);
    }


    //abbot_ext_begin

    /** Wait for the Component represented by the given ComponentReference to
    become available.  The timeout is affected by
    abbot.robot.component_delay, which defaults to 30s. 
    */
    public void waitForComponentEnabled(final ComponentReference ref) {
        wait(new Condition() {

            @Override
            public boolean test() {
                return getTester(Component.class).assertComponentEnabled(ref);
            }

            @Override
            public String toString() {
                return ref + " to show";
            }
        }, componentDelay);
    }


    /** Return whether the Component represented by the given
    ComponentReference is available.
     */
    public boolean assertComponentEnabled(ComponentReference ref) {
        try {
            Component c = ref.findInHierarchy(getFinder());
            return c.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }


    //abbot_ext_end


    private Method[] cachedMethods = null;

    /** Look up methods with the given prefix. */
    private Method[] getMethods(String prefix, Class returnType, boolean onComponent) {
        if (cachedMethods == null) {
            cachedMethods = getClass().getMethods();
        }
        List<Method> methods = new ArrayList<Method>();
        Set<String> names = new HashSet<String>();
        Method[] mlist = cachedMethods;
        for (int i = 0; i < mlist.length; i++) {
            String name = mlist[i].getName();
            if (!names.contains(name)) {
                Class[] params = mlist[i].getParameterTypes();
                if (name.startsWith(prefix)
                    && (returnType == null || returnType.equals(mlist[i].getReturnType()))
                    && ((params.length == 0 && !onComponent) || (params.length > 0 && (Component.class
                            .isAssignableFrom(params[0]) == onComponent)))) {
                    methods.add(mlist[i]);
                    names.add(name);
                }
            }
        }
        return methods.toArray(new Method[methods.size()]);
    }

    private Method[] cachedActions = null;

    /** Return a list of all actions defined by this class that don't depend
     * on a component argument.
     */
    public Method[] getActions() {
        if (cachedActions == null) {
            cachedActions = getMethods("action", void.class, false);
        }
        return cachedActions;
    }

    private Method[] cachedComponentActions = null;

    /** Return a list of all actions defined by this class that require
     * a component argument.
     */
    public Method[] getComponentActions() {
        if (cachedComponentActions == null) {
            cachedComponentActions = getMethods("action", void.class, true);
        }
        return cachedComponentActions;
    }


    private Method[] cachedPropertyMethods = null;

    /** Return an array of all property check methods defined by this class.
     * The first argument <b>must</b> be a Component.
     */
    public Method[] getPropertyMethods() {
        if (cachedPropertyMethods == null) {
            ArrayList<Method> all = new ArrayList<Method>();
            all.addAll(Arrays.asList(getMethods("is", boolean.class, true)));
            all.addAll(Arrays.asList(getMethods("has", boolean.class, true)));
            all.addAll(Arrays.asList(getMethods("get", null, true)));
            // Remove getXXX or isXXX methods which aren't property checks
            Class[] args = new Class[] {Component.class};
            try {
                all.remove(getClass().getMethod("getTag", args));
                all.remove(getClass().getMethod("getTester", args));
                all.remove(getClass().getMethod("isOnPopup", args));
            } catch (NoSuchMethodException e) {}
            cachedPropertyMethods = all.toArray(new Method[all.size()]);
        }
        return cachedPropertyMethods;
    }

    private Method[] cachedAssertMethods = null;

    /** Return a list of all assertions defined by this class that don't
     * depend on a component argument.
     */
    public Method[] getAssertMethods() {
        if (cachedAssertMethods == null) {
            cachedAssertMethods = getMethods("assert", boolean.class, false);
        }
        return cachedAssertMethods;
    }

    private Method[] cachedComponentAssertMethods = null;

    /** Return a list of all assertions defined by this class that require a
     * component argument.
     */
    public Method[] getComponentAssertMethods() {
        if (cachedComponentAssertMethods == null) {
            cachedComponentAssertMethods = getMethods("assert", boolean.class, true);
        }
        return cachedComponentAssertMethods;
    }

    /** Quick and dirty strip raw text from html, for getting the basic text
        from html-formatted labels and buttons.  Behavior is undefined for
        badly formatted html.
    */
    public static String stripHTML(String str) {
        if (str != null && (str.startsWith("<html>") || str.startsWith("<HTML>"))) {
            while (str.startsWith("<")) {
                int right = str.indexOf(">");
                if (right == -1) break;
                str = str.substring(right + 1);
            }
            while (str.endsWith(">")) {
                int right = str.lastIndexOf("<");
                if (right == -1) break;
                str = str.substring(0, right);
            }
        }
        return str;
    }

    /** Wait for the given condition, throwing an ActionFailedException if it
     * times out.
     */
    protected void waitAction(String desc, Condition cond) throws ActionFailedException {
        try {
            wait(cond);
        } catch (WaitTimedOutError wto) {
            throw new ActionFailedException(desc);
        }
    }

    /** Return the Component class that corresponds to this ComponentTester
        class.  For example, JComponentTester.getTestedClass(JLabel.class)
        would return JComponent.class.
    */
    public Class getTestedClass(Class cls) {
        while (getTester(cls.getSuperclass()) == this) {
            cls = cls.getSuperclass();
        }
        return cls;
    }


    //abbot_ext_begin

    /** 
     * Speichert die Daten einer Komponente unter dem angegebenen Dateinamen ab
     * @param comp die Komponente
     * @param fileName der Dateiname
     */
    public void actionSaveContent(Component comp, String fileName) {

        if (fileName.startsWith("${")) {
            String tempFilenameVar = fileName.substring(2, fileName.length() - 1);
            fileName = RTVariablesSingleton.theInstance().getVariable(tempFilenameVar);
        }

        try {
            GUIUtil.theInstance().saveContent(comp, fileName);
        } catch (Exception e) {

            logger.error("Something ugly happened: ", e);
        }


    }

    //abbot_ext_end


}
