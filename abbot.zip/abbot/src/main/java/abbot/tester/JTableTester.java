package abbot.tester;

import java.awt.Component;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JTable;
/** Provide user actions on a JTable. */
// TODO: multi-select
public class JTableTester extends JComponentTester {

    protected Point cellToPoint(Component c, int row, int col) {
        JTable table = (JTable)c;
        Rectangle rect = table.getCellRect(row, col, false);
        return new Point(rect.x + rect.width/2, rect.y + rect.height/2);
    }

    /** Make sure the entire cell at the given index is visible. */
    public void actionScrollCellToVisible(Component comp, int row, int col) {
        scrollToVisible(comp, ((JTable)comp).getCellRect(row, col, false));
    }

    /** Select the given cell, if not already. */
    public void actionSelectCell(Component c, int row, int col) {
        // FIXME don't click if already selected
        actionClickCell(c, row, col);
    }

    /** JTable select cell action. */
    public void actionClickCell(Component c, int row, int col) {
        actionClickCell(c, row, col, "BUTTON1_MASK");
    }

    /** JTable select cell action. */
    public void actionClickCell(Component c, int row, int col,
                                String modifiers) {
        actionClickCell(c, row, col, modifiers, 1);
    }

    /** JTable select cell action. */
    public void actionClickCell(Component c, int row, int col,
                                String modifiers, int count) {
        Point pt = cellToPoint(c, row, col);
        actionClick(c, pt.x, pt.y, modifiers, count);
    }

    /** Initiate a drag operation at the given cell using mouse button 1. */
    public void actionDragCell(Component c, int row, int col) {
        actionDragCell(c, row, col, "BUTTON1_MASK");
    }

    /** Initiate a drag operation at the given cell, using the given button
     * modifiers.
     */
    public void actionDragCell(Component c, int row, int col,
                               String modifiers) {
        Point pt = cellToPoint(c, row, col);
        actionDrag(c, pt.x, pt.y, modifiers);
    }

    /** Drop the current drag action on the given cell. */
    public void actionDropAtCell(Component c, int row, int col) {
        Point pt = cellToPoint(c, row, col);
        actionDrop(c, pt.x, pt.y);
    }

    /** Select a menu item from a popup menu at the given cell. */
    public void actionSelectPopupMenuItemAtCell(Component c, int row, int col,
                                                String itemName) {
        Point pt = cellToPoint(c, row, col);
        actionSelectPopupMenuItem(c, pt.x, pt.y, itemName);
    }

    /** Activate a popup menu at the given cell. */
    public void actionShowPopupMenuAtCell(Component c, int row, int col) {
        Point pt = cellToPoint(c, row, col);
        actionShowPopupMenu(c, pt.x, pt.y);
    }
}
