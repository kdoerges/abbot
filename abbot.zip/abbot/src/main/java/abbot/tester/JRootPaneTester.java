package abbot.tester;

import java.awt.Component;


public class JRootPaneTester extends JComponentTester {

    /**
     * Return a unique identifier for the given Component.  There is only
     * ever one JRootPane for a given Window, so derive from the parent's
     * tag.
     */
    @Override
    public String deriveTag(Component comp) {
        String tag = null;
        if (comp.getParent() != null) {
            String ptag = getTag(comp.getParent());
            if (ptag != null && !"".equals(ptag)) tag = ptag + " Root Pane";
        }
        if (tag == null || "".equals(tag)) tag = super.deriveTag(comp);
        return tag;
    }
}
