package abbot.tester;

import java.awt.Component;
import java.awt.Dialog;


public class DialogTester extends WindowTester {

    /** Return a unique tag to help identify the given component. */
    @Override
    public String deriveTag(Component comp) {
        String tag = ((Dialog)comp).getTitle();
        if (tag == null || "".equals(tag)) {
            tag = super.deriveTag(comp);
        }
        return tag;
    }
}
