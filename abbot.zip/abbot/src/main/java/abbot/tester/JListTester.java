package abbot.tester;

import java.awt.Component;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;

import abbot.Log;
import abbot.util.ExtendedComparator;

/** Provide actions and assertions for a JList component.
    <ul>
    <li>Select an item by index
    <li>Select an item by value (its string representation)
    </ul>
 */
// TODO multi-select
public class JListTester extends JComponentTester {

    /** Convert the given list index into an x, y coordinate.
        @throws ActionFailedException if the index is out of range.
    */
    protected Point indexToPoint(Component c, int index) {
        JList list = (JList)c;
        // NOTE: Setting the index out of range normally does nothing,
        // cf. DefaultListSelectionModel.  But this is a requested user
        // action, so if we can't do it, we need to fail.
        if (index >= list.getModel().getSize() || index < 0) {
            throw new ActionFailedException("Index " + index + " out of range");
        }
        Rectangle rect = list.getCellBounds(index, index);
        return new Point(rect.x + rect.width/2, rect.y + rect.height/2);
    }

    /** JList doesn't provide direct access to its contents, so make up for
     * that oversight.
     */
    public Object getElementAt(JList list, int index) {
        return list.getModel().getElementAt(index);
    }

    /** Return the size of the given list. */
    public int getSize(JList list) {
        return list.getModel().getSize();
    }

    /** Return an array of strings that represents the list's contents. */
    public String[] getContents(JList list) {
        ListModel model = list.getModel();
        String[] values = new String[model.getSize()];
        for (int i=0;i < values.length;i++) {
            values[i] = model.getElementAt(i).toString();
        }
        return values;
    }

    /** Make sure the entire element at the given index is visible. */
    public void actionScrollCellToVisible(Component list, int index) {
        scrollToVisible(list, ((JList)list).getCellBounds(index, index));
    }

    /** Select the given index.  Does nothing if the index is
     * already selected.  
     * @throws ActionFailedException if the index is out of range.
     */
    public void actionSelectIndex(Component c, final int index) {
        final JList list = (JList)c;
        if (list.getSelectedIndex() == index)
            return;
        if (getEventMode() == EM_PROG) { 
            invokeAndWait(new Runnable() {
                public void run() {
                    list.setSelectedIndex(index);
                }
            });
        }
        else {
            actionClickIndex(list, index, "BUTTON1_MASK", 1);
        }
    }

    /** Click the cell at the given index, using mouse button 1.
        @throws ActionFailedException if the index is out of range.
    */
    public void actionClickIndex(Component list, int index) {
        actionClickIndex(list, index, "BUTTON1_MASK", 1);
    }

    /** Click the cell at the given index, using the given button modifiers.
        @throws ActionFailedException if the index is out of range.
    */
    public void actionClickIndex(Component list, int index, String modifiers) {
        actionClickIndex(list, index, modifiers, 1);
    }

    /** Click the cell at the given index, using the given button modifiers
        and click count.
        @throws ActionFailedException if the index is out of range.
    */
    public void actionClickIndex(Component c, int index,
                                 String modifiers, int count) {
        Point pt = indexToPoint(c, index);
        actionClick(c, pt.x, pt.y, modifiers, count);
    }

    /** Find the first string match in the list and return its index.
        @throws ActionFailedException if the value is not matched.
    */
    protected int valueToIndex(Component c, String value) {
        JList list = (JList)c;
        ListCellRenderer lcr = list.getCellRenderer();
        for (int i=0;i < list.getModel().getSize();i++) {
            Object obj = list.getModel().getElementAt(i);
            Component cr = lcr.getListCellRendererComponent(list, obj,
                                                            i, false, false);
            // If the cell renderer is displaying text, compare against the
            // text instead of the object
            if (cr instanceof JLabel)
                obj = ((JLabel)cr).getText();

            if (ExtendedComparator.stringsMatch(value, obj.toString())) {
                return i;
            }
            else {
                Log.debug("Value '" + value + "' does not match '"
                          + obj.toString());
            }
        }
        throw new ActionFailedException("Value '" + value 
                                        + "' not found in JList");
    }

    /** Select the first instance of the given value in the JList.  Does
     * nothing if that value is already selected.
     * @throws ActionFailedException if the value does not exist.
     */
    public void actionSelectValue(Component list, String item) {
        actionSelectIndex(list, valueToIndex(list, item));
    }

    /** Click on the given value using mouse button 1.
        @throws ActionFailedException if the value does not exist.
    */
    public void actionClickValue(Component list, String item) {
        actionClickIndex(list, valueToIndex(list, item));
    }

    /** Click on the given value, using the given button modifiers.
        @throws ActionFailedException if the value does not exist.
    */
    public void actionClickValue(Component list, String item, String modifiers) {
        actionClickIndex(list, valueToIndex(list, item), modifiers);
    }

    /** Click on the given value, using the given button modifiers and click
        count. 
        @throws ActionFailedException if the value does not exist.
    */
    public void actionClickValue(Component list, String item,
                                 String modifiers, int count) {
        actionClickIndex(list, valueToIndex(list, item), modifiers, count);
    }

    /** Select an item from a popup menu on the given list at the given index.
        @throws ActionFailedException if the index is out of range.
    */
    public void actionSelectPopupMenuItemAtIndex(Component list, int index,
                                                 String menuItem) {
        Point pt = indexToPoint(list, index);
        actionSelectPopupMenuItem(list, pt.x, pt.y, menuItem);
    }

    /** Select an item from a popup menu on the given list at the given value.
        @throws ActionFailedException if the value does not exist.
    */
    public void actionSelectPopupMenuItemAtValue(Component list, String item,
                                                 String menuItem) {
        actionSelectPopupMenuItemAtIndex(list, valueToIndex(list, item),
                                         menuItem);
    }

    /** Activate a popup menu on the given list at the given index. 
        @throws ActionFailedException if the index is out of range.
    */
    public void actionShowPopupMenuAtIndex(Component list, int index) {
        Point pt = indexToPoint(list, index);
        actionShowPopupMenu(list, pt.x, pt.y);
    }

    /** Activate a popup menu on the given list at the given value.  
        @throws ActionFailedException if the value does not exist.
    */
    public void actionShowPopupMenuAtValue(Component list, String item) {
        actionShowPopupMenuAtIndex(list, valueToIndex(list, item));
    }
}
