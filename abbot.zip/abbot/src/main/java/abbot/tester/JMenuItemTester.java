package abbot.tester;

import java.awt.Component;

import javax.swing.JMenuItem;


public class JMenuItemTester extends AbstractButtonTester {

    @Override
    public String deriveTag(Component comp) {
        return ((JMenuItem)comp).getText();
    }
}
