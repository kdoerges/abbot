package abbot.tester;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.Method;
import java.util.*;

import abbot.Log;
import abbot.util.Properties;

import com.obi.test.tregs.abbot.component.AbbotProperties;


/** Keep track of all known root windows, and all known showing/hidden/closed
 * windows.
 */
public class WindowTracker {

    /** Keep track of all app contexts we can.  Maps contexts to sets of root
     * windows.
     */
    private Map<EventQueue, Map<Component, Component>> contexts;

    private ContextTracker contextTracker;

    /** Windows which for which isShowing is true but are not yet ready for
        input. */
    private Map<Window, TimerTask> pendingWindows = new WeakHashMap<Window, TimerTask>();

    /** Windows which we deem are ready to use.  */
    private Map<Window, Window> openWindows = new WeakHashMap<Window, Window>();

    /** Windows which are not visible. */
    private Map<Window, Window> hiddenWindows = new WeakHashMap<Window, Window>();

    /** Windows which have sent a WINDOW_CLOSE event. */
    private Map<Component, Component> closedWindows = new WeakHashMap<Component, Component>();

    private static int windowReadyDelay = Properties.getProperty("abbot.window_ready_delay", 0, 5000, 100);

    private Timer queue = new Timer(true);

    private static WindowTracker tracker = null;

    /** Only ever want one of these. */
    public static synchronized WindowTracker getTracker() {
        if (tracker == null) tracker = new WindowTracker();
        return tracker;
    }

    /** Create an instance of WindowTracker which will track all windows
     * coming and going on the current and subsequent app contexts. 
     * WARNING: if an applet loads this, it will only ever see stuff in its
     * own app context.
     */
    WindowTracker() {
        contextTracker = new ContextTracker();
        long mask = WindowEvent.WINDOW_EVENT_MASK | ComponentEvent.COMPONENT_EVENT_MASK;
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        toolkit.addAWTEventListener(contextTracker, mask);
        contexts = new WeakHashMap<EventQueue, Map<Component, Component>>();
        contexts.put(toolkit.getSystemEventQueue(), new WeakHashMap<Component, Component>());
        // Populate stuff that may already have shown/been hidden
        Frame[] frames = Frame.getFrames();
        synchronized (openWindows) {
            for (int i = 0; i < frames.length; i++) {
                scanExistingWindows(frames[i]);
            }
        }
    }

    private void scanExistingWindows(Window w) {
        // Make sure we catch subsequent show/hide events for this window
        new WindowWatcher(w);
        Window[] windows = w.getOwnedWindows();
        for (int i = 0; i < windows.length; i++) {
            scanExistingWindows(windows[i]);
        }
        openWindows.put(w, w);
        if (!w.isShowing()) {
            hiddenWindows.put(w, w);
        }
    }

    /** Returns whether the window is ready to receive input.
        A window's "isShowing" flag may be set true before the WINDOW_OPENED
        event is generated, and even after the WINDOW_OPENED is sent the
        window peer is not guaranteed to be ready.
    */
    public boolean isWindowReady(Window w) {
        synchronized (openWindows) {
            return openWindows.containsKey(w) && !hiddenWindows.containsKey(w);
        }
    }

    /** Return all available root Windows.  A root Window is one
     * that has a null parent.  Nominally this means a list similar to that
     * returned by Frame.getFrames(), but in the case of an Applet may return
     * a few Dialogs as well.
     */
    public Set<Component> getRootWindows() {
        Set<Component> set = new HashSet<Component>();
        // Use Frame.getFrames() here in addition to our watched set, just in
        // case any of them is missing from our set.
        synchronized (contexts) {
            Iterator<EventQueue> iter = contexts.keySet().iterator();
            while (iter.hasNext()) {
                EventQueue tQueue = iter.next();
                // @TODO ehem. dead-Store, Aufruf notwendig?
                Toolkit.getDefaultToolkit();
                Map<Component, Component> map = contexts.get(tQueue);
                set.addAll(map.values());
            }
            Frame[] frames = Frame.getFrames();
            for (int i = 0; i < frames.length; i++) {
                set.add(frames[i]);
            }
        }
        //Log.debug(String.valueOf(list.size()) + " total Frames");
        return set;
    }

    /** Provides tracking of window visibility state.  We explicitly add this
     * on WINDOW_OPEN and remove it on WINDOW_CLOSE to avoid having to process
     * extraneous ComponentEvents.
     */
    private class WindowWatcher extends WindowAdapter implements ComponentListener {

        public WindowWatcher(Window w) {
            w.addComponentListener(this);
            w.addWindowListener(this);
        }

        @Override
        public void componentShown(ComponentEvent e) {
            markWindowShowing((Window)e.getSource());
        }

        @Override
        public void componentHidden(ComponentEvent e) {
            synchronized (openWindows) {
                // @TODO: Kl�ren: Immer Window? Evtl. Map<Object, Object> definieren
                hiddenWindows.put((Window)e.getSource(), (Window)e.getSource());
                cancelPendingReady(e.getSource());
            }
        }

        @Override
        public void windowClosed(WindowEvent e) {
            e.getWindow().removeWindowListener(this);
            e.getWindow().removeComponentListener(this);
        }

        @Override
        public void componentResized(ComponentEvent e) {}

        @Override
        public void componentMoved(ComponentEvent e) {}
    }

    /** Whenever we get a window that's on a new event dispatch thread, take
     * note of the thread, since it may correspond to a new event queue and
     * AppContext. 
     */
    // FIXME what if it has the same app context? can we check?
    private class ContextTracker implements AWTEventListener {

        @Override
        public void eventDispatched(AWTEvent ev) {

            ComponentEvent event = (ComponentEvent)ev;
            Component comp = event.getComponent();
            // This is our sole means of accessing other app contexts
            // (if running within an applet).  We look for window events
            // beyond OPENED in order to catch windows that have already
            // opened by the time we start listening but which are not
            // in the Frame.getFrames list (i.e. they are on a different
            // context).   Specifically watch for COMPONENT_SHOWN on applets,
            // since we may not get frame events for them.
            if (comp instanceof java.applet.Applet) {
                Component parent = comp;
                while (parent.getParent() != null)
                    parent = parent.getParent();
                if (parent instanceof Frame) comp = parent;
            } else if (!(comp instanceof Window)) {
                return;
            }

            int id = ev.getID();
            if (id == WindowEvent.WINDOW_OPENED) {
                noteOpened(comp);
            } else if (id == WindowEvent.WINDOW_CLOSED) {
                noteClosed(comp);
            } else if (id == WindowEvent.WINDOW_CLOSING) {
                // ignore
            }
            // Take note of all other window events
            else if ((id >= WindowEvent.WINDOW_FIRST && id <= WindowEvent.WINDOW_LAST)
                     || id == ComponentEvent.COMPONENT_SHOWN) {
                if (!getRootWindows().contains(comp)) noteOpened(comp);
            }
        }
    }

    private void noteOpened(Component comp) {

        //Log.debug("Noting " + Robot.toString(comp));
        if (comp.getParent() == null) {
            EventQueue tQueue = comp.getToolkit().getSystemEventQueue();
            synchronized (contexts) {
                Map<Component, Component> whm = contexts.get(tQueue);
                if (whm == null) {
                    contexts.put(tQueue, whm = new WeakHashMap<Component, Component>());
                }
                whm.put(comp, comp);
            }
        }
        // Attempt to ensure the window is ready for input before recognizing
        // it as "open".  There is no Java API for this, so we institute an
        // empirically tested delay.
        if (comp instanceof Window) {
            new WindowWatcher((Window)comp);
            markWindowShowing((Window)comp);
        }
    }

    private void noteClosed(Component comp) {


        if (comp.getParent() == null) {
            EventQueue tQueue = comp.getToolkit().getSystemEventQueue();
            synchronized (contexts) {
                Map<Component, Component> whm = contexts.get(tQueue);
                if (whm != null)
                    whm.remove(comp);
                else
                    Log.log("Got WINDOW_CLOSED on "
                            + Robot.toString(comp)
                            + " on a new context: "
                            + Thread.currentThread());
            }
        }
        synchronized (openWindows) {

            //abbot_ext_begin

            if (AbbotProperties.theInstance().getMemoryOptimizing()) {
                removeOpenWindows(comp);
            }


            openWindows.remove(comp);
            hiddenWindows.remove(comp);
            closedWindows.put(comp, comp);
            cancelPendingReady(comp);
        }
    }


    private void removeOpenWindows(Component comp) {
        // Pr�fe, ob das Objekt auf getTitle antwortet

        Method titleMethod = null;
        Class compClass = comp.getClass();
        try {
            titleMethod = compClass.getMethod("getTitle", new Class[0]);
        } catch (NoSuchMethodException e) {

        }

        String title = null;
        if (titleMethod != null) {

            try {
                title = (String)titleMethod.invoke(comp, new Object[0]);
                if (title == null) {
                    title = comp.toString();
                }
            } catch (Exception e) {
                title = comp.toString();
            }
        } else {
            title = comp.toString();
        }

        if (title != null) {
            Vector<Window> dialogsToRemove = new Vector<Window>();

            Iterator<Window> openWindowIterator = openWindows.keySet().iterator();
            while (openWindowIterator.hasNext()) {
                Window element = openWindowIterator.next();
                Method openWindowTitleMethod = null;
                Class openWindowClass = comp.getClass();
                String openWindowTitle = null;
                try {
                    openWindowTitleMethod = openWindowClass.getMethod("getTitle", new Class[0]);
                } catch (NoSuchMethodException e) {

                }

                if (openWindowTitleMethod != null) {
                    try {
                        openWindowTitle = (String)openWindowTitleMethod.invoke(element, new Object[0]);
                        if (openWindowTitle == null) {
                            openWindowTitle = element.toString();
                        }
                    } catch (Exception e) {
                        openWindowTitle = element.toString();
                    }
                    if ((openWindowTitle != null) && (openWindowTitle.equals(title))) {
                        dialogsToRemove.add(element);
                    }
                }
            }
            Iterator<Window> removeIterator = dialogsToRemove.iterator();

            while (removeIterator.hasNext()) {
                Object dialogToRemove = removeIterator.next();
                openWindows.remove(dialogToRemove);

            }
        }
    }

    //abbot_ext_end


    private void markWindowReady(Window w) {
        synchronized (openWindows) {
            closedWindows.remove(w);
            hiddenWindows.remove(w);
            openWindows.put(w, w);
            pendingWindows.remove(w);
            //Log.debug("Ready: " + Robot.toString(w));
        }
    }

    /** Provide a method for canceling a pending "set window ready" task, in
        case the window is closed before we think it's ready.
    */
    private void cancelPendingReady(Object key) {
        synchronized (openWindows) {
            TimerTask task = pendingWindows.get(key);
            if (task != null) {
                pendingWindows.remove(key);
                task.cancel();
            }
        }
    }

    /** Indicate a window has set isShowing true and needs to be marked ready
        when it is actually ready.
    */
    private void markWindowShowing(final Window w) {
        if (windowReadyDelay == 0) {
            markWindowReady(w);
        } else {
            // NOTE: this task must be canceled if a CLOSE or HIDDEN is
            // encountered before the task is run.
            TimerTask task = new TimerTask() {

                @Override
                public void run() {
                    markWindowReady(w);
                }
            };
            synchronized (openWindows) {
                try {
                    queue.schedule(task, windowReadyDelay);
                } catch (IllegalStateException e) {
                    Log.warn(e);
                    Log.warn("Timer canceled, starting a new one");
                    pendingWindows.clear();
                    queue = new Timer(true);
                    queue.schedule(task, windowReadyDelay);
                }
                pendingWindows.put(w, task);
                //Log.debug("Added: " + Robot.toString(w));
            }
        }
    }
}
