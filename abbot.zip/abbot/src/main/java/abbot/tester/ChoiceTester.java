package abbot.tester;

import java.awt.Choice;
import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;

import abbot.util.Properties;
import abbot.util.ExtendedComparator;

/** AWT Choice (ComboBox) support. */
public class ChoiceTester extends ComponentTester {

    private int choiceDelay =
        Properties.getProperty("abbot.tester.choice_delay", 0, 60000, 30000);

    // w32 fires SELECT on arrow up/down
    // OSX fires on ENTER/SPACE or click only
    private class Listener implements ItemListener {
        public volatile boolean gotChange = false;
        public int targetIndex = -1;
        public void itemStateChanged(ItemEvent ev) {
            gotChange = ((Choice)ev.getItemSelectable()).
                getSelectedIndex() == targetIndex;
        }
    }

    /** Select an item by index. */
    public void actionSelectIndex(Component c, final int index) {
        final Choice choice = (Choice)c;
        int current = choice.getSelectedIndex();
        if (current == index)
            return;

        Listener listener = new Listener();
        listener.targetIndex = index;
        choice.addItemListener(listener);

        // Ensure mouse events are processed before any key events are sent
        actionClick(choice);
        choice.select(index);
        ItemEvent ie = new ItemEvent(choice, ItemEvent.ITEM_STATE_CHANGED,
                                     choice.getSelectedObjects()[0],
                                     ItemEvent.SELECTED);
        postEvent(choice, ie);
        // Close the popup
        key(KeyEvent.VK_ENTER);
        waitForIdle();
        long now = System.currentTimeMillis();
        try {
            while (!listener.gotChange) {
                if (System.currentTimeMillis() - now > choiceDelay)
                    throw new ActionFailedException("Choice not activated");
                sleep();
            }
        }
        finally {
            choice.removeItemListener(listener);
        }
    }

    /** Select an item by its String representation. */
    public void actionSelectItem(Component c, String item) {
        Choice choice = (Choice)c;
        for (int i=0;i < choice.getItemCount();i++) {
            if (ExtendedComparator.stringsMatch(choice.getItem(i), item)) {
                actionSelectIndex(c, i);
                return;
            }
        }
        throw new ActionFailedException("Item '" + item
                                        + "' not found in Choice");
    }
}
