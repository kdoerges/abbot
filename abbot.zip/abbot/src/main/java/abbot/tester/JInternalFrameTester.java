package abbot.tester;

import java.awt.Component;
import java.awt.Frame;
import java.awt.Point;
import java.beans.PropertyVetoException;
import javax.swing.JInternalFrame;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

public class JInternalFrameTester extends JComponentTester {

    private class VetoFailure {
        public PropertyVetoException e = null;
    }

    protected void maximize(final JInternalFrame frame, final boolean b) {
        if (!frame.isMaximizable())
            throw new ActionFailedException("The given JInternalFrame ("
                                            + toString(frame) + ") is not "
                                            + "maximizable");
        Point p = getMaximizeLocation(frame);
        mouseMove(frame, p.x, p.y);
        final VetoFailure veto = new VetoFailure();
        invokeAndWait(new Runnable() {
            public void run() {
                try {
                    frame.setMaximum(b);
                }
                catch(PropertyVetoException e) {
                    veto.e = e;
                }
            }
        });
        if (veto.e != null) {
            throw new ActionFailedException("Maximize of "
                                            + Robot.toString(frame)
                                            + " was vetoed ("
                                            + veto.e + ")");
        }
    }

    public void actionMaximize(Component comp) {
        maximize((JInternalFrame)comp, true);
    }

    public void actionNormalize(Component comp) {
        maximize((JInternalFrame)comp, false);
    }

    protected void iconify(final JInternalFrame frame, final boolean b) {
        if (!frame.isIconifiable())
            throw new ActionFailedException("The given JInternalFrame ("
                                            + toString(frame) + ") is not "
                                            + "iconifiable");
        if (b) {
            Point p = getIconifyLocation(frame);
            mouseMove(frame, p.x, p.y);
        }
        else {
            Component c = frame.getDesktopIcon();
            mouseMove(c, c.getWidth()/2, c.getHeight()/2);
        }
        final VetoFailure veto = new VetoFailure();
        invokeAndWait(new Runnable() {
            public void run() {
                try {
                    frame.setIcon(b);
                }
                catch(PropertyVetoException e) {
                    veto.e = e;
                }
            }
        });
        if (veto.e != null) {
            throw new ActionFailedException("Iconify of "
                                            + Robot.toString(frame)
                                            + " was vetoed ("
                                            + veto.e + ")");
        }
    }

    /** Iconify the given Frame. */
    public void actionIconify(Component comp) {
        iconify((JInternalFrame)comp, true);
    }

    /** Deiconify the given Frame. */
    public void actionDeiconify(Component comp) {
        iconify((JInternalFrame)comp, false);
    }

    /** Move the given internal frame. */
    public void actionMove(Component comp, int x, int y) {
        move((JInternalFrame)comp, x, y);
        waitForIdle();
    }

    /** Resize the given internal frame. */
    public void actionResize(Component comp, int width, int height) {
        resize((JInternalFrame)comp, width, height);
        waitForIdle();
    }

    /** Close the internal frame. */
    public void actionClose(Component comp) {
        // This is LAF-specific, so it must be done programmatically.
        final JInternalFrame frame = (JInternalFrame)comp;
        if (!frame.isClosable()) 
            throw new ActionFailedException("The given JInternalFrame ("
                                            + toString(frame) + ") is not "
                                            + "closable");
        Point p = getCloseLocation(frame);
        mouseMove(frame, p.x, p.y);
        final VetoFailure veto = new VetoFailure();
        invokeAndWait(new Runnable() {
            public void run() {
                try {
                    frame.setClosed(true);
                }
                catch(PropertyVetoException e) {
                    veto.e = e;
                }
            }
        });
        if (veto.e != null) {
            throw new ActionFailedException("Close of "
                                            + Robot.toString(frame)
                                            + " was vetoed ("
                                            + veto.e + ")");
        }
    }
}

