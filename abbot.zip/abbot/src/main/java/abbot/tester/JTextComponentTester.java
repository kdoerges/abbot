package abbot.tester;

import java.awt.Component;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.InputEvent;

import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;

import abbot.Log;

public class JTextComponentTester extends JComponentTester {

    /** @deprecated */
    public void actionText(Component tc, String text) {
        actionEnterText(tc, text);
    }

    /**
     * Type the given text into the given component, replacing any existing
     * text already there.
     */
    public void actionEnterText(Component c, String text) {
        JTextComponent tc = (JTextComponent)c;
        focus(tc);
        actionSelect(tc, 0, tc.getText().length());
        actionKeyString(text);
    }

    /** Click at the given index position. */
    public void actionClick(Component tc, int index) {
        mouseMove(tc, index);
        mousePress(InputEvent.BUTTON1_MASK);
        mouseRelease(InputEvent.BUTTON1_MASK);
        waitForIdle();
    }

    /** Select the given range of text. */
    public void actionSelect(Component comp, int start, int end) {
        startSelection(comp, start);
        endSelection(comp, end);
        waitForIdle();
    }

    /** Move the pointer to the given index location.  Takes care of
     * auto-scrolling through text.
     */
    protected void mouseMove(Component c, int index) {
        JTextComponent tc = (JTextComponent)c;
        Log.debug("move to index " + index);
        try {
            int x, y;
            Rectangle rect = tc.modelToView(index);
            Insets insets = tc.getInsets();
            // stay within the visible component
            // rely on auto-scrolling if the location is not within the
            // component's visible bounds
            actionScrollToVisible(tc, rect.x, rect.y);
            rect = tc.modelToView(index);
            Log.debug("Moving to index " + index + " at ("
                      + rect.x + "," + rect.y + ")");
            mouseMove(tc, rect.x, rect.y);
        }
        catch(BadLocationException ble) {
            throw new ActionFailedException(ble.getMessage()
                                            + ": " + index + " (text was '"
                                            + tc.getText() + "')");
        }
    }

    protected void startSelection(Component comp, int index) {
        mouseMove(comp, index);
        mousePress(InputEvent.BUTTON1_MASK);
    }

    protected void endSelection(Component comp, int index) {
        mouseMove(comp, index);
        mouseRelease(InputEvent.BUTTON1_MASK);
    }

    /** Start a selection at the given index. */
    public void actionStartSelection(Component comp, int index) {
        startSelection(comp, index);
        waitForIdle();
    }

    /** Terminate a selection on the given index. */
    public void actionEndSelection(Component comp, int index) {
        endSelection(comp, index);
        waitForIdle();
    }
}
