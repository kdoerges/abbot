package abbot.tester;

import java.awt.Component;
import java.awt.FileDialog;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import abbot.Log;


/**
 * Tester for the java.awt.FileDialog.
 *
 * @author Vrata Venet, European Space Agency, Madrid-Spain (av@iso.vilspa.esa.es) 
 * NOTE: different platforms do different things when the dialog is hidden.
 * w32 returns null for the file if FileDialog.hide is invoked; other
 * platforms may leave the file as is.
 */
public class FileDialogTester extends DialogTester {

    /**
     * This sets the file path for the fd
     */
    public void actionSetFile(Component comp, final String file) {
        if (null == file || "".equals(file))
            throw new IllegalArgumentException("File name in FileDialog should be non-null and non-empty");
        final FileDialog dialog = (FileDialog)comp;
        invokeAndWait(new Runnable() {

            @Override
            public void run() {
                dialog.setFile(file);
            }
        });
    }

    public void actionSetDirectory(Component comp, final String dir) {
        if (null == dir || "".equals(dir))
            throw new IllegalArgumentException("File name in FileDialog should be non-null and non-empty");
        final FileDialog dialog = (FileDialog)comp;
        invokeAndWait(new Runnable() {

            @Override
            public void run() {
                dialog.setDirectory(dir);
            }
        });
    }

    /** Accept the currently selected file. */
    public void actionAccept(Component comp) {
        Log.debug("accept");
        final FileDialog fd = (FileDialog)comp;
        final String file = fd.getFile();
        if (file == null) throw new ActionFailedException("No file selected");

        fd.addComponentListener(new ComponentAdapter() {

            @Override
            public void componentHidden(ComponentEvent e) {
                fd.removeComponentListener(this);
                fd.setFile(file);
            }
        });

        invokeAndWait(new Runnable() {

            @Override
            public void run() {
                fd.hide();
                fd.setFile(file);
            }
        });
        fd.setFile(file);
    }

    /** Close the file dialog without selecting a file. */
    public void actionCancel(Component comp) {
        final FileDialog fd = (FileDialog)comp;
        fd.addComponentListener(new ComponentAdapter() {

            @Override
            public void componentHidden(ComponentEvent e) {
                fd.removeComponentListener(this);
                fd.setFile(null);
            }
        });
        invokeAndWait(new Runnable() {

            @Override
            public void run() {
                fd.hide();
                fd.setFile(null);
            }
        });
        fd.setFile(null);
    }
}
