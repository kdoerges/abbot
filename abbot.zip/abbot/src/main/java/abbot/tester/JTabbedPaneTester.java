package abbot.tester;

import java.awt.Component;
import java.awt.Rectangle;
import java.util.ArrayList;

import javax.swing.JTabbedPane;
import javax.swing.plaf.TabbedPaneUI;

import abbot.util.ExtendedComparator;


public class JTabbedPaneTester extends JComponentTester {

    /** Return an array of strings that represent the tabs in the pane.
     */
    public String[] getTabs(Component comp) {
        JTabbedPane tp = (JTabbedPane)comp;
        int count = tp.getTabCount();
        ArrayList<String> list = new ArrayList<String>(count);
        for (int i = 0; i < count; i++) {
            list.add(tp.getTitleAt(i));
        }
        return list.toArray(new String[count]);
    }

    public void actionSelectIndex(Component comp, final int index) {
        final JTabbedPane tp = (JTabbedPane)comp;
        int current = tp.getSelectedIndex();
        if (current == index) return;

        if (getEventMode() == EM_PROG) {
            invokeAndWait(new Runnable() {

                public void run() {
                    tp.setSelectedIndex(index);
                }
            });
        } else {
            TabbedPaneUI ui = tp.getUI();
            Rectangle rect = ui.getTabBounds(tp, index);
            click(tp, rect.x + (rect.width + 1) / 2, rect.y + (rect.height + 1) / 2);
            waitForIdle();
        }
    }

    public void actionSelectTab(Component comp, String tabName) {
        JTabbedPane tp = (JTabbedPane)comp;


        //abbot_ext_begin

        // Zun�chst �ber den Namen, nicht den Titel suchen
        String currentTabName = tp.getComponentAt(tp.getSelectedIndex()).getName();
        if (tabName.equals(currentTabName)) return;

        for (int i = 0; i < tp.getTabCount(); i++) {

            String tempNextTabName = tp.getComponentAt(i).getName();
            if (tabName.equals(tempNextTabName)) {
                actionSelectIndex(comp, i);
                return;
            }
        }

        //abbot_ext_end


        String tab = tp.getTitleAt(tp.getSelectedIndex());
        if (ExtendedComparator.stringsMatch(tabName, tab)) return;

        for (int i = 0; i < tp.getTabCount(); i++) {
            if (ExtendedComparator.stringsMatch(tabName, tp.getTitleAt(i))) {
                actionSelectIndex(comp, i);
                return;
            }
        }
        // While actions are supposed to represent real user actions, it's
        // possible that the current environment does not match sufficiently,
        // so we need to throw an appropriate exception that can be used to
        // diagnose the problem.
        throw new ActionFailedException("Tab '" + tabName + "' not found in JTabbedPane");
    }
}
