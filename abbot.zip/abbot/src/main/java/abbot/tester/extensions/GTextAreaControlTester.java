package abbot.tester.extensions;

import java.awt.Component;

import javax.swing.JViewport;

import abbot.tester.JComponentTester;
import abbot.tester.JTextComponentTester;
import de.gebit.trend.gui.textfield.GTextAreaControl;


/**
 * Tester f�r das TREND-GTextAreaControl
 * @author sk
 */
public class GTextAreaControlTester extends JComponentTester {

    private final JTextComponentTester theJTextComponentTester = new JTextComponentTester();


    public GTextAreaControlTester() {
        super();
    }

    protected Component getTextAreaForTester(Component c) {

        if (!(c instanceof GTextAreaControl)) {
            return c;
        } else {
            GTextAreaControl tc = (GTextAreaControl)c;
            Component tempViewPort = tc.getComponent(0);
            Component tempTheTheRealComponent = ((JViewport)tempViewPort).getComponent(0);
            return tempTheTheRealComponent;

            //          if ("addressList".equals(tc.getName())) {
            //              Component tempTheRealComponent = tc.getComboBox();
            //
            //              return tempTheRealComponent;
            //            GChoiceControl tc = (GChoiceControl)c;
            //            if ("addressList".equals(tc.getName())) {
            //                Component tempTheRealComponent = tc.getComboBox();
            //
            //                return tempTheRealComponent;
            //            } else {
            //                return c;
            //            }
        }
    }


    /**
     * Type the given text into the given component, replacing any existing
     * text already there.
     */
    public void actionEnterText(Component c, String text) {
        theJTextComponentTester.actionEnterText(getTextAreaForTester(c), text);
    }

    /** Click at the given index position. */

    public void actionClick(Component c, int index) {
        theJTextComponentTester.actionClick(getTextAreaForTester(c), index);
    }

    /** Select the given range of text. */

    public void actionSelect(Component comp, int start, int end) {
        theJTextComponentTester.actionSelect(getTextAreaForTester(comp), start, end);
    }


    /** Start a selection at the given index. */

    public void actionStartSelection(Component comp, int index) {
        theJTextComponentTester.actionStartSelection(getTextAreaForTester(comp), index);
    }

    /** Terminate a selection on the given index. */

    public void actionEndSelection(Component comp, int index) {
        theJTextComponentTester.actionEndSelection(getTextAreaForTester(comp), index);
    }

    @Override
    public void actionActionMap(Component comp, String name) {
        theJTextComponentTester.actionActionMap(getTextAreaForTester(comp), name);
    }


}
