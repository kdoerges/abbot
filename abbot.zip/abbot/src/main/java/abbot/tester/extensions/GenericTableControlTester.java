package abbot.tester.extensions;

import java.awt.Component;

import abbot.tester.JComponentTester;
import de.gebit.trend.gui.generic.list.GenericTableControl;
import de.gebit.trend.gui.list.GListSelectionModel;
import extensions.system.AbbotScriptrunnerException;


public class GenericTableControlTester extends GTableControlTester {

   
}
