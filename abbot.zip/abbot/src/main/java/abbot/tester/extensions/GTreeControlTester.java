package abbot.tester.extensions;

import java.awt.Component;
import java.util.Arrays;
import java.util.List;

import abbot.tester.JComponentTester;
import de.gebit.trend.gui.treeview.GTreeControl;
import de.gebit.trend.gui.treeview.GTreeModel;


public class GTreeControlTester extends JComponentTester {

    /**
     * Bei Mehrfachselektion Trenner zwischen den Eintr�gen
     */
    public static final String ENTRY_SEPARATOR = "@@";

    /**
     * Kennzeichen, falls kein Eintrag selektiert ist
     */
    public static final String NO_ENTRY_SELECTED_INDICATOR = "NONE";

    /**
     * Es werden Eintr�ge in einem GTreeControl selektiert
     * Sollen mehrere Eintr�ge selektiert werden, so sind die Werte in selectedValue 
     * durch @@ voneinander zu trennen
     * Die Suche nach den jeweiligen Baumeintr�ge erfolgt dadurch, dass jedem Baumeintrag to Nachricht toString
     * geschickt wird. Der (erste) Eintrag, der denselben Wert zur�ckliefert wie selectedValue, wird selektiert
     */
    public void actionSelectItem(Component c, String selectedValue) throws Exception {
        if (c instanceof GTreeControl) {
            GTreeControl tempTreeComponent = (GTreeControl)c;

            GTreeModel tempGModel = (GTreeModel)tempTreeComponent.getGModel();

            Object[] selObjects = new Object[0];
            if ((selectedValue != null) && (!selectedValue.trim().equals(NO_ENTRY_SELECTED_INDICATOR))) {
                String[] tempRecordedEntries = selectedValue.split(ENTRY_SEPARATOR);
                if (tempRecordedEntries.length > 0) {
                    selObjects = findEntries(tempGModel, tempRecordedEntries);
                }
            }

            tempTreeComponent.setSelectedObjects(selObjects);
            
            for (Object tempObject : selObjects) {
                tempTreeComponent.fireItemStateChanged(tempObject, true);
                
            }
            

        }
    }


    /**
     * Such im GModel die zu den Strings passenden Eintr�ge
     */
    private Object[] findEntries(GTreeModel aGModel, String[] recordedEntries) throws Exception {

        Object[] tempResult = new Object[recordedEntries.length];
        Object[] tempRoot = aGModel.getRoot();
        List<Object> tempRootList = Arrays.asList(tempRoot);


        for (int i = 0; i < recordedEntries.length; i++) {
            Object tempNextEntry = findEntry(aGModel, tempRootList, recordedEntries[i]);
            if (tempNextEntry == null) {
                String tempMessage = "Entry " + tempNextEntry + " not found.";
                throw new Exception(tempMessage);
            } else {
                tempResult[i] = tempNextEntry;
            }
        }

        return tempResult;
    }

    /**
     * Sucht im GModel aus den �bergebenen TreeEntries denjenigen heraus, der zu aRecordedValue passt
     * Es wird dabei auch rekursiv in den Unterknoten der treeEntries gesucht
     */
    @SuppressWarnings("unchecked")
    private Object findEntry(GTreeModel aGModel, List treeEntries, String aRecordedValue) {

        for (Object tNextTreeEntry : treeEntries) {
            if ((tNextTreeEntry != null) && (tNextTreeEntry.toString().equals(aRecordedValue))) {
                return tNextTreeEntry;
            } else {
                if (tNextTreeEntry != null) {
                    // Suche in den Unterknoten
                    List tempChildren = aGModel.getChildrenOf(tNextTreeEntry);
                    Object tempFoundEntry = findEntry(aGModel, tempChildren, aRecordedValue);
                    if (tempFoundEntry != null) {
                        return tempFoundEntry;
                    }
                }
            }
        }

        // Keinen passenden Eintrag gefunden
        return null;

    }


}
