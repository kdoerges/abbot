package abbot.tester.extensions;

import java.awt.Component;
import java.lang.reflect.Method;
import java.math.BigDecimal;

import util.BusinessObjectUtil;

import abbot.editor.editors.AssertEditor;
import abbot.script.ComponentReference;
import abbot.tester.JComponentTester;
import de.gebit.trend.gui.list.GTableControl;
import de.gebit.trend.gui.list.GListSelectionModel;
import de.gebit.trend.model.ModelUtil;
import extensions.system.AbbotScriptrunnerException;



public class GTableControlTester extends JComponentTester {

	public static final String ACTION_NONE = "none";
	public static final String ACTION_SET = "set";
	public static final String ACTION_CHECK = "check";
	
	
	public String assertCellValue(ComponentReference ref, String row, String columnName) throws Exception {

		Component c = ref.findInHierarchy(getFinder());
		GTableControl tempTableComponent = (GTableControl) c;
		Object tempSelectedObject = tempTableComponent.getValueAt(new Integer(row) - 1);
						
		Object tempNextObject = BusinessObjectUtil.theInstance().get(tempSelectedObject, columnName);
		
    	if (tempNextObject == null) {
    		return null;
    	} else {
    		return tempNextObject.toString();
    	}	
	}
	

	
    public void actionSelectItem(Component c, String selectedRow) throws Exception {
    	actionSelectItem(c, selectedRow, null, null, ACTION_NONE, false);
    }

    
    public void actionSelectItem(Component c, String selectedRow, String selectedColumn) throws Exception {
        actionSelectItem(c, selectedRow, selectedColumn, null, ACTION_NONE, false);
    }
    

    public void actionSelectItem(Component c, String selectedRow, String selectedColumn, String aValue, String action) throws Exception {
    	actionSelectItem(c, selectedRow, selectedColumn, aValue, action, false);
    }
    
    public void actionSelectItem(Component c, String selectedRow, String selectedColumn, boolean selectRange) throws Exception {
    	actionSelectItem(c, selectedRow, selectedColumn, null, null, selectRange);
    }
    
    
    public void actionSelectItem(Component c, String selectedRow, String selectedColumn, String aColumnValue, String action,  boolean selectRange) throws Exception {
        if (c instanceof GTableControl) {
            GTableControl tempTableComponent = (GTableControl)c;

            if ((selectedRow != null) && (!selectedRow.trim().equals(""))) {
                int tempSelectRow = new Integer(selectedRow).intValue();
                int tempNumberOfAvailableRows = tempTableComponent.getItemCount();

                if (tempSelectRow < 1) {
                    String tempException = "Illegal row selection (" + tempSelectRow + "): must be greater than 0";
                    throw new AbbotScriptrunnerException(tempException);
                }
                if (tempSelectRow > tempNumberOfAvailableRows) {
                    String tempException =
                            "Row " + tempSelectRow + " not availabe; number of rows = " + tempNumberOfAvailableRows;
                    throw new AbbotScriptrunnerException(tempException);
                } else {
                    if (tempTableComponent.getSelectionModel().isSingleSelection()) {
                        tempTableComponent.setSelectedIndex(tempSelectRow - 1);
                    	Object tempSelectedObject = tempTableComponent.getValueAt(tempSelectRow-1);
                    	
                    	if (ACTION_NONE.equals(action)) {                  		
                    		return;
                    	}
                    	else if (ACTION_SET.equals(action)) {
                    		if (aColumnValue != null) {
                    			BusinessObjectUtil.theInstance().set(tempSelectedObject, selectedColumn, aColumnValue);
                    			((GTableControl) c).repaintItem(new Integer(selectedRow) - 1);
                    		}
                    	} else {
                    		// Check
                    		Object tempActualValue = BusinessObjectUtil.theInstance().get(tempSelectedObject, selectedColumn);
                    		boolean tempOK = true;
                    		if ((tempActualValue == null) && (aColumnValue == null)) {
                    			tempOK = true;
                    		} if ((tempActualValue == null) || (aColumnValue == null)) {
                    			tempOK = false;
                    		}else {
                    			tempOK = (tempActualValue.toString().equals(aColumnValue.toString()));
                    			if (tempOK) {
                    				return;
                    			} else {
                    				String tempMessage = "Column value differs; expected=" + aColumnValue.toString() + "; actual=" + tempActualValue.toString();
                    				throw new Exception(tempMessage);
                    			}
                    		}
                    	}

                        
                    } else {
                        if (selectRange) {
                            int tempStartIndex = 1;
                            int[] tempSelIndices = tempTableComponent.getSelectedIndices();
                            if ((tempSelIndices.length) > 0) {
                                tempStartIndex = tempSelIndices[tempSelIndices.length - 1] + 1;
                            }

                            for (int i = tempStartIndex; i <= tempSelectRow; i++) {
                                tempTableComponent.getSelectionModel()
                                        .setSelectionState(i - 1, GListSelectionModel.STATE_SELECTED);
                            }

                        } else {
                            tempTableComponent.getSelectionModel()
                                    .setSelectionState((tempSelectRow - 1), GListSelectionModel.STATE_SELECTED);
                        }
                    }

                }
            }

            ;


        }
    }

}
