package abbot.tester.extensions;

import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JLabel;

import abbot.script.ComponentReference;
import abbot.tester.JComponentTester;
import abbot.tester.JTextComponentTester;
import de.gebit.trend.gui.list.GCodeControl;


/**
 * Tester f�r das TREND-GCodeControl
 * @author sk
 */
public class GCodeControlTester extends JComponentTester {

    private final JTextComponentTester theJTextComponentTester = new JTextComponentTester();

    private final GChoiceControlTester theJChoiceControlTester = new GChoiceControlTester();

    public GCodeControlTester() {
        super();
    }

    private static final String LABELED_BY_PROPERTY = "labeledBy";

    /** Derive a tag for identifying this component.  */

    // Diese Methode wurde �berschrieben, da das JCodeControl ein zugeordnetes Label hat
    // Diese Information soll aber nicht f�r die Bestimmung des Labels verwendet werden
    @Override
    public String deriveTag(Component comp) {

        if (ComponentReference.isOldConventionMode()) {
            return super.deriveTag(comp);
        }

        String tag = null;


        // Falls Label existiert, dieses zun�chst aus den clientProperty heraus nehmen,
        // und nach der Bestimmung des tags wieder zur�ck setzen
        JLabel label = (JLabel)((JComponent)comp).getClientProperty(LABELED_BY_PROPERTY);

        if (label != null) {
            ((JComponent)comp).putClientProperty(LABELED_BY_PROPERTY, null);
        }

        tag = super.deriveTag(comp);

        if (label != null) {
            ((JComponent)comp).putClientProperty(LABELED_BY_PROPERTY, label);
        }


        return tag;
    }


    protected Component getCodeTextControlForTester(Component c) {

        if (!(c instanceof GCodeControl)) {
            return c;
        } else {
            GCodeControl tc = (GCodeControl)c;
            return tc.getComponent(1);
            //            try {
            //                GCodeControl tc = (GCodeControl)c;
            //                Field tempField = tc.getClass().getField("codeTextControl");
            //                tempField.setAccessible(true);
            //                Component tempCodeTextControl = (Component)tempField.get(tc);
            //                return tempCodeTextControl;
            //            } catch (Exception e) {
            //                logger.error("Something ugly happened: ",e);
            //                return null;
            //            }

        }
    }

    protected Component getCodeChoiceControlForTester(Component c) {

        if (!(c instanceof GCodeControl)) {
            return c;
        } else {
            GCodeControl tc = (GCodeControl)c;
            return tc.getComponent(0);
            //            try {
            //                GCodeControl tc = (GCodeControl)c;
            //                Field tempField = tc.getClass().getField("codeChoiceControl");
            //                tempField.setAccessible(true);
            //                Component tempCodeTextControl = (Component)tempField.get(tc);
            //                return tempCodeTextControl;
            //            } catch (Exception e) {
            //                logger.error("Something ugly happened: ",e);
            //                return null;
            //            }

        }
    }


    /**
     * Type the given text into the given component, replacing any existing
     * text already there.
     */
    public void actionEnterText(Component c, String text) {
        theJTextComponentTester.actionEnterText(getCodeTextControlForTester(c), text);
    }

    /** Click at the given index position. */

    public void actionClick(Component c, int index) {
        theJTextComponentTester.actionClick(getCodeTextControlForTester(c), index);
    }

    /** Select the given range of text. */

    public void actionSelect(Component comp, int start, int end) {
        theJTextComponentTester.actionSelect(getCodeTextControlForTester(comp), start, end);
    }


    /** Start a selection at the given index. */

    public void actionStartSelection(Component comp, int index) {
        theJTextComponentTester.actionStartSelection(getCodeTextControlForTester(comp), index);
    }

    /** Terminate a selection on the given index. */

    public void actionEndSelection(Component comp, int index) {
        theJTextComponentTester.actionEndSelection(getCodeTextControlForTester(comp), index);
    }

    @Override
    public void actionActionMap(Component comp, String name) {
        theJTextComponentTester.actionActionMap(getCodeTextControlForTester(comp), name);
    }

    public void actionSelectItem(Component comp, String item) {
        theJChoiceControlTester.actionSelectItem(getCodeChoiceControlForTester(comp), item);
    }

    public void actionSelectIndex(Component comp, final int index) {
        theJChoiceControlTester.actionSelectIndex(getCodeChoiceControlForTester(comp), index);

    }

}
