package abbot.tester.extensions;

import java.awt.Component;

import abbot.tester.JComponentTester;
import abbot.tester.JTextComponentTester;
import de.gebit.trend.gui.calendar.GCalendarControl;


/**
 * Tester f�r das TREND-GCalendarControl
 * @author sk
 */
public class GCalendarControlTester extends JComponentTester {

    private final JTextComponentTester theJTextComponentTester = new JTextComponentTester();


    public GCalendarControlTester() {
        super();
    }

    protected Component getTextAreaForTester(Component c) {

        if (!(c instanceof GCalendarControl)) {
            return c;
        } else {

            return ((GCalendarControl)c).getComponent(0);

        }
    }


    /**
     * Type the given text into the given component, replacing any existing
     * text already there.
     */
    public void actionEnterText(Component c, String text) {
        theJTextComponentTester.actionEnterText(getTextAreaForTester(c), text);
    }

    /** Click at the given index position. */

    public void actionClick(Component c, int index) {
        theJTextComponentTester.actionClick(getTextAreaForTester(c), index);
    }

    @Override
    public void actionClick(Component comp, int x, int y, String buttons, int count) {
        theJTextComponentTester.actionClick(getTextAreaForTester(comp), x, y, buttons, count);
    }


    /** Select the given range of text. */

    public void actionSelect(Component comp, int start, int end) {
        theJTextComponentTester.actionSelect(getTextAreaForTester(comp), start, end);
    }


    /** Start a selection at the given index. */

    public void actionStartSelection(Component comp, int index) {
        theJTextComponentTester.actionStartSelection(getTextAreaForTester(comp), index);
    }

    /** Terminate a selection on the given index. */

    public void actionEndSelection(Component comp, int index) {
        theJTextComponentTester.actionEndSelection(getTextAreaForTester(comp), index);
    }

    @Override
    public void actionActionMap(Component comp, String name) {
        theJTextComponentTester.actionActionMap(getTextAreaForTester(comp), name);
    }


}
