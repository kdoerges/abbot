package abbot.tester.extensions;

import java.awt.Component;

import abbot.tester.JComboBoxTester;
import abbot.tester.JComponentTester;
import abbot.tester.JTextComponentTester;
import de.gebit.trend.gui.list.GChoiceControl;


/**
 *  * Tester f�r das TREND-GChoiceControl
 * @author sk
 */
public class GChoiceControlTester extends JComponentTester {

    private final JTextComponentTester theJTextComponentTester = new JTextComponentTester();

    private final JComboBoxTester theJComboBoxTester = new JComboBoxTester();

    public GChoiceControlTester() {
        super();
    }

    protected Component getComboBoxForTester(Component c) {

        if (!(c instanceof GChoiceControl)) {
            return c;
        } else {
            GChoiceControl tc = (GChoiceControl)c;
            Component tempTheRealComponent = tc.getComboBox();
            return tempTheRealComponent;

            //          if ("addressList".equals(tc.getName())) {
            //              Component tempTheRealComponent = tc.getComboBox();
            //
            //              return tempTheRealComponent;
            //            GChoiceControl tc = (GChoiceControl)c;
            //            if ("addressList".equals(tc.getName())) {
            //                Component tempTheRealComponent = tc.getComboBox();
            //
            //                return tempTheRealComponent;
            //            } else {
            //                return c;
            //            }
        }
    }

    protected Component getTextComponentForTester(Component c) {

        if (!(c instanceof GChoiceControl)) {
            return c;
        } else {
            GChoiceControl tc = (GChoiceControl)c;
            //            if ("addressList".equals(tc.getName())) {
            Component tempTheRealComponent = tc.getEditorComponent();

            return tempTheRealComponent;
            //            } else {
            //                return c;
            //            }
        }
    }


    /**
     * Type the given text into the given component, replacing any existing
     * text already there.
     */
    public void actionEnterText(Component c, String text) {
        theJTextComponentTester.actionEnterText(getTextComponentForTester(c), text);
    }

    /** Click at the given index position. */

    public void actionClick(Component c, int index) {
        theJTextComponentTester.actionClick(getTextComponentForTester(c), index);
    }

    /** Select the given range of text. */

    public void actionSelect(Component comp, int start, int end) {
        theJTextComponentTester.actionSelect(getTextComponentForTester(comp), start, end);
    }


    /** Start a selection at the given index. */

    public void actionStartSelection(Component comp, int index) {
        theJTextComponentTester.actionStartSelection(getTextComponentForTester(comp), index);
    }

    /** Terminate a selection on the given index. */

    public void actionEndSelection(Component comp, int index) {
        theJTextComponentTester.actionEndSelection(getTextComponentForTester(comp), index);
    }

    @Override
    public void actionActionMap(Component comp, String name) {
        theJTextComponentTester.actionActionMap(getTextComponentForTester(comp), name);
    }

    public void actionSelectItem(Component comp, String item) {
        theJComboBoxTester.actionSelectItem(getComboBoxForTester(comp), item);
    }

    public void actionSelectIndex(Component comp, final int index) {
        theJComboBoxTester.actionSelectIndex(getComboBoxForTester(comp), index);

    }

}
