package abbot.tester;

import java.awt.Component;

import javax.swing.JButton;

import abbot.Log;


public class AbstractButtonTester extends JComponentTester {

    @Override
    public String deriveTag(Component comp) {

        //abbot_ext_begin
        // Der Text von Buttons wird nicht als Tag verwendet, da nicht I18N-f�hig
        //        AbstractButton absButton = ((AbstractButton)comp);
        //        String tag = stripHTML(absButton.getText());
        //        if ("".equals(tag) || tag == null) {
        //            tag = super.deriveTag(comp);
        //        }

        String tag = super.deriveTag(comp);


        //abbot_ext_end

        return tag;
    }

    /** AbstractButton click action. */
    @Override
    public void actionClick(final Component c) {
        if (getEventMode() == EM_PROG) {
            invokeAndWait(new Runnable() {

                public void run() {

                    waitForComponentEnabled(c);
                    //Abbot_Ext_Begin
                    if (!c.isEnabled()) {
                        clickFailed(c);
                    } else {
                        ((JButton)c).doClick();
                    }
                }
            });
        } else /* EM_ROBOT */{

            waitForComponentEnabled(c);

            if (!c.isEnabled()) {
                clickFailed(c);
            } else {
                click(c);
                waitForIdle();
            }

        }
    }


    /**
     * Wird aufgerufen, wenn auf eine Komponente (Button) nicht geklickt werden konnte
     * @param c die Komponente
     */
    private void clickFailed(Component c) {
        String tempMessage =
                "Could not click " + c.getClass().getSimpleName() + " " + c.getName() + " because it is not enabled;";
        tempMessage = tempMessage + " waiting duration was " + maxWaitEnabledCycles() + " seconds.";

        System.out.println(tempMessage);
        // TestScriptRunner.getLastActiveInstance().setTerminationRequested(new AbbotScriptrunnerException(tempMessage));

    }

    /**
     * Anzahl der Versuche beim Klicken auf eine Komponente (Button)
     * @return die Anzahl der Versuche
     */
    private int maxWaitEnabledCycles() {
        return 5;
    }

    /**
     * Wartet, bis die �bergebene Komponente enabled ist
     * oder die Anzahl der Versuche erreicht ist
     * @param c die Komponente
     * @return true, falls Komponente enabled, false sonst
     */
    private boolean waitForComponentEnabled(Component c) {

        boolean tempButtonEnabled = c.isEnabled();
        int tempCounter = 0;

        while (!tempButtonEnabled && tempCounter < maxWaitEnabledCycles()) {
            try {
                tempCounter++;
                String tempWarning =
                        "Waiting (#"
                                + tempCounter
                                + ") for  "
                                + c.getClass().getSimpleName()
                                + " "
                                + c.getName()
                                + " to be enabled";
                Log.warn(tempWarning);
                Thread.sleep(1000);
                tempButtonEnabled = c.isEnabled();
            } catch (InterruptedException e) {
                //Egal
            }
        }

        return tempButtonEnabled;

    }

    //Abbot_Ext_End
}
