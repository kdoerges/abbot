package abbot.tester;


public class ContainerTester extends ComponentTester {

}
