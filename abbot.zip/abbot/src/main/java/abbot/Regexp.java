package abbot;

import gnu.regexp.RE;
import gnu.regexp.REException;
import gnu.regexp.REMatch;

/** Simple wrapper around the more fully-featured RE class. */

public class Regexp {
    /** Return whether there is a match for the given regular expression
     * within the given string.
     */
    public static boolean stringContainsMatch(String regexp, String actual) {
        try {
            RE e = new RE(regexp);
            REMatch m = e.getMatch(actual);
            return m != null;
        }
        catch(REException exc) {
            Log.warn(exc);
            return false;
        }
    }
    /** Return whether the given regular expression matches the given string
     * exactly. 
     */
    public static boolean stringMatch(String regexp, String actual) {
        if (actual == null)
            actual = "";
        try {
            RE e = new RE(regexp);
            REMatch m = e.getMatch(actual);
            return m != null && m.toString().equals(actual);
        }
        catch(REException exc) {
            Log.warn(exc);
            return false;
        }
    }
}
