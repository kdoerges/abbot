/* 
 * Copyright 2004 Gesellschaft f. Datenverarbeitung 
 * All Rights Reserved. * http://www.gfd.de 
 * 
 * File:    PopupListener.java 
 * Project: _internAbbot 
 * 
 * Date:    06.12.2004 11:06:02 
 * Creator: drexler
 */

package abbot.editor;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPopupMenu;


/** 
 * TODO Beschreibung des Einsatzgebiets von "PopupListener.java" 
 * @author drexler 
 */
public class PopupListener extends MouseAdapter {

    JPopupMenu popup;

    PopupListener(JPopupMenu popupMenu) {
        popup = popupMenu;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        maybeShowPopup(e);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        maybeShowPopup(e);
    }

    private void maybeShowPopup(MouseEvent e) {
        if (e.isPopupTrigger()) {
            popup.show(e.getComponent(), e.getX(), e.getY());
        }
    }
}
