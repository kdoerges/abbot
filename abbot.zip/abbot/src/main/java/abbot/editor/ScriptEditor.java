package abbot.editor;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.MenuComponent;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.InputMap;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import junit.extensions.abbot.ScriptFixture;
import junit.extensions.abbot.ScriptTestSuite;
import junit.framework.Test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import abbot.AssertionFailedError;
import abbot.ComponentFinder;
import abbot.DefaultComponentFinder;
import abbot.Log;
import abbot.NoExitSecurityManager;
import abbot.NoSuchReferenceException;
import abbot.Platform;
import abbot.Resolver;
import abbot.editor.actions.EditorAction;
import abbot.editor.actions.EditorToggleAction;
import abbot.editor.editors.StepChangeListener;
import abbot.editor.editors.StepEditor;
import abbot.editor.recorder.EventRecorder;
import abbot.editor.recorder.Recorder;
import abbot.editor.recorder.RecordingFailedException;
import abbot.i18n.Strings;
import abbot.script.Action;
import abbot.script.Annotation;
import abbot.script.ArgumentParser;
import abbot.script.Assert;
import abbot.script.Call;
import abbot.script.Comment;
import abbot.script.ComponentReference;
import abbot.script.EventExceptionHandler;
import abbot.script.InvalidScriptException;
import abbot.script.Launch;
import abbot.script.Sample;
import abbot.script.Script;
import abbot.script.ScriptFilter;
import abbot.script.Sequence;
import abbot.script.Step;
import abbot.script.StepEvent;
import abbot.script.StepListener;
import abbot.script.StepRunner;
import abbot.script.Terminate;
import abbot.tester.ComponentTester;
import abbot.tester.ImageComparator;
import abbot.tester.InputState;
import abbot.tester.Robot;
import abbot.util.AWT;
import abbot.util.EventNormalizer;
import abbot.util.Properties;
import abbot.util.SingleThreadedEventListener;
import abbot.util.ThreadTerminatingSecurityManager.ThreadTerminatedException;

import com.apple.mrj.MRJApplicationUtils;
import com.apple.mrj.MRJQuitHandler;


/**
 * Costello, the editor for Abbot scripts.<p>
 *
 * Acts as a resolver, using the currently in-context script as the component
 * resolver. <p>
 */
public class ScriptEditor implements ActionListener, Resolver, EditorConstants {

    private static final Logger logger = LoggerFactory.getLogger(ScriptEditor.class);

    static {
        try {
            new EventExceptionHandler().install();
        } catch (Exception e) {
            logger.warn("Could not install event exception handler!", e);
        }
    }

    // if set, log all events, even those going to filtered components
    protected static final boolean logAllEvents = Boolean.getBoolean("abbot.editor.log_all_events");

    protected static final long fixtureEventMask = Properties.getProperty("abbot.fixture.event_mask",
                                                                          Long.MIN_VALUE,
                                                                          Long.MAX_VALUE,
                                                                          EventRecorder.RECORDING_EVENT_MASK);

    /** Key to use to invert an assertion/wait. */
    public static final int KC_INVERT = KeyEvent.VK_SHIFT;

    /** Key to use to insert a wait instead of an assertion.   Use option key
        on mac, control key anywhere else. */
    public static final int KC_WAIT = Platform.isMacintosh() ? KeyEvent.VK_ALT : KeyEvent.VK_CONTROL;

    /** Flag for informational status. */
    protected static final int INFO = 0;

    /** Flag to indicate a warning. */
    protected static final int WARN = 1;

    /** Flag to indicate an error. */
    protected static final int ERROR = 2;

    /** Flag to indicate a script failure. */
    protected static final int FAILURE = 3;

    /** Prefixes for different types of status messages. */
    protected static final String[] statusFormat = {"Normal", "Warning", "Error", "Failure"};

    protected static final Color[] statusColor = {Color.black, Color.orange.darker(), Color.red, Color.red,};

    /** All editor actions. */
    protected EditorAction[] actions;

    protected ArrayList<javax.swing.Action> insertActions = new ArrayList<javax.swing.Action>();

    protected ArrayList<javax.swing.Action> assertActions = new ArrayList<javax.swing.Action>();

    protected ArrayList<javax.swing.Action> waitActions = new ArrayList<javax.swing.Action>();

    protected ArrayList<javax.swing.Action> captureActions = new ArrayList<javax.swing.Action>();

    /** Adapter for representing the script itself, providing access to
     * individual script steps.
     */
    protected ScriptModel scriptModel;

    protected ScriptTable scriptTable;

    protected EditorSecurityManager securityManager = null;

    protected SecurityManager oldSecurityManager = null;

    protected ThreadGroup editorGroup;

    /** Keep all application under test threads in the same group to make them
     * easier to track. */
    protected ThreadGroup appGroup;

    public ComponentFinder finder;

    protected Recorder[] recorders;

    @SuppressWarnings("unchecked")
    protected java.util.List savedStateWhileRecording;

    /** Allow exits from anywhere until the editor is fully initialized. */
    protected boolean rootIsExiting = true;

    protected boolean exiting = false;

    protected boolean ignoreStepEvents = false;

    /** Whether to ignore incoming AWT events. */
    protected boolean ignoreEvents = false;

    /** Is there a script or launch step currently running? */
    protected boolean isScriptRunning = false;

    /** Is the app currently launched/visible? */
    protected boolean isAppLaunched = false;

    /** When was the app last launched? */
    protected long lastLaunchTime = 0;

    /** Are we trying to capture an image? */
    protected boolean capturingImage = false;

    /** What component is currently "selected" for capture? */
    protected Component captureComponent = null;

    protected Component innermostCaptureComponent = null;

    /** Is this the first editor launched, or one under test? */
    protected boolean isRootEditor = true;

    /** AWT input state. */
    protected static InputState state = new InputState();

    /** Generic filter to select a test script. */
    protected ScriptFilter filter = new ScriptFilter();

    /** Current test case class (should derive from AWTTestCase). */
    protected Class testClass = null;

    /** Current test suite.  */
    protected ScriptTestSuite testSuite = null;

    /** Current test script. */
    protected Script testScript = null;

    /** Runner used to execute the script. */
    protected StepRunner runner = null;

    /** Current set of scripts, based on the test suite (if any). */
    protected List<String> testScriptList = null;

    /** Currently selected component.  Note that this may be a dummy
     * component.
     */
    protected Component selectedComponent = null;

    /** Currently selected reference, if any. */
    protected ComponentReference selectedReference = null;

    /** Are we currently recording events? */
    protected boolean recording = false;

    /** The current recorder to pass events for capture. */
    protected Recorder recorder = null;

    /** Since recorder starts with a key release, and stops with a key press,
        make sure we don't start immediately after stopping.
    */
    protected boolean justStoppedRecording = false;

    /** Need to be able to set the combo box selection w/o reacting to the
     * resulting posted action.
     */
    protected boolean ignoreComboBox = false;

    /** Where to stop. */
    protected Step stopStep = null;

    // GUI components
    protected JFileChooser chooser;

    public ScriptEditorFrame view = null;

    protected boolean invertAssertions = false;

    protected boolean waitAssertions = false;

    /**
     * Constructs a ScriptEditor with the specified view
     */
    public ScriptEditor() {
        if (!Boolean.getBoolean("abbot.editor.root")) {
            isRootEditor = true;
            System.setProperty("abbot.editor.root", "true");
        }

        initContext();
        initRecorders();
        initFrame();
        initScriptTableAndComponentBrowser();
        addEventHandlers();

        editorGroup = new ThreadGroup("Editor Threads " + this) {

            @Override
            public void uncaughtException(Thread t, Throwable thrown) {
                if (thrown instanceof ThreadTerminatedException) {
                    Log.log("AUT Thread terminated: " + t);
                } else {
                    Log.warn("Editor thread exception not caught: " + t);
                    Log.warn(thrown);
                }
            }
        };
        // Clear the status only if there were no errors
        if (view.getStatus().equals(Strings.get("Initializing"))) {
            setStatus(Strings.get("Ready"));
        }
        rootIsExiting = false;
    }

    /**
     *  Add event handlers to their respective components
     */
    protected void addEventHandlers() {
        scriptTable.getSelectionModel().addListSelectionListener(new ScriptTableSelectionHandler());
        scriptTable.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent me) {
                if ((me.getModifiers() & MouseEvent.BUTTON1_MASK) != 0) {
                    if (view.getEditor() == null) showStepEditor();
                }
            }
        });
        MouseListener ml = new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent me) {
                if ((me.getModifiers() & MouseEvent.BUTTON1_MASK) != 0) {
                    int size = scriptTable.getRowCount();
                    scriptTable.clearSelection();
                    scriptTable.setCursorLocation(size);
                }
            }
        };
        view.addMouseListener(ml);
        view.getTestScriptSelector().addItemListener(new ScriptSelectorItemHandler());
        view.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                quit();
            }
        });
        if (Platform.isOSX()) {
            // Mac has it's own dedicated Quit menu item
            MRJApplicationUtils.registerQuitHandler(new MRJQuitHandler() {

                @Override
                public void handleQuit() {
                    Log.debug("Quit from MRJ quit handler");
                    quit();
                }
            });
        }
    }

    /**
     * Determines if the editor is testing itself and initializes the 
     * security manager accordingly.  
     */
    protected void initContext() {
        finder = DefaultComponentFinder.getFinder();
        if (isRootEditor) {
            initSecurityManager();
            try {
                new EventExceptionHandler().install();
            } catch (Exception e) {
                showWarning(e.toString());
            }
        }
    }

    protected void initRecorders() {
        // Use the editor as the resolver, since the actual resolver will
        // be the currently scoped script.
        recorders = new Recorder[] {new EventRecorder(this, false), new EventRecorder(this, true),};

        ActionListener recorderListener = new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent event) {
                setStatus(event.getActionCommand());
            }
        };
        for (int i = 0; i < recorders.length; i++) {
            if (recorders[i] != null) recorders[i].addActionListener(recorderListener);
        }
    }

    /** Initialize the primary editor frame. */
    protected void initFrame() {

        actions = createActions();

        scriptModel = new ScriptModel() {

            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
        runner = new StepRunner() {

            @Override
            public void terminate() {
                super.terminate();
                setAppLaunched(false);
                view.getComponentBrowser().refresh();
            }
        };
        runner.setTerminateOnError(false);
        runner.addStepListener(new StepListener() {

            @Override
            public void stateChanged(StepEvent ev) {
                if (ignoreStepEvents) return;
                reflectScriptExecutionState(ev);
            }
        });
        scriptTable = new ScriptTable(scriptModel) {

            @Override
            public Color getStepColor(Step step, boolean selected) {
                Throwable thr = runner.getError(step);
                selected = selected || step == stopStep;
                if (thr == null) {
                    return super.getStepColor(step, selected);
                }
                Color color =
                        (thr instanceof AssertionFailedError) ? statusColor[ScriptEditor.FAILURE]
                                : statusColor[ScriptEditor.ERROR];
                if (selected) {
                    Color sel = getSelectionBackground();
                    color = mixColors(color, sel);
                }
                if (step instanceof Sequence) color = mixColors(color, Color.white);
                return color;
            }
        };
        // Override default "cut" action in table
        ActionMap amap = scriptTable.getActionMap();
        amap.put("cut", actions[MI_CUT]);
        InputMap imap = scriptTable.getInputMap();
        imap.put(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0), "toggle");

        // Only allow the script editor to dispose of the frame
        view = new ScriptEditorFrame(this, Strings.get("ScriptEditor.title", new Object[] {""}), scriptTable, actions) {

            @Override
            public void dispose() {
                // Need to prevent arbitrary disposal by the code under test.
                // Only allow the dispose if
                // a) we triggered it (exiting == true)
                // b) the root script editor is disposing us
                if (exiting || isDisposeFromRootEditor()) {
                    Log.debug("Disposing editor frame");
                    super.dispose();
                } else {
                    Log.debug("Dispose ignored");
                }
            }
        };
        updateDynamicActions();

        finder.filterComponent(view);
    }

    /** Provide a color that is a mix of the two given colors. */
    protected Color mixColors(Color c1, Color c2) {
        return new Color((c1.getRed() + c2.getRed()) / 2,
                         (c1.getGreen() + c2.getGreen()) / 2,
                         (c1.getBlue() + c2.getBlue()) / 2);
    }

    /** Return whether the root editor disposed of this instance. */
    protected boolean isDisposeFromRootEditor() {
        // FIXME cf how applets prevent disposal of embedded frame
        // DefaultComponentFinder sets this property in disposeWindows
        return !isRootEditor && Boolean.getBoolean("abbot.finder.disposal");
    }

    protected void createAsserts(List<javax.swing.Action> list, ComponentTester tester, boolean wait) {
        list.clear();
        Method[] methods = tester.getAssertMethods();
        for (int i = 0; i < methods.length; i++) {
            list.add(new TesterMethodAction(tester, methods[i], wait));
        }
        methods = tester.getComponentAssertMethods();
        if (list.size() != 0 && methods.length != 0) {
            list.add(null);
        }
        for (int i = 0; i < methods.length; i++) {
            list.add(new TesterMethodAction(tester, methods[i], wait));
        }
        methods = tester.getPropertyMethods();
        if (list.size() != 0 && methods.length != 0) {
            list.add(null);
        }
        for (int i = 0; i < methods.length; i++) {
            String name = methods[i].getName();
            if (name.startsWith("is"))
                name = name.substring(2);
            else if (name.startsWith("get") || name.startsWith("has")) name = name.substring(3);
            list.add(new TesterMethodAction(tester, methods[i], wait));
        }
    }

    /** Return a script step encapsulating an image comparison.  
     * Assumes the script context is not null.
     */
    protected Step captureImage(Component comp) {
        Step step = null;
        ComponentTester tester = ComponentTester.getTester(comp);
        java.awt.image.BufferedImage img = tester.capture(comp);
        try {
            // Save the image file relative to the current context
            ComponentReference ref = addComponent(comp);
            File scriptFile = ((Script)getContext()).getFile();
            File newFile = new File(getContext().getDirectory(), scriptFile.getName() + "-" + ref.getID() + ".jpg");
            int index = 1;
            while (newFile.exists()) {
                newFile =
                        new File(getContext().getDirectory(), scriptFile.getName()
                                                              + "-"
                                                              + ref.getID()
                                                              + "-"
                                                              + index++
                                                              + ".jpg");
            }
            ImageComparator.writeJPEG(newFile, img);
            // Note that the pathname is saved relative to the script
            // context. 
            step =
                    new Assert(getContext(),
                               null,
                               "assertImage",
                               new String[] {ref.getID(), newFile.getName(), "true"},
                               "true",
                               false);
        } catch (IOException io) {
            Log.warn(io);
        }
        return step;
    }

    /** Start recording, launching the code under test if necessary. */
    protected void startRecording(Recorder rec) {
        Log.debug("Starting recorder");
        boolean noWindows = getShowingWindowCount() == 0;
        boolean canLaunch = testScript != null && testScript.hasLaunch() && !isAppLaunched;
        if (noWindows && !canLaunch) {
            // Can't launch, and there are no windows to
            // record on, so show a warning
            showError(Strings.get("NoWindows.title"), Strings.get("NoWindows"));
        } else {
            if (recorder != null) stopRecording(true);
            Log.debug("Now recording with " + rec);
            recording = true;
            recorder = rec;

            setStatus("Please wait...");
            // Disable the UI while recording; we re-enable the frame itself
            // to avoid being unable to click on it later (w32, 1.4.1)
            savedStateWhileRecording = AWT.disableHierarchy(view);
            view.setEnabled(true);
            // get us out of the way
            // FIXME this puts us WAY back on linux; this is only a
            // problem in that the status bar is often hidden
            // Maybe make a floating status while the recorder is
            // running. 
            // Only go back if the app is already up, otherwise the
            // about-to-be-launched app is hidden.
            if (!noWindows) view.toBack();
            recorder.start();

            if (noWindows) {
                launch(false);
            }
        }
    }

    /** Stop recording and update the recorder actions' state. */
    protected void stopRecording(boolean discardRecording) {
        Log.debug("Stopping recorder");
        recording = false;
        int type = INFO;
        String extended = null;
        String status = Strings.get(discardRecording ? "RecorderCanceled" : "RecorderFinished");
        try {
            recorder.terminate();
        } catch (RecordingFailedException e) {
            Log.log(e);
            showWarning(Strings.get("editor.recording.failure"));
            status = e.getReason().getMessage();
            extended = getStackTrace(e.getReason());
            type = ERROR;
        }
        try {
            if (!discardRecording) {
                addStep(recorder.getStep());
            }
        } finally {
            recorder = null;
            AWT.reenableHierarchy(savedStateWhileRecording);
        }
        view.toFront();
        setStatus(status, extended, type);
    }

    protected RecordAllAction recordAllAction = null;

    protected RecordAllAction recordAllMotionAction = null;

    protected void updateDynamicActions() {
        Class cls = selectedComponent == null ? Component.class : selectedComponent.getClass();
        ComponentTester tester = ComponentTester.getTester(cls);
        // assert submenu
        createAsserts(assertActions, tester, false);
        // wait submenu
        createAsserts(waitActions, tester, true);
        // component-specific insert actions
        insertActions.clear();
        Method[] methods = tester.getActions();
        for (int i = 0; i < methods.length; i++) {
            javax.swing.Action action = new TesterMethodAction(tester, methods[i], true);
            insertActions.add(action);
        }
        methods = tester.getComponentActions();
        for (int i = 0; i < methods.length; i++) {
            javax.swing.Action action = new TesterMethodAction(tester, methods[i], true);
            insertActions.add(action);
        }
        // capture actions

        captureActions.clear();
        recordAllAction = new RecordAllAction(recorders[0], false);
        captureActions.add(recordAllAction);
        recordAllMotionAction = new RecordAllAction(recorders[1], true);
        captureActions.add(recordAllMotionAction);
        captureActions.add(null);
        javax.swing.Action action = new AbstractAction(Strings.get("ImageCapture")) {

            @Override
            public void actionPerformed(ActionEvent ev) {
                // This is really only for documentation purposes; there is
                // nothing to capture if the menu item can be activated, since
                // the editor has focus when the menu is selected.
            }
        };
        action.putValue(javax.swing.Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("shift F3"));
        captureActions.add(action);

        view.populateInsertMenu(insertActions);
        view.populateAssertMenu(assertActions);
        view.populateWaitMenu(waitActions);
        view.populateCaptureMenu(captureActions);
    }

    protected void setSelected(int which, boolean select) {
        ((EditorToggleAction)actions[which]).setSelected(select);
    }

    protected void setEnabled(int which, boolean enable) {
        if (which == MI_CAPTURE_DYNAMIC) {
            for (int i = 0; i < captureActions.size(); i++) {
                javax.swing.Action action = captureActions.get(i);
                if (action != null) action.setEnabled(enable);
            }
        } else if (which == MI_WAIT_DYNAMIC) {
            for (int i = 0; i < waitActions.size(); i++) {
                javax.swing.Action action = waitActions.get(i);
                if (action != null) action.setEnabled(enable);
            }
        } else if (which == MI_ASSERT_DYNAMIC) {
            for (int i = 0; i < assertActions.size(); i++) {
                javax.swing.Action action = assertActions.get(i);
                if (action != null) action.setEnabled(enable);
            }
        } else if (which == MI_INSERT_DYNAMIC) {
            for (int i = 0; i < insertActions.size(); i++) {
                javax.swing.Action action = insertActions.get(i);
                if (action != null) action.setEnabled(enable);
            }
        } else {
            actions[which].setEnabled(enable);
        }
    }

    /**
      * Initalize the componentBrowser and listeners to the scriptTable
      */
    protected void initScriptTableAndComponentBrowser() {
        ComponentBrowser cb = new ComponentBrowser(this, finder);
        cb.setEnabled(false);
        cb.addSelectionListener(new ComponentBrowserListener() {

            @Override
            public void selectionChanged(ComponentBrowser src, Component comp, ComponentReference ref) {
                setSelectedComponent(comp, ref);
            }

            @Override
            public void propertyAction(ComponentBrowser src, Method m, Object value, boolean sample) {
                if (selectedComponent == null) return;
                addPropertyMethodCall(m, value, sample);
            }
        });
        view.setComponentBrowser(cb);
    }

    /**
     * Install a new security manager to prevent launched applications
     * from exiting the JVM.  This is only a partial solution; ideally
     * we'd like to be able to kill all the launched app's threads, or force
     * an unload of the class and reload it.
     * Should only be installed once, in the root editor context.
     */
    protected void initSecurityManager() {
        if (Boolean.getBoolean("abbot.no_security_manager")) return;

        securityManager = new EditorSecurityManager();
        try {
            oldSecurityManager = System.getSecurityManager();
            System.setSecurityManager(securityManager);
        } catch (Exception e) {
            oldSecurityManager = securityManager = null;
            Log.warn(e);
        }
    }

    /** Respond to various components. */
    @Override
    public void actionPerformed(ActionEvent ev) {
        Log.debug("Got action " + ev.getActionCommand());
        switch (ev.getID()) {
        case MI_ABOUT:
            view.showAboutBox();
            break;
        case MI_OPEN:
            openScript();
            break;
        case MI_NEW:
            newScript(false);
            break;
        case MI_DUPLICATE:
            newScript(true);
            break;
        case MI_CLEAR:
            clearScript();
            break;
        case MI_DELETE:
            deleteScript();
            break;
        case MI_SAVE:
            saveScript();
            break;
        case MI_SAVE_AS:
            saveAsScript(false);
            break;
        case MI_RENAME:
            saveAsScript(true);
            break;
        case MI_CLOSE:
            closeScript();
            break;
        case MI_EXIT:
            quit();
            break;
        case MI_CUT:
            cut();
            break;
        case MI_MOVE_UP:
            moveStepsUp();
            break;
        case MI_MOVE_DOWN:
            moveStepsDown();
            break;
        case MI_GROUP:
            groupSteps();
            break;
        case MI_RUN:
            runScript(false);
            break;
        case MI_RUNTO:
            runScript(true);
            break;
        case MI_RUNSELECTED:
            runSelectedSteps();
            break;
        case MI_EXPORT_HIERARCHY:
            exportHierarchy();
            break;
        case MI_LAUNCH:
            launch(true);
            break;
        case MI_TERMINATE:
            terminate();
            break;
        case MI_INSERT_LAUNCH:
            insertLaunch();
            break;
        case MI_INSERT_TERMINATE:
            insertTerminate();
            break;
        case MI_INSERT_CALL:
            insertCall(false);
            break;
        case MI_INSERT_SAMPLE:
            insertCall(true);
            break;
        case MI_INSERT_SEQUENCE:
            insertSequence();
            break;
        case MI_INSERT_SCRIPT:
            insertScript();
            break;
        case MI_INSERT_COMMENT:
            insertComment();
            break;
        case MI_INSERT_ANNOTATION:
            insertAnnotation();
            break;
        case MI_SELECT_TESTSUITE:
            browseTests();
            break;
        case MI_STOP_ON_FAILURE:
            stopOnFailureToggle();
            break;
        case MI_STOP_ON_ERROR:
            stopOnErrorToggle();
            break;
        case MI_FORK:
            forkedToggle();
            break;
        case MI_GETVMARGS:
            getVMArgs();
            break;
        case MI_SLOW:
            slowPlaybackToggle();
            break;
        default:
            if (ev.getSource() == view.getTestScriptSelector() && !ignoreComboBox) {
                Script script = (Script)view.getTestScriptSelector().getSelectedItem();
                if (script != testScript) setScript(script);
            } else if (ev.getSource() == view.getTestScriptDescription()) {
                if (testScript != null) {
                    testScript.setDescription(view.getTestScriptDescription().getText());
                }
            } else {
                Log.warn("Unrecognized event: " + ev.getActionCommand() + "(" + ev.getID() + ")");
            }
        }
    }

    /** Remove the selected step. */
    protected void cut() {
        int row = scriptTable.getSelectedRow();
        if (row == -1) {
            Log.warn("Unexpected cut state");
            return;
        }
        scriptModel.removeSteps(scriptTable.getSelectedSteps());
        int count = scriptTable.getRowCount();
        if (count > 0) {
            if (row >= count) row = count - 1;
            scriptTable.setRowSelectionInterval(row, row);
            scriptTable.setCursorLocation(row + 1);
        }
        enableComponents();
        setStatus("");
    }

    protected void moveStepsUp() {
        scriptTable.moveUp();
        enableComponents();
    }

    /** Move the selected step down. */
    protected void moveStepsDown() {
        scriptTable.moveDown();
        enableComponents();
    }

    /** Put the current selection into a sequence. */
    protected void groupSteps() {
        int row = scriptTable.getSelectedRow();
        Sequence seq = new Sequence(getContext(), (String)null);
        List<Step> list = scriptTable.getSelectedSteps();
        Step first = list.get(0);
        Sequence parent = scriptModel.getParent(first);
        int index = parent.indexOf(first);
        scriptModel.removeSteps(list);
        Iterator<Step> iter = list.iterator();
        Step last = parent;
        while (iter.hasNext()) {
            last = iter.next();
            seq.addStep(last);
        }
        scriptModel.insertStep(parent, seq, index);
        scriptModel.toggle(row);
        scriptTable.setRowSelectionInterval(row, scriptModel.getRowOf(last));
        enableComponents();
    }

    /** Insert a blank launch step. */
    void insertLaunch() {
        Step step =
                new Launch(getContext(),
                           Strings.get("FixClassname"),
                           "abbot.editor.ScriptEditor",
                           "main",
                           new String[] {"[]"},
                           ".",
                           true,
                           false);
        addStep(step);
    }

    /** Insert a terminate step. */
    void insertTerminate() {
        Step step = new Terminate(getContext(), (String)null);
        scriptTable.setCursorLocation(scriptTable.getRowCount());
        addStep(step);
    }

    protected void insertCall(boolean sample) {
        if (sample) {
            addStep(new Sample(getContext(),
                               (String)null,
                               Strings.get("YourClassName"),
                               Strings.get("YourMethodName"),
                               null,
                               Strings.get("YourPropertyName")));
        } else {
            addStep(new Call(getContext(),
                             (String)null,
                             Strings.get("YourClassName"),
                             Strings.get("YourMethodName"),
                             null));
        }
    }

    /** Insert a new, empty sequence. */
    protected void insertSequence() {
        addStep(new Sequence(getContext(), (String)null, null));
    }

    protected void insertComment() {
        addStep(new Comment(getContext(), ""));
    }

    protected void insertAnnotation() {
        addStep(new Annotation(getContext(), ""));
    }

    /** Insert another script as a step in this one. */
    protected void insertScript() {
        JFileChooser tChooser = getChooser();
        tChooser.setCurrentDirectory(getWorkingDirectory());
        if (tChooser.showOpenDialog(view) == JFileChooser.APPROVE_OPTION) {
            File file = tChooser.getSelectedFile();
            Script script = new Script(file.getAbsolutePath());
            try {
                script.load();
                addStep(script);
            } catch (Exception exc) {
                Log.warn(exc);
                // FIXME report errors
            }
        }
    }

    /** Returns the current test suite's directory, if available, the
        directory of the current script, if available, or the current working 
        directory.
    */
    protected File getWorkingDirectory() {
        return testSuite != null ? testSuite.getDirectory() : (testScript != null ? testScript.getDirectory()
                : new File(System.getProperty("user.dir")));
    }

    /** Return a file chooser that filters for test scripts. */
    protected JFileChooser getChooser() {
        if (chooser == null) {
            chooser = new JFileChooser();
            chooser.setFileFilter(filter);
            chooser.setCurrentDirectory(getWorkingDirectory());
        }
        return chooser;
    }

    /** Set the test case to the one corresponding to the given index. */
    public void setScript(int index) {
        if (getScripts().size() == 0) {
            setScript((Script)null);
            if (testSuite != null) setStatus(Strings.get("NoScripts"), null, WARN);

        } else {
            if (index >= getScripts().size()) index = getScripts().size() - 1;
            setScript(getScriptAt(index));
        }
    }

    public void setScript(Script script) {
        if (script == testScript && script != null) return;

        Log.debug("Setting script to '" + script + "'");
        if (script != null) {
            try {
                script.load();
            } catch (InvalidScriptException ise) {
                Log.warn(ise);
                setScript((String)null);
                showError("Invalid Script", ise.toString());
                return;
            } catch (Exception e) {
                setScript((String)null);
                Log.warn(e);
                return;
            }
        }

        if (testScript != null) {
            terminate();
        }
        testScript = script;
        scriptTable.clearSelection();
        scriptModel.setScript(script);
        if (script == null) {
            scriptTable.setCursorLocation(0);
            scriptTable.setEnabled(false);
            view.getTestScriptDescription().setText("");
            view.getTestScriptDescription().setEnabled(false);
            setStatus(Strings.get("NoScript"));
        } else {
            scriptTable.setEnabled(true);
            scriptTable.setCursorLocation(script.hasLaunch() ? 1 : 0);
            if (chooser != null) {
                chooser.setCurrentDirectory(script.getDirectory());
            }
            view.getTestScriptDescription().setText(script.getDescription());
            view.getTestScriptDescription().setEnabled(true);
            setStatus(Strings.get("EditingScript", new Object[] {testScript.getName()}));
        }
        enableComponents();

        ignoreComboBox = true;
        view.getTestScriptSelector().setSelectedItem(testScript);
        ignoreComboBox = false;
        updateTitle();
    }

    /** Update the state of all actions.  This method should be invoked after
     * any GUI state change.
     */
    protected void enableComponents() {
        boolean haveScript = testScript != null;
        boolean haveSelection = scriptTable.getSelectedRow() != -1;

        setEnabled(MI_OPEN, true);
        setEnabled(MI_STOP_ON_FAILURE, haveScript);
        setSelected(MI_STOP_ON_FAILURE, haveScript && runner.getStopOnFailure());
        setEnabled(MI_STOP_ON_ERROR, haveScript);
        setSelected(MI_STOP_ON_ERROR, haveScript && runner.getStopOnError());
        setEnabled(MI_FORK, haveScript);
        setSelected(MI_FORK, haveScript && testScript.isForked());
        setEnabled(MI_GETVMARGS, haveScript && testScript.isForked());
        setEnabled(MI_SLOW, haveScript);
        setSelected(MI_SLOW, haveScript && testScript.isSlowPlayback());
        setEnabled(MI_RUN, haveScript);
        setEnabled(MI_RUNTO, haveScript && haveSelection);
        setEnabled(MI_RUNSELECTED, haveScript && haveSelection && isAppLaunched);
        setEnabled(MI_EXPORT_HIERARCHY, haveScript && isAppLaunched);
        setEnabled(MI_LAUNCH, haveScript && testScript.hasLaunch() && !isAppLaunched);
        setEnabled(MI_TERMINATE, isAppLaunched);
        setEnabled(MI_NEW, true);
        setEnabled(MI_DUPLICATE, haveScript);
        setEnabled(MI_SAVE, haveScript);
        setEnabled(MI_SAVE_AS, haveScript);
        setEnabled(MI_RENAME, haveScript);
        setEnabled(MI_DELETE, haveScript);
        setEnabled(MI_CLOSE, haveScript);

        setEnabled(MI_CUT, haveScript && haveSelection);
        setEnabled(MI_MOVE_UP, haveScript && haveSelection && scriptTable.canMoveUp());
        setEnabled(MI_MOVE_DOWN, haveScript && haveSelection && scriptTable.canMoveDown());
        setEnabled(MI_GROUP, haveScript && haveSelection);
        setEnabled(MI_CLEAR, haveScript);

        setEnabled(MI_INSERT_LAUNCH, haveScript && !testScript.hasLaunch());
        setEnabled(MI_INSERT_TERMINATE, haveScript && !testScript.hasTerminate());
        setEnabled(MI_INSERT_SCRIPT, haveScript);
        setEnabled(MI_INSERT_CALL, haveScript);
        setEnabled(MI_INSERT_SAMPLE, haveScript);
        setEnabled(MI_INSERT_SEQUENCE, haveScript);
        setEnabled(MI_INSERT_COMMENT, haveScript);
        setEnabled(MI_INSERT_ANNOTATION, haveScript);
        setEnabled(MI_INSERT_DYNAMIC, haveScript);
        setEnabled(MI_ASSERT_DYNAMIC, haveScript);
        setEnabled(MI_WAIT_DYNAMIC, haveScript);
        setEnabled(MI_CAPTURE_DYNAMIC, haveScript);

        view.getComponentBrowser().setEnabled(!isScriptRunning);
    }

    /** Set the current test script.  */
    public void setScript(String filename) {
        Script script = filename != null ? new Script(filename) : null;
        setScript(script);
    }

    /** Indicate the component and/or reference currently in use. */
    protected void setSelectedComponent(Component c, ComponentReference ref) {

        if (c == selectedComponent && ref == selectedReference) return;

        boolean update = c != selectedComponent;
        selectedComponent = c;
        selectedReference = ref;
        if (ref != null) {
            String msg =
                    Strings.get(c == null ? "ComponentReferenceX" : "ComponentReference", new Object[] {ref.getID()});
            setStatus(msg);
        } else if (c != null) {
            setStatus(Strings.get("UnreferencedComponent"));
        } else {
            setStatus(Strings.get("NoComponent"));
        }
        if (update) {
            updateDynamicActions();
        }
    }

    /** Sets the currently selected test suite, updating all gui components
        appropriately.  */
    public void setTestSuite(String suiteClassname) {
        // FIXME maybe populate the script popup with everything we can find
        // if null
        // FIXME include the current script in the collection owned by the
        // test suite
        Log.debug("Setting test suite to " + suiteClassname);
        testSuite = null;
        testScriptList = null;
        if (suiteClassname != null) {
            try {
                // FIXME use a dynamic class loader so we can reload after
                // changes to the suite/fixture class. 
                Class cls = Class.forName(suiteClassname);
                if (!ScriptFixture.class.isAssignableFrom(cls) && !ScriptTestSuite.class.isAssignableFrom(cls)) {
                    showWarning("Class " + cls.getName() + " must be derived from ScriptTestSuite");
                } else {
                    testClass = cls;
                    Method suiteMethod = null;
                    testSuite = null;
                    try {
                        suiteMethod = testClass.getMethod("suite", new Class[0]);
                        Object tObject = suiteMethod.invoke(null, new Object[0]);
                        if (tObject instanceof ScriptTestSuite) {
                            testSuite = (ScriptTestSuite)tObject;
                        } else {
                            testSuite = null;
                        }
                    } catch (NoSuchMethodException nsm) {
                        showError(nsm.toString());
                        testSuite = null;
                    } catch (InvocationTargetException ite) {
                        showError(ite.toString());
                    } catch (IllegalAccessException iae) {
                        showError(iae.toString());
                    }
                }
            } catch (ClassNotFoundException e) {
                showWarning("'"
                            + suiteClassname
                            + "' is neither a script nor a test suite."
                            + " No suite will be loaded.");
            }
        }
        if (testSuite == null) {
            view.getCurrentTestSuiteLabel().setText(Strings.get("NoSuite"));
            view.getTestScriptSelector().setSelectedIndex(-1);
            view.getTestScriptSelector().setModel(new DefaultComboBoxModel());
            view.getTestScriptSelector().setEnabled(false);
        } else {
            view.getTestScriptSelector().setEnabled(true);
            view.getCurrentTestSuiteLabel().setText(testSuite.toString());
            Object oldSelection = view.getTestScriptSelector().getSelectedItem();
            ignoreComboBox = true;
            view.getTestScriptSelector().setEnabled(true);
            // Workaround for indexing bug on OSX
            view.getTestScriptSelector().setSelectedItem(null);
            List<String> list = getScripts();
            DefaultComboBoxModel model = new DefaultComboBoxModel(list.toArray(new Object[list.size()]));
            view.getTestScriptSelector().setModel(model);
            // If the test suite didn't actually change, then keep the old
            // selection. 
            if (getScripts().contains(oldSelection)) view.getTestScriptSelector().setSelectedItem(oldSelection);
            ignoreComboBox = false;
        }
    }

    /** Set the frame title to the default. */
    protected void updateTitle() {
        String title =
                Strings.get("ScriptEditor.title", new Object[] {testScript != null
                        ? (" (" + testScript.getName() + ")") : ""});
        view.setTitle(title);
    }

    /** Pull up a dialog with all available test suites.  */
    protected void browseTests() {
        //        TestCollector collector = new ScriptTestCollector();
        //        TestSelector selector = new TestSelector(view, collector);
        //        String className;
        //        if (selector.isEmpty()) {
        //            showMessage(Strings.get("NoTestCaseFound"), Strings.get("NoTestCaseFound"));
        //            // Don't change anything
        //        } else {
        //            selector.show();
        //            className = selector.getSelectedItem();
        //            if (className != null) {
        //                terminate();
        //                boolean none = className.equals(TestSelector.TEST_NONE);
        //                setTestSuite(none ? null : className);
        //                setScript(0);
        //                if (none) {
        //                    setStatus(Strings.get("EditingScripts"));
        //                }
        //            }
        //        }
    }

    /** Return true if it's ok to exit. */
    protected boolean checkSaveBeforeClose() {
        // query save/cancel/exit
        if (testScript != null && testScript.isDirty()) {
            int opt = showConfirmation(Strings.get("ScriptModified"), JOptionPane.YES_NO_CANCEL_OPTION);
            if (opt == JOptionPane.CANCEL_OPTION || opt == JOptionPane.CLOSED_OPTION) {
                return false;
            } else if (opt == JOptionPane.YES_OPTION) {
                saveScript();
            }
        }
        return true;
    }

    protected void closeScript() {
        if (!checkSaveBeforeClose()) return;
        setScript((Script)null);
    }

    /** Quit the application. */
    protected void quit() {
        if (!checkSaveBeforeClose()) return;

        Log.debug("editor quit" + (isRootEditor ? " (root)" : ""));
        dispose();
        if (isRootEditor) {
            rootIsExiting = true;
            System.exit(0);
        }
    }

    /** Set the contents of the status message. */
    public void setStatus(String msg) {
        setStatus(msg, null, INFO);
    }

    /** Set the contents of the status message to the given exception. */
    protected String getStackTrace(Throwable thr) {
        StringWriter writer = new StringWriter();
        thr.printStackTrace(new PrintWriter(writer));
        return writer.toString();
    }

    /** Set the contents of the status message. */
    public void setStatus(String msg, String extended, int type) {
        String text = Strings.get(statusFormat[type], new Object[] {msg});
        view.setStatus(text, extended, statusColor[type]);
        // Save all messages to the log
        Log.log(text);
    }

    protected void setStatusForStep(Step step) {
        if (step == null) {
            setStatus("");
            return;
        }

        Throwable error = runner.getError(step);
        boolean fromScript = step == testScript;
        String msg = error != null ? error.toString() : null;
        String inStep = Strings.get("InStep", new Object[] {step});

        /**
         * Abbot Ext
         * Wenn wir das Abbot Script nicht ermitteln koennen soll
         * dies nur im Editor angezeigt werden aber nicht zu einer 
         * "wild-herumfliegenden" Exception fuehren.
         */
        File tempFile = null;
        int tempLine = 0;
        boolean cannotResolve = false;
        try {
            tempFile = scriptModel.getFile(step);
            tempLine = scriptModel.getLine(step);
        } catch (IllegalArgumentException e) {
            cannotResolve = true;
            Log.warn("Cannot resolve step / scriptfilename!", e);
        }

        String where = null;
        if (!cannotResolve) {
            where = Strings.get("StepAt", new Object[] {tempFile, new Integer(tempLine)});
        } else {
            where = "Cannot resolve scriptfilename: " + tempFile.getAbsolutePath();
        }

        /** Abbot Ext END */

        String extended = null;
        int type = INFO;
        if (error != null) {
            Log.log(error);
            boolean isFailure = (error instanceof AssertionFailedError);
            type = isFailure ? FAILURE : ERROR;
            extended = getStackTrace(error);
            // If we're not stopping on failure, don't mention it
            // specifically
            if (fromScript) {
                if ((isFailure && !runner.getStopOnFailure()) || (!isFailure && !runner.getStopOnError())) {
                    msg = Strings.get(isFailure ? "ScriptFailure" : "ScriptError");
                } else {
                    // Otherwise ignore messages from the script itself
                    return;
                }
            } else {
                extended = inStep + "\n" + where + "\n" + extended;
            }
        } else if (fromScript) {
            msg = Strings.get("ScriptSuccess");
        }
        // If nothing interesting happened, leave the status alone
        if (msg != null) setStatus(msg, extended, type);
    }

    /** Return a ComponentReference corresponding to the currently selected
        Component or ComponentReference, creating one if necessary.
    */
    protected String getSelectedComponentID() {
        String id = null;
        if (selectedReference != null) {
            id = selectedReference.getID();
        } else if (selectedComponent != null) {
            ComponentReference ref = addComponent(selectedComponent);
            id = ref.getID();
            setStatus(Strings.get("ComponentReference", new Object[] {id}));
        }
        return id;
    }

    /** Add either an Action or an Assert method provided by the given
        Tester. */
    protected void addTesterCall(Method method, ComponentTester tester, boolean wait) {
        boolean invert = invertAssertions;
        Class[] params = method.getParameterTypes();
        String id = getSelectedComponentID();
        Class componentClass = selectedComponent != null ? selectedComponent.getClass() : null;
        boolean componentArg0 = params.length > 0 && Component.class.isAssignableFrom(params[0]);

        // FIXME pretty up this input interface; one field per arg?
        String argString =
                showInputDialog(Strings.get("IdentifyArguments"), getTesterMethodArgsDesc(method), componentArg0 ? id
                        : null);
        if (argString == null) return;

        String[] args = ArgumentParser.parseArgumentList(argString);
        try {
            insertTesterCall(tester, method, componentClass, id, args, wait, invert);
        } catch (IllegalArgumentException iae) {
            Log.warn(iae);
        } catch (NoSuchReferenceException nsr) {
            Log.warn(nsr);
        }
    }

    /** Invoked after the user has selected a component and a property for
     * it.
     */
    protected void addPropertyMethodCall(Method method, Object value, boolean sample) {
        String id = getSelectedComponentID();
        String methodName = method.getName();
        String[] args = ComponentTester.class.isAssignableFrom(method.getDeclaringClass()) ? new String[] {id} : null;
        method.getDeclaringClass().getName();
        if (sample) {
            selectedComponent.getClass();
            Sample step = new Sample(getContext(), null, methodName, args, id, Strings.get("YourPropertyName"));
            addStep(step);
        } else {
            String expectedValue = value != null ? value.toString() : "(null)";
            boolean invert = invertAssertions;
            boolean wait = waitAssertions;
            Assert step = new Assert(getContext(), null, methodName, args, id, expectedValue, invert);
            step.setWait(wait);
            addStep(step);
        }
    }

    /** Returns null if not found. */
    public String getComponentID(Component comp) {
        ComponentReference ref = getComponentReference(comp);
        return ref != null ? ref.getID() : null;
    }

    /** Insert a new step at the current cursor location.  */
    protected void addStep(Step step) {
        Sequence parent = scriptTable.getCursorParent();
        int index = scriptTable.getCursorParentIndex();
        scriptModel.insertStep(parent, step, index);
        int row = scriptModel.getRowOf(step);
        scriptTable.setRowSelectionInterval(row, row);
        scriptTable.setCursorLocation(row + 1);
        enableComponents();
    }

    /** Create a new script. */
    protected void newScript(boolean copyFixture) {
        if (!checkSaveBeforeClose()) return;
        Log.debug("Creating a new script");
        File dir = getWorkingDirectory();
        JFileChooser tChooser = getChooser();
        tChooser.setCurrentDirectory(dir);
        tChooser.setSelectedFile(new File(dir, Strings.get("UntitledXML")));
        if (tChooser.showSaveDialog(view) == JFileChooser.APPROVE_OPTION) {
            File file = tChooser.getSelectedFile();
            if (!file.exists() || file.isFile()) {
                newScript(file, copyFixture);
            } else {
                Log.warn("Selected file is a directory");
            }
        }
    }

    /** Create a new script at the given filename, or open it if it already
     * exists.  Optionally copies the fixture from the current script.
     */
    void newScript(File file, boolean copyFixture) {
        try {
            if (file.createNewFile()) {
                Script srcFixture = testScript;
                setScript(file.getAbsolutePath());
                if (!copyFixture || srcFixture == null) {
                    insertLaunch();
                    insertTerminate();
                } else {
                    copyFixture(srcFixture);
                }
            } else {
                // TODO: Maybe show a warning that it exists?
                setScript(file.getAbsolutePath());
            }
            setStatus(Strings
                    .get(copyFixture ? "FixtureDuplicated" : "NewScriptCreated", new Object[] {file.getName()}));
        } catch (IOException io) {
            showError("File Error", io.toString());
        }
    }

    /** Copy the fixture from the given script into the current one. */
    protected void copyFixture(Script src) {
        Step first = src.getStep(0);
        Step last = src.getStep(src.size() - 1);
        if (first instanceof Launch) {
            setStatus(Strings.get("AddingLaunch"));
            addStep(first);
        }
        if (src.size() > 1 && (src.getStep(1) instanceof Assert)) {
            Assert wait = (Assert)src.getStep(1);
            if (wait.isWait() && wait.getMethodName().equals("assertFrameShowing")) {
                setStatus(Strings.get("AddingWait"));
                addStep(wait);
            }
        }
        if (last instanceof Terminate) {
            setStatus(Strings.get("AddingTerminate"));
            addStep(last);
        }
    }

    /** Launch the GUI under test. */
    protected void launch(boolean terminateRecorder) {
        if (testScript == null) {
            Log.warn("null testScript");
            return;
        }

        // Clean up any extant windows
        terminate(terminateRecorder);
        ignoreStepEvents = true;

        setStatus(Strings.get("Launching"));
        // FIXME time out and flag an error if the launch never returns
        // (even if threaded, it should return at some point)
        runSteps(testScript.getLaunchStep(), true, Strings.get("LaunchingDone"), new Runnable() {

            @Override
            public void run() {
                // JAVA 7: Wir vermuten ein Problem bei der Rueckmeldung und setzen hier nun true
                ignoreStepEvents = false;
            }
        });
    }

    protected void terminate() {
        terminate(true);
    }

    /** Do everything we can to dispose of the application under test. */
    protected void terminate(boolean terminateRecorder) {
        if (terminateRecorder && recorder != null) {
            // Assume we want to keep the results
            stopRecording(false);
        }
        if (testScript != null) {
            scriptTable.clearSelection();
            runner.terminate();
            if (appGroup != null) {
                appGroup = null;
            }
        }
    }

    protected void setAppLaunched(boolean state) {
        isAppLaunched = state;
        setEnabled(MI_LAUNCH, !state && testScript.hasLaunch());
        setEnabled(MI_TERMINATE, state);
    }

    protected void openScript() {
        JFileChooser tChooser = getChooser();
        tChooser.setCurrentDirectory(getWorkingDirectory());
        if (testScript != null) {
            tChooser.setSelectedFile(testScript.getFile());
        }
        if (tChooser.showOpenDialog(view) == JFileChooser.APPROVE_OPTION) {
            File file = tChooser.getSelectedFile();
            setScript(file.getAbsolutePath());
        }
    }

    protected void stopOnFailureToggle() {
        if (testScript != null) {
            runner.setStopOnFailure(!runner.getStopOnFailure());
        }
    }

    protected void stopOnErrorToggle() {
        if (testScript != null) {
            runner.setStopOnError(!runner.getStopOnError());
        }
    }

    protected void forkedToggle() {
        if (testScript != null) {
            testScript.setForked(!testScript.isForked());
            setEnabled(MI_GETVMARGS, testScript.isForked());
        }
    }

    protected void getVMArgs() {
        String args =
                showInputDialog(Strings.get("GetVMArgs.title"), Strings.get("GetVMArgs.msg"), testScript.getVMArgs());
        if (args != null) {
            testScript.setVMArgs(args);
        }
    }

    protected void slowPlaybackToggle() {
        if (testScript != null) {
            testScript.setSlowPlayback(!testScript.isSlowPlayback());
        }
    }

    protected void runScript(boolean toSelection) {
        if (testScript == null) {
            Log.warn("null testScript");
            return;
        }
        Log.debug("Running test case " + testScript);
        if (toSelection) {
            stopStep = scriptTable.getSelectedStep();
        }
        // Don't need to terminate here if the script is forked
        if (!testScript.isForked()) terminate();

        setStatus(Strings.get("InvokingTest"));
        Runnable completion = new Runnable() {

            @Override
            public void run() {
                // When the script finishes, bring the main
                // app forward.
                view.toFront();
            }
        };
        runSteps(testScript, false, Strings.get("editor.actions.run_script.finish"), completion);
    }

    protected void exportHierarchy() {
        JFileChooser tChooser = getChooser();
        if (tChooser.showSaveDialog(view) == JFileChooser.APPROVE_OPTION) {
            setStatus(Strings.get("editor.actions.export_hierarchy.start"));
            final File file = tChooser.getSelectedFile();
            new Thread("Exporting hierarchy") {

                @Override
                public void run() {
                    Window[] windows = finder.getRootWindows();
                    HierarchyWriter hw = new HierarchyWriter();
                    try {
                        FileWriter writer = new FileWriter(file);
                        hw.writeHierarchy(writer, windows);
                    } catch (IOException io) {
                        showError(Strings.get("SaveFailed.title"), io.toString());
                    }
                    setStatus(Strings.get("editor.actions.export_hierarchy.finish"));
                }
            }.start();
        }
    }

    protected void runSelectedSteps() {
        if (testScript == null || scriptTable.getSelectedSteps() == null || !isAppLaunched) {
            Log.warn("inconsistent program state");
            return;
        }

        Sequence steps = new Sequence(getContext(), null, scriptTable.getSelectedSteps());
        int[] selection = scriptTable.getSelectedRows();
        final int row0 = selection[0];
        final int row1 = selection[selection.length - 1];
        setStatus(Strings.get("editor.actions.run_selected.start"));
        /* abbot_ext_begin */
        /* view.hide(); */
        /* abbot_ext_end */
        runSteps(steps, false, Strings.get("editor.actions.run_selected.finish"), new Runnable() {

            @Override
            public void run() {
                scriptTable.setRowSelectionInterval(row0, row1);
                view.setVisible(true);
            }
        });
    }

    /** Invoke the given test script. */
    @SuppressWarnings("unchecked")
    protected void runSteps(final Step which, final boolean terminateOnError, final String completionMessage,
            final Runnable onCompletion) {

        final boolean launch = which instanceof Launch;
        setAppLaunched(true);
        lastLaunchTime = System.currentTimeMillis();
        final List savedState = AWT.disableHierarchy(view);
        Runnable action = new Runnable() {

            @Override
            public void run() {
                try {
                    if (launch) {
                        runner.launch(testScript);
                    } else {
                        runner.run(which);
                    }
                    if (completionMessage != null) setStatus(completionMessage);
                } catch (Throwable thr) {
                    if (terminateOnError) terminate();
                }
                SwingUtilities.invokeLater(new Runnable() {

                    @Override
                    public void run() {
                        AWT.reenableHierarchy(savedState);
                        isScriptRunning = false;
                        enableComponents();
                        if (onCompletion != null) {
                            onCompletion.run();
                        }
                    }
                });
            }
        };
        appGroup = new ThreadGroup("Application Under Test " + this) {

            @Override
            public void uncaughtException(Thread t, Throwable thrown) {
                Log.warn("Application thread exception not caught: " + t);
                Log.warn(thrown);
            }
        };
        Thread launcher = new Thread(appGroup, action, "Script runner");
        launcher.setDaemon(true);
        view.getComponentBrowser().setEnabled(false);
        view.setEditor(null);
        isScriptRunning = true;
        launcher.start();
    }

    /** Remove all contents from the current script. */
    protected void clearScript() {
        if (testScript == null) {
            Log.warn("null testScript");
            return;
        }
        if (showConfirmation(Strings.get("editor.confirm.clear_script")) == JOptionPane.YES_OPTION) {
            scriptTable.clearSelection();
            scriptTable.setCursorLocation(0);
            testScript.clear();
            scriptModel.setScript(testScript);
        }
    }

    /** Delete the currently selected script/test case. */
    protected void deleteScript() {
        if (testScript == null) {
            Log.warn("null testScript");
            return;
        }
        if (showConfirmation(Strings.get("editor.confirm.delete_script")) == JOptionPane.YES_OPTION) {
            File file = testScript.getFile();
            int index = view.getTestScriptSelector().getSelectedIndex();
            file.delete();
            setTestSuite(testClass.getName());
            setScript(index);
        }
    }

    /** Change the file backing the current script/test case, effectively
     * changing its name.
     */
    protected void saveAsScript(boolean rename) {
        if (testScript == null) {
            Log.warn("null testScript");
            return;
        }
        File oldFile = testScript.getFile();
        JFileChooser tChooser = getChooser();
        tChooser.setCurrentDirectory(getWorkingDirectory());
        // FIXME make sure it falls within the test suite's script set?
        //chooser.setFileFilter(testScript.getFileFilter());
        if (tChooser.showSaveDialog(view) == JFileChooser.APPROVE_OPTION) {
            File newFile = tChooser.getSelectedFile();
            if (rename) {
                if (!oldFile.renameTo(newFile)) {
                    // FIXME show a warning
                    return;
                }
            }
            testScript.setFile(newFile);
            saveScript();
            updateTitle();

            if (testSuite != null && testSuite.accept(newFile)) {
                setTestSuite(testClass.getName());
            } else {
                setTestSuite(null);
            }

            if (rename) {
                setStatus(Strings.get("ScriptRename", new Object[] {newFile.getName()}));
            } else {
                setStatus(Strings.get("ScriptSaved", new Object[] {newFile.getName()}));
            }
            // Combo box doesn't know that the script has changed its
            // toString 
            view.getTestScriptSelector().repaint();
        }
    }

    /** Save the current script/test case state to disk. */
    protected void saveScript() {
        if (testScript == null) {
            Log.warn("null testScript");
            return;
        }
        File file = testScript.getFile();
        File parent = file.getParentFile();
        boolean canWrite = (!file.exists() && parent.canWrite()) || (file.exists() && file.canWrite());
        if (!canWrite) {
            String msg = Strings.get("NoFilePermission", new Object[] {file.toString()});
            showError(Strings.get("SaveFailed.title"), msg);
        } else {
            try {
                setStatus(Strings.get("Saving", new Object[] {file}));
                testScript.save();
                saveNestedScripts(testScript);
                setStatus(Strings.get("Saved", new Object[] {file}));
            } catch (IOException exc) {
                showError(Strings.get("SaveFailed.title"), exc.toString());
            }
        }
    }

    protected void saveNestedScripts(Sequence seq) throws IOException {
        Iterator<Step> iter = seq.steps().iterator();
        while (iter.hasNext()) {
            Step step = iter.next();
            if (step instanceof Script) {
                /* abbot_ext_begin */
                ((Script)step).save();
                saveNestedScripts((Script)step);
                /* abbot_ext_end */
            } else if (step instanceof Sequence) saveNestedScripts((Sequence)step);
        }
    }

    protected EventNormalizer normalizer = new EventNormalizer();

    /** Start listening to GUI events. */
    public void startListening() {
        long mask = fixtureEventMask;
        normalizer.startListening(new SingleThreadedEventListener() {

            @Override
            protected void processEvent(AWTEvent event) {
                ScriptEditor.this.processEvent(event);
            }
        }, mask);
        view.getComponentBrowser().setEnabled(true);
    }

    /** Stop listening to GUI events. */
    protected void stopListening() {
        normalizer.stopListening();
    }

    /** Return the number of windows that are showing. */
    protected int getShowingWindowCount() {
        Window[] windows = finder.getWindows();
        int count = 0;
        for (int i = 0; i < windows.length; i++) {
            if (windows[i].isShowing()) ++count;
        }
        return count;
    }

    protected int DONT_CARE = -1;

    protected boolean isKeyPress(AWTEvent event, int code, int modifiers) {
        return event.getID() == KeyEvent.KEY_PRESSED
               && ((KeyEvent)event).getKeyCode() == code
               && (((KeyEvent)event).getModifiers() == modifiers || modifiers == DONT_CARE);
    }

    protected boolean isKeyRelease(AWTEvent event, int code, int modifiers) {
        return event.getID() == KeyEvent.KEY_RELEASED
               && ((KeyEvent)event).getKeyCode() == code
               && (((KeyEvent)event).getModifiers() == modifiers || modifiers == DONT_CARE);
    }

    /** The editor does many things with the event stream, including logging
     * events, passing them off to the recorder, and updating its internal
     * state.
     */
    protected void processEvent(AWTEvent event) {
        int id = event.getID();

        Object src = event.getSource();
        // Allow only component events and AWT menu actions
        boolean isComponent = src instanceof Component;
        boolean isFiltered = isComponent && finder.isFiltered((Component)src);
        // Keep a log of all events we see on non-filtered components
        if (isRootEditor) {
            if (logAllEvents || (!isFiltered && !ignoreEvents)) {
                // abbot_ext_begin 
                // Log-Ausgaben heraus genommen,  da Robot.toString(event) lange dauern kann
                //                 Log.log("ED: " + Robot.toString(event) + " (" + Thread.currentThread() + ")");
                //abbot_ext_end
            }
        }
        if (!isComponent && !(src instanceof MenuComponent)) {
            Log.warn("Source not a Component or MenuComponent: " + event);
            return;
        }
        // If the script is running (or even being launched), the code
        // under test may do things that should really be done on the event
        // dispatch thread (initial component show and such).  
        // If this is the case, defer mucking about with AWT until the code
        // under test has stabilized.
        if (isScriptRunning) {
            return;
        }

        boolean editorActivated = event.getID() == WindowEvent.WINDOW_ACTIVATED && src == view;
        boolean appGone =
                isAppLaunched
                        && getShowingWindowCount() == 0
                        && (appGroup != null && appGroup.activeCount() == 0)
                        && System.currentTimeMillis() - lastLaunchTime > 7500;
        if (appGone) Log.debug("Code under test no longer running");

        Component ultimateComponent = state.getUltimateMouseComponent();
        // Make sure we filter any transient windows generated by the
        // script editor's frame.  This avoids some of the hierarchy event
        // NPEs present on pre-1.4 VMs.
        if (id == WindowEvent.WINDOW_OPENED && ((WindowEvent)event).getWindow().getParent() == view) {
            finder.filterComponent(((WindowEvent)event).getWindow());
            view.getComponentBrowser().refresh();
        } else if (isKeyPress(event, KeyEvent.VK_F2, KeyEvent.SHIFT_MASK) || editorActivated || appGone) {
            Log.debug("stop recording trigger");
            if (recording) {
                stopRecording(false);
                justStoppedRecording = true;
            } else {
                justStoppedRecording = false;
            }
        }
        // Start recording all events on alt+shift+F2
        else if (isKeyRelease(event, KeyEvent.VK_F2, KeyEvent.SHIFT_MASK | KeyEvent.ALT_MASK)) {
            Log.debug("start recording trigger");
            if (!isFiltered && !recording && !justStoppedRecording) {
                Log.debug("Start recording events (+motion)");
                startRecording(recorders[1]);
            }
        }
        // Start recording on shift+F2
        else if (isKeyRelease(event, KeyEvent.VK_F2, KeyEvent.SHIFT_MASK)) {
            Log.debug("start recording trigger");
            if (!isFiltered && !recording && !justStoppedRecording) {
                Log.debug("Start recording events");
                startRecording(recorders[0]);
            }
        } else if (capturingImage) {
            // Cancel an image capture on ESC or editor activation
            if (isKeyRelease(event, KeyEvent.VK_ESCAPE, 0) || editorActivated) {
                Log.debug("stop image capture command");
                if (captureComponent != null) highlightComponent(captureComponent, false);
                if (recorder != null) {
                    if (editorActivated)
                        stopRecording(false);
                    else
                        recording = true;
                }
                setStatus("Image capture canceled");
                captureComponent = innermostCaptureComponent = null;
                capturingImage = false;
            } else if (captureComponent != null && isKeyPress(event, KeyEvent.VK_UP, 0) && !(src instanceof Window)) {
                Log.debug("image capture move up");
                Component parent = finder.getComponentParent(captureComponent);
                if (parent != null) {
                    Log.debug("Changing from " + Robot.toString(captureComponent) + " to " + Robot.toString(parent));
                    highlightComponent(captureComponent, false);
                    highlightComponent(captureComponent = parent, true);
                }
            } else if (captureComponent != null && isKeyPress(event, KeyEvent.VK_DOWN, 0) && !(src instanceof Window)) {
                Log.debug("image capture move down");
                if (captureComponent instanceof Container) {
                    Component[] subs = finder.getComponents((Container)captureComponent);
                    for (int i = 0; i < subs.length; i++) {
                        if (SwingUtilities.isDescendingFrom(innermostCaptureComponent, subs[i])) {
                            Log.debug("Changing from "
                                      + Robot.toString(captureComponent)
                                      + " to "
                                      + Robot.toString(subs[i]));
                            highlightComponent(captureComponent, false);
                            highlightComponent(captureComponent = subs[i], true);
                            break;
                        }
                    }
                }
                setStatus("Image capture target is " + Robot.toString(captureComponent));
            } else if (isKeyRelease(event, KeyEvent.VK_F3, KeyEvent.SHIFT_MASK)
                       && !isFiltered
                       && testScript != null
                       && ultimateComponent != null) {
                Log.debug("image capture snapshot");
                setStatus("Capturing image...");
                view.repaint();
                highlightComponent(captureComponent, false);
                // Must wait for the highlight to go away
                SwingUtilities.invokeLater(new Runnable() {

                    @Override
                    public void run() {
                        Step step = captureImage(captureComponent);
                        if (step != null) {
                            // If we capture while recording, add it to the
                            // recorder's stream.  Otherwise, add it directly.
                            if (recorder != null) {
                                recorder.insertStep(step);
                            } else {
                                addStep(step);
                            }
                        }
                        setStatus("Capturing image...done");
                        captureComponent = innermostCaptureComponent = null;
                        capturingImage = false;
                    }
                });
            }
        } else if (isKeyRelease(event, KeyEvent.VK_F3, KeyEvent.SHIFT_MASK)
                   && !isFiltered
                   && testScript != null
                   && ultimateComponent != null) {
            Log.debug("image capture locate");
            recording = false;
            capturingImage = true;
            captureComponent = ultimateComponent;
            innermostCaptureComponent = captureComponent;
            if (captureComponent != null) {
                highlightComponent(captureComponent, true);
            }
            setStatus("Image capture target is " + Robot.toString(captureComponent));
        } else if (recorder != null && recording && !isFiltered) {
            Log.debug("recorder process event");
            try {
                recorder.recordEvent(event);
            } catch (RecordingFailedException e) {
                // Stop recording, but keep what we've got so far
                stopRecording(false);
                showWarning(Strings.get("editor.recording.failure"));
                setStatus(e.getReason().getMessage(), getStackTrace(e.getReason()), ERROR);
            }
        }

        if (!finder.isFiltered(ultimateComponent)) {
            boolean keySelect = isKeyPress(event, KeyEvent.VK_F1, KeyEvent.SHIFT_MASK);
            boolean mouseSelect =
                    event.getID() == MouseEvent.MOUSE_PRESSED
                            && Robot.isTertiaryButton(((MouseEvent)event).getModifiers());
            boolean makeReference = isKeyPress(event, KeyEvent.VK_F1, KeyEvent.SHIFT_MASK | KeyEvent.ALT_MASK);

            if (keySelect || mouseSelect || makeReference) {
                Component selected =
                        event instanceof MouseEvent ? InputState.getComponentAt((Component)event.getSource(),
                                                                                ((MouseEvent)event).getPoint())
                                : ultimateComponent;

                // We usually want the combo box itself, not its LAF button
                if (selected != null && (selected.getParent() instanceof JComboBox)) selected = selected.getParent();
                if (makeReference && getContext() != null) {
                    getContext().addComponent(selected);
                }
                view.getComponentBrowser().setSelectedComponent(selected);
            }
        }

        // Adjust the state of the assert/sample options
        if (isKeyPress(event, KC_INVERT, DONT_CARE)) {
            invertAssertions = true;
            view.setAssertOptions(waitAssertions, invertAssertions);
        } else if (isKeyRelease(event, KC_INVERT, DONT_CARE)) {
            invertAssertions = false;
            view.setAssertOptions(waitAssertions, invertAssertions);
        } else if (isKeyPress(event, KC_WAIT, DONT_CARE)) {
            waitAssertions = true;
            view.setAssertOptions(waitAssertions, invertAssertions);
        } else if (isKeyRelease(event, KC_WAIT, DONT_CARE)) {
            waitAssertions = false;
            view.setAssertOptions(waitAssertions, invertAssertions);
        }
    }

    /** Return a List of script filenames in the current suite. */
    protected List<String> getScripts() {
        if (testScriptList == null) {
            testScriptList = getScripts(testSuite);
        }
        return testScriptList;
    }

    /** Return a List of script filenames contained in the given Test. */
    protected List<String> getScripts(junit.framework.Test node) {
        ArrayList<String> names = new ArrayList<String>();
        if (node == null) {} else if (node instanceof ScriptFixture) {
            names.add(((ScriptFixture)node).getName());
        } else if (node instanceof junit.framework.TestSuite) {
            Enumeration<Test> tenum = ((junit.framework.TestSuite)node).tests();
            while (tenum.hasMoreElements()) {
                junit.framework.Test test = tenum.nextElement();
                names.addAll(getScripts(test));
            }
        } else if (node instanceof junit.extensions.TestDecorator) {
            junit.framework.Test base = ((junit.extensions.TestDecorator)node).getTest();
            names.addAll(getScripts(base));
        }
        //Log.debug("Test scripts under " + node + ": " + names.size());
        return names;
    }

    /** Returns the test case at the given index.  */
    protected Script getScriptAt(int index) {
        List<String> filenames = getScripts();
        if (index >= filenames.size()) index = filenames.size() - 1;
        return new Script(filenames.get(index));
    }

    /** Create a new step and insert it at the cursor. */
    protected void insertTesterCall(ComponentTester tester, Method method, Class componentClass, String id,
            String[] argList, boolean wait, boolean invert) throws NoSuchReferenceException {
        String expectedResult = "true";
        String methodName = method.getName();

        if (methodName.startsWith("assert")) {
            Assert step;
            if (id == null) {
                // Built-in ComponentTester assertion
                step = new Assert(getContext(), null, methodName, argList, expectedResult, invert);
            } else {
                // Property method on a component
                ComponentReference ref = getComponentReference(id);
                if (ref == null) throw new NoSuchReferenceException(id);
                step =
                        new Assert(getContext(),
                                   null,
                                   methodName,
                                   argList,
                                   method.getDeclaringClass(),
                                   expectedResult,
                                   invert);
            }
            step.setWait(wait);
            addStep(step);
        } else if (methodName.startsWith("action")) {
            if (id == null) {
                // non-component action
                addStep(new Action(getContext(), null, methodName, argList));
            } else {
                ComponentReference ref = getComponentReference(id);
                if (ref == null) throw new NoSuchReferenceException(id);
                addStep(new Action(getContext(), null, methodName, argList, method.getDeclaringClass()));
            }
        } else {
            // It's an tester-provided property method
            ComponentReference ref = getComponentReference(id);
            if (ref == null) throw new NoSuchReferenceException(id);
            addStep(new Assert(getContext(),
                               null,
                               methodName,
                               argList,
                               tester.getTestedClass(componentClass),
                               expectedResult,
                               invert));
        }
    }

    /** Update the UI to reflect the current state of the script's
     * execution.
     */
    public void reflectScriptExecutionState(StepEvent ev) {
        Step step = ev.getStep();
        String cmd = ev.getType();
        Log.debug("Got step event " + ev);
        if (cmd.equals(StepEvent.STEP_START)) {
            if (ev.getStep() == stopStep) {
                runner.stop();
                stopStep = null;
            }
            if (ev.getStep() != testScript) {
                final int row = scriptModel.getRowOf(step);
                if (row == -1) {
                    // Step not visible, ignore
                } else {
                    SwingUtilities.invokeLater(new Runnable() {

                        @Override
                        public void run() {
                            /* Abbot_ext_begin */
                            //Change selection hinzugenommen
                            //Au�erdem sollte ein refresh-Problem nicht eine fehlerhaften Skriptausf�hrung zur Folge haben
                            scriptTable.setRowSelectionInterval(row, row);
                            scriptTable.setCursorLocation(row + 1);

                            /** 1.3 */
                            Rectangle rect = scriptTable.getCellRect(row, 0, true);
                            scriptTable.scrollRectToVisible(rect);

                            // scriptTable.changeSelection(row, 0, false, false);
                            /*Abbot_ext_end */
                        }
                    });
                }
                int i = testScript.indexOf(step);
                if (i != -1) {
                    setStatus(Strings.get("RunningStep",
                                          new Object[] {String.valueOf(i + 1), String.valueOf(testScript.size())}));
                }
            }
        } else if (cmd.equals(StepEvent.STEP_FAILURE) || cmd.equals(StepEvent.STEP_ERROR)) {
            // Make sure the table updates its colors
            final int index = scriptModel.getRowOf(step);
            if (index != -1) {
                // scriptModel.fireTableRowsUpdated(index, index);
                AWT.invokeAndWait(new Runnable() {

                    @Override
                    public void run() {
                        scriptModel.fireTableRowsUpdated(index, index);
                    }
                });

            }
            setStatusForStep(step);
        }
    }

    protected Resolver getContext() {
        return scriptTable.getScriptContext();
    }

    /** From abbot.Resolver. */
    @Override
    public ComponentReference getComponentReference(String refid) {
        return getContext() != null ? getContext().getComponentReference(refid) : null;
    }

    /** From abbot.Resolver. */
    @Override
    public ComponentReference getComponentReference(Component comp) {
        return getContext() != null ? getContext().getComponentReference(comp) : null;
    }

    /** From abbot.Resolver. */
    @Override
    public void addComponentReference(ComponentReference ref) {
        if (getContext() == null) {
            throw new RuntimeException(Strings.get("NoContext"));
        }
        getContext().addComponentReference(ref);
    }

    /** From abbot.Resolver. */
    @Override
    public ComponentReference addComponent(Component comp) {
        if (getContext() == null) {
            throw new RuntimeException(Strings.get("NoContext"));
        }
        return getContext().addComponent(comp);
    }

    /** From abbot.Resolver. */
    @Override
    public String getUniqueID(ComponentReference ref) {
        if (getContext() == null) {
            throw new RuntimeException(Strings.get("NoContext"));
        }
        return getContext().getUniqueID(ref);
    }

    /** From abbot.Resolver. 
     * @SuppressWarnings("unchecked") Code aus Abbot */
    @Override
    @SuppressWarnings("unchecked")
    public Collection<ComponentReference> getComponentReferences() {
        if (getContext() == null) {
            return new HashSet<ComponentReference>();
        }
        return getContext().getComponentReferences();
    }

    /** From abbot.Resolver. */
    @Override
    public File getDirectory() {
        if (getContext() == null) {
            return new File(System.getProperty("user.dir"));
        }
        return getContext().getDirectory();
    }

    /** From abbot.Resolver. */
    @Override
    public void setProperty(String name, String value) {
        if (getContext() != null) {
            getContext().setProperty(name, value);
        }
    }

    /** From abbot.Resolver. */
    @Override
    public String getProperty(String name) {
        if (getContext() != null) {
            return getContext().getProperty(name);
        }
        return null;
    }

    @Override
    public String toString() {
        if (isRootEditor) {
            return "Script Editor (root)";
        }
        return "Script Editor (under test)";
    }

    protected void setStepEditor(Step step) {
        final StepEditor tEditor;
        ignoreEvents = true;
        if (step != null && (tEditor = StepEditor.getEditor(step)) != null) {
            view.setEditor(tEditor);
            // make sure the script model listens to changes from the
            // editor 
            tEditor.addStepChangeListener(new StepChangeListener() {

                @Override
                public void stepChanged(Step aStep) {
                    int row = scriptModel.getRowOf(aStep);
                    if (row != -1) scriptModel.fireTableRowsUpdated(row, row);
                }
            });
        } else {
            Log.debug("No editor available for " + step);
            view.setEditor(null);
        }
        ignoreEvents = false;
        // Update the component browser if the context changes
        view.getComponentBrowser().setResolver(getContext());
    }

    protected static String usage() {
        return ScriptEditor.class.getName() + " [suite classname]";
    }

    /** 
     * @deprecated Set the properties for your action directly.
     * Install the given documentation properties, given as an array of four
     * Strings.  Add-on classes derived from ComponentTester should invoke
     * this for each exported action.  These properties are for use by the
     * editor to better describe the available methods.<p> 
     */
    @Deprecated
    public static void setDocumentationProperties(String[] action) {
        System.setProperty(action[0] + ".menu", action[1]);
        System.setProperty(action[0] + ".desc", action[2]);
        if (action.length > 3 && action[3] != null && !"".equals(action[3])) {
            System.setProperty(action[0] + ".args", action[3]);
        }
        if (action.length > 4 && action[4] != null && !"".equals(action[4])) {
            System.setProperty(action[0] + ".icon", action[4]);
        }
    }

    /**
     * This class responds to changes in the script table's selection.
     */
    protected class ScriptTableSelectionHandler implements ListSelectionListener {

        @Override
        public void valueChanged(ListSelectionEvent ev) {
            if (ev.getValueIsAdjusting() || isScriptRunning) return;
            showStepEditor();
        }
    }

    protected void showStepEditor() {
        Step step = scriptTable.getSelectedRowCount() == 1 ? scriptModel.getStepAt(scriptTable.getSelectedRow()) : null;
        setStepEditor(step);
        setStatusForStep(step);
        enableComponents();
    }

    /**
     * Handle the current test case/script selection from the current test
     * suite (if any).
     */
    protected class ScriptSelectorItemHandler implements ItemListener {

        @Override
        public void itemStateChanged(ItemEvent e) {
            if (ItemEvent.SELECTED == e.getStateChange() && !ignoreComboBox) {
                if (checkSaveBeforeClose()) {
                    setScript(new Script((String)e.getItem()));
                } else {
                    setScript(testScript);
                }
            }
        }
    }

    /** Provide a global editor context for anyone else that wants to display
     * an appropriate dialog message.
     */
    // FIXME move to ScriptEditorFrame
    protected static ScriptEditor editor = null;

    /** Global facility for message dialogs. */
    public static void showMessage(String title, String msg) {
        Frame frame = editor != null ? editor.view : null;
        msg = TextFormat.dialog(msg);
        JOptionPane.showMessageDialog(frame, msg);
    }

    /** Global facility for warning dialog. */
    public static void showWarning(String msg) {
        showWarning(Strings.get("Warning.title"), msg);
    }

    /** Global facility for warning dialog. */
    public static void showWarning(String title, String msg) {
        Frame frame = editor != null ? editor.view : null;
        msg = TextFormat.dialog(msg);
        JOptionPane.showMessageDialog(frame, msg, title, JOptionPane.WARNING_MESSAGE);
    }

    /** Global facility for obtaining a user input String. */
    public static String showInputDialog(String title, String msg, String initial) {
        Frame frame = editor != null ? editor.view : null;
        msg = TextFormat.dialog(msg);
        return (String)JOptionPane.showInputDialog(frame, msg, title, JOptionPane.PLAIN_MESSAGE, null, null, initial);
    }

    /* Port from abbot 1.3
     * 
     * Moved to view!
     *  
     *  
     */
    /** Global facility for error dialogs. */
    //    public static void showError(String msg) {
    //        showError(Strings.get("Error.title"), msg);
    //    }

    /** Global facility for error dialogs. */
    //    public static void showError(String title, String msg) {
    //        Frame frame = editor != null ? editor.view : null;
    //        msg = TextFormat.dialog(msg);
    //        JOptionPane.showMessageDialog(frame, msg, title, JOptionPane.ERROR_MESSAGE);
    //    }

    public void showError(String msg) {
        showError(Strings.get("Error.title"), msg);
    }

    public void showError(String title, String msg) {
        view.showError(title, msg);
    }

    public static int showConfirmation(String msg) {
        return showConfirmation(msg, JOptionPane.YES_NO_OPTION);
    }

    public static int showConfirmation(String msg, int opts) {
        Frame frame = editor != null ? editor.view : null;
        msg = TextFormat.dialog(msg);
        return JOptionPane.showConfirmDialog(frame, msg, Strings.get("Confirm"), opts);
    }

    /** Return the human-readable menu name for the action. */
    protected String getTesterMethodMenuName(Method m) {
        String name = m.getName();
        // First try the resource bundle, then a system property
        String menu = Strings.get(name + ".menu", true);
        if (menu == null) {
            menu = System.getProperty(name + ".menu");
            // Default to the stripped-down method name
            if (menu == null) {
                if (name.startsWith("action") || name.startsWith("assert"))
                    menu = name.substring(6);
                else if (name.startsWith("is"))
                    menu = name.substring(2);
                else if (name.startsWith("get"))
                    menu = name.substring(3);
                else
                    menu = name;
            }
        }
        return menu;
    }

    protected Icon getTesterMethodIcon(Method m) {
        // This loads the icon if it's in a jar file.  Doesn't seem to work
        // when loading from a raw class file in the classpath.
        Icon icon = null;
        String path = Strings.get(m.getName() + ".icon", true);
        if (path == null) {
            path = System.getProperty(m.getName() + ".icon");
        }
        if (path != null) {
            URL url = ScriptEditor.class.getResource(path);
            if (url == null) {
                url = ScriptEditor.class.getResource("icons/" + path + ".gif");
            }
            if (url != null) {
                icon = new ImageIcon(url);
            }
        }
        return icon;
    }

    protected String getTesterMethodArgsDesc(Method m) {
        String cname = Robot.simpleClassName(m.getDeclaringClass());
        String args = Strings.get(cname + "." + m.getName() + ".args", true);
        if (args == null) {
            args = System.getProperty(cname + "." + m.getName() + ".args");
            if (args == null) {
                args = m.toString();
            }
        }
        return args;
    }

    protected EditorAction[] createActions() {
        ActionListener al = ScriptEditor.this;
        EditorAction[] tActions =
                new EditorAction[] {new EditorAction(MI_ABOUT, "About", al),
                                    new EditorAction(MI_NEW, "NewScript", al),
                                    new EditorAction(MI_OPEN, "OpenScript", al),
                                    new EditorAction(MI_DUPLICATE, "Duplicate", al),
                                    new EditorAction(MI_SAVE, "SaveScript", al),
                                    new EditorAction(MI_SAVE_AS, "SaveAs", al),
                                    new EditorAction(MI_RENAME, "Rename", al),
                                    new EditorAction(MI_CLOSE, "Close", al),
                                    new EditorAction(MI_DELETE, "DeleteScript", al),
                                    new EditorAction(MI_EXIT, "Exit", al),
                                    new EditorAction(MI_CUT, "Cut", al),
                                    new EditorAction(MI_MOVE_UP, "MoveUp", al),
                                    new EditorAction(MI_MOVE_DOWN, "MoveDown", al),
                                    new EditorAction(MI_GROUP, "Group", al),
                                    new EditorAction(MI_CLEAR, "ClearScript", al),
                                    new EditorAction(MI_RUN, "RunScript", al),
                                    new EditorAction(MI_RUNTO, "RunScriptTo", al),
                                    new EditorAction(MI_RUNSELECTED, "editor.actions.run_selected", al),
                                    new EditorAction(MI_EXPORT_HIERARCHY, "editor.actions.export_hierarchy", al),
                                    new EditorAction(MI_LAUNCH, "Launch", al),
                                    new EditorAction(MI_TERMINATE, "Terminate", al),
                                    new EditorAction(MI_GETVMARGS, "GetVMArgs", al),
                                    new EditorAction(MI_INSERT_LAUNCH, "InsertLaunch", al),
                                    new EditorAction(MI_INSERT_TERMINATE, "InsertTerminate", al),
                                    new EditorAction(MI_INSERT_CALL, "InsertCall", al),
                                    new EditorAction(MI_INSERT_SAMPLE, "InsertSample", al),
                                    new EditorAction(MI_INSERT_SEQUENCE, "InsertSequence", al),
                                    new EditorAction(MI_INSERT_SCRIPT, "InsertScript", al),
                                    new EditorAction(MI_INSERT_COMMENT, "InsertComment", al),
                                    new EditorAction(MI_INSERT_ANNOTATION, "InsertAnnotation", al),
                                    new EditorToggleAction(MI_STOP_ON_FAILURE, "StopOnFailure", al),
                                    new EditorToggleAction(MI_STOP_ON_ERROR, "StopOnError", al),
                                    new EditorToggleAction(MI_FORK, "Fork", al),
                                    new EditorToggleAction(MI_SLOW, "SlowPlayback", al),
                                    new EditorAction(MI_SELECT_TESTSUITE, "SelectTestSuite", al),};
        if (tActions.length != MI_ACTION_COUNT) {
            Log.warn("EditorConstants doesn't match actions array");
            System.exit(1);
        }
        return tActions;
    }

    /** This action shows an input dialog to collect arguments for a given
     * method on a ComponentTester class and adds an assertion or action to
     * the current script. 
     */
    protected class TesterMethodAction extends AbstractAction {

        protected Method method;

        protected ComponentTester tester;

        protected boolean wait;

        public TesterMethodAction(ComponentTester t, Method m, boolean w) {
            super(getTesterMethodMenuName(m), getTesterMethodIcon(m));
            wait = w;
            tester = t;
            method = m;
        }

        @Override
        public void actionPerformed(ActionEvent ev) {
            addTesterCall(method, tester, wait);
        }
    }

    /** Security manager to prevent applications under test from exiting. */
    protected class EditorSecurityManager extends NoExitSecurityManager {

        @Override
        public void checkRead(String file) {
            // avoid annoying drive A: bug on w32
        }

        /** We do additional checking to allow exit from the editor itself. */
        @Override
        public void checkExit(int status) {
            // Only allow exits by the root script editor
            if (!rootIsExiting) {
                super.checkExit(status);
            }
        }

        @Override
        protected void exitCalled(int status) {
            terminate();
        }
    }

    public void dispose() {
        // Close any application under test
        terminate();
        stopListening();
        // Close this frame; flag to the view to allow it to be disposed
        exiting = true;
        view.setVisible(false);
        view.dispose();

        // Get rid of the security manager
        if (securityManager != null) {
            System.setSecurityManager(oldSecurityManager);
            securityManager = null;
        }
    }

    protected static void bugCheck() {
        Window w = Costello.getSplashScreen();
        if (w != null) {
            // Test for bugs that the user should know about
            String[] bugs = Robot.bugCheck(Costello.getSplashScreen());
            for (int i = 0; i < bugs.length; i++) {
                showWarning(Strings.get("BugWarning.title"), bugs[i]);
            }
        }
    }

    /** Launch the script editor, with an argument of either a test suite
     * class or a script filename.
     */
    public static void main(String[] args) {
        try {
            args = Log.init(args);

            bugCheck();

            if (args.length > 1) {
                System.err.println("usage: " + usage());
                System.exit(1);
            }

            editor = new ScriptEditor();

            // Load the requested script or suite
            String arg = args.length == 1 ? args[0] : null;
            if (arg != null && new File(arg).exists() && Script.isScript(new File(arg))) {
                editor.setTestSuite(null);
                editor.setScript(arg);
            } else {
                editor.setTestSuite(arg);
                editor.setScript(0);
            }

            // Linux sometimes has some miscellaneous stuff lying around;
            // dispose of it
            editor.finder.disposeWindows();
            editor.view.pack();
            editor.view.setVisible(true);
            // Don't start listening to events until we're done generating them
            // (the "show" above can trigger deadlocks when the framework is
            // under test).
            editor.startListening();
        } catch (Throwable e) {
            if (editor != null) editor.dispose();
            System.err.println("Unexpected exception trying to launch " + "the script editor");
            logger.error("Something ugly happened: ", e);
            System.exit(1);
        }
    }

    protected void highlightComponent(final Component comp, boolean on) {
        // FIXME investigate the right way to do this
        // Maybe by setting a custom border?
        comp.repaint();
        if (!on) {
            return;
        }
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                Graphics g = comp.getGraphics();
                g.setColor(Color.red);
                Rectangle bounds = g.getClipBounds();
                if (bounds != null) {
                    g.drawRect(bounds.x, bounds.y, bounds.width - 1, bounds.height - 1);
                } else {
                    g.drawRect(0, 0, comp.getWidth() - 1, comp.getHeight() - 1);
                }
            }
        });
    }

    protected class RecordAllAction extends AbstractAction {

        protected Recorder tRecorder = null;

        public RecordAllAction(Recorder rec, boolean motion) {
            super(rec.toString());
            tRecorder = rec;
            String stroke = "shift F2";
            if (motion) stroke = "alt " + stroke;
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(stroke));
            putValue(NAME, tRecorder.toString());
        }

        @Override
        public void actionPerformed(ActionEvent ev) {
            Log.debug("Menu action: start recording due to " + ev.getActionCommand());
            startRecording(tRecorder);
        }
    }

    /*
     * Abbot Ext begin
     */
    public Script getTestScript() {
        return testScript;
    }

    /*
     * Abbot Ext end
     */
}
