package abbot.editor.recorder;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.event.MouseEvent;

import javax.swing.JTabbedPane;
import javax.swing.plaf.TabbedPaneUI;

import abbot.Resolver;
import abbot.script.Action;
import abbot.script.ComponentReference;
import abbot.script.Step;


/**
 * Record basic semantic events you might find on an JTabbedPane. <p>
 * <ul>
 * <li>Select a tab.
 * </ul>
 */
public class JTabbedPaneRecorder extends JComponentRecorder {

    public JTabbedPaneRecorder(Resolver resolver) {
        super(resolver);
    }

    @Override
    public boolean accept(AWTEvent event) {
        if (isClick(event)) {
            MouseEvent me = (MouseEvent)event;
            JTabbedPane tp = (JTabbedPane)me.getComponent();
            TabbedPaneUI ui = tp.getUI();
            int index = ui.tabForCoordinate(tp, me.getX(), me.getY());
            if (index != -1) {
                setStatus("Selecting tab '" + tp.getTitleAt(index));
                init(SE_CLICK);
                return true;
            }
        }
        return super.accept(event);
    }

    /** Parse clicks, notably those that select a tab. */
    @Override
    protected Step createClick(Component target, int x, int y, int mods, int count) {
        ComponentReference cr = getResolver().addComponent(target);
        JTabbedPane tp = (JTabbedPane)target;
        TabbedPaneUI ui = tp.getUI();
        int index = ui.tabForCoordinate(tp, x, y);
        if (index != -1) {
            //abbot_ext_begin
            //Nicht den Titel, sondern den Namen nehmen
            // String title = tp.getTitleAt(index);
            String title = tp.getComponent(index).getName();
            if (title == null) {
                title = tp.getTitleAt(index);
            }
            //abbot_ext_end
            return new Action(getResolver(),
                              null,
                              "actionSelectTab",
                              new String[] {cr.getID(), title},
                              javax.swing.JTabbedPane.class);
        }
        return super.createClick(target, x, y, mods, count);
    }
}
