package abbot.editor.recorder;

import java.awt.Component;
import java.awt.Container;

import abbot.Resolver;
import abbot.script.Action;
import abbot.script.ComponentReference;
import abbot.script.Step;
import abbot.tester.extensions.GTreeControlTester;
import de.gebit.trend.gui.list.GTableControl;
import de.gebit.trend.gui.treeview.GTreeControl;


public class GScrollPanelClientRecorder extends JComponentRecorder {

    public GScrollPanelClientRecorder(Resolver aResolver) {

        super(aResolver);
    }


    /** 
     * Pr�fen, ob der Klick auf ein GTreeControl ausgef�hrt wurde;
     * dann werden die selektierten Eintr�ge in dem erzeugten Step gemerkt
     * Anmerkung: jedem selektierten Eintrag wird die Methode toString geschickt;
     * es liegt in der Verantwortung der jeweiligen Klasse der Eintr�ge, dass toString einen eindeutigen Wert
     * zur�ckliefert, �ber den beim Abspielen der jeweilige Eintrag wieder eindeutig gefunden werden kann.
     * Sind mehrere Eintr�ge selektiert, so werden die Werte im Step mit @@ aneinander geh�ngt
     * @see abbot.editor.recorder.ComponentRecorder#createClick(java.awt.Component, int, int, int, int)
     */
    @Override
    protected Step createClick(Component comp, int x, int y, int mods, int count) {

        Container target = comp.getParent();

        if (target instanceof GTableControl) {
            return new GTableControlRecorder(getResolver()).createClick(target, x, y, mods, count);
        }


        else if (target instanceof GTreeControl) {
            Object[] tempSelObjects = ((GTreeControl)target).getSelectedObjects();
            String tempSelectionString = GTreeControlTester.NO_ENTRY_SELECTED_INDICATOR;
            if (tempSelObjects.length > 0) {
                StringBuffer tempSelectedObjectsSB = new StringBuffer();
                for (Object tSelObject : tempSelObjects) {
                    tempSelectedObjectsSB.append(tSelObject.toString());
                    tempSelectedObjectsSB.append(GTreeControlTester.ENTRY_SEPARATOR);
                }
                tempSelectionString = tempSelectedObjectsSB.toString();
                tempSelectionString = tempSelectionString.substring(0, tempSelectionString.length() - 2);
            }

            ComponentReference cr = getResolver().addComponent(target);

            String[] args = new String[2];
            args[0] = cr.getID();
            args[1] = tempSelectionString;

            return new Action(getResolver(), null, "actionSelectItem", args);


        }
        return super.createClick(comp.getParent(), x, y, mods, count);


    }
}
