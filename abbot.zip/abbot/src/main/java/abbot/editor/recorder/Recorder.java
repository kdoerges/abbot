package abbot.editor.recorder;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import abbot.ComponentFinder;
import abbot.DefaultComponentFinder;
import abbot.Log;
import abbot.Resolver;
import abbot.script.Step;
import abbot.tester.Robot;

/**
 * The Recorder provides a mechanism for recording an event stream and
 * generating a sequence of script steps from that stream.
 * <p>
 * NOTE: when writing a recorder, be very careful not to test for
 * platform-specific behavior, and avoid being susceptible to
 * platform-specific bugs.  Please make sure the recorder works on both
 * pointer-focus and click-to-focus window managers, as well as on at least
 * two platforms.<p>
 */
public abstract class Recorder {
    private ActionListener al;
    private Resolver resolver;
    private ComponentFinder finder;
    private long lastEventTime = 0;

    /** Create a Recorder for use in converting events into script steps. */
    public Recorder(Resolver resolver) {
        this.resolver = resolver;
        this.finder = DefaultComponentFinder.getFinder();
    }

    /** The recorder supports zero or one listeners. */
    public void addActionListener(ActionListener al) {
        this.al = al;
    }

    protected ActionListener getListener() { return al; }

    /** Start recording a new event stream. */
    public void start() {
        lastEventTime = System.currentTimeMillis();
    }

    /** Indicate the end of the current event input stream. */
    public abstract void terminate() throws RecordingFailedException;

    public long getLastEventTime() {
        return lastEventTime;
    }

    /** Create a step or sequence of steps based on the event stream so far. */
    protected abstract Step createStep();

    /** Return a step or sequence of steps representing the steps created thus
        far, or null if none.
    */
    public Step getStep() {
        return createStep();
    }

    /** Insert an arbitrary step into the recording stream. */
    public void insertStep(Step step) {
        // Default does nothing
    }

    /** Process the given event. 
        @throws RecordingFailedException if an error was encountered and
        recording should discontinue.
    */
    public void recordEvent(java.awt.AWTEvent event)
        throws RecordingFailedException {
        if (Log.isClassDebugEnabled(getClass()))
            Log.debug("REC: " + Robot.toString(event));
        Object src = event.getSource();
        if ((src instanceof Component)
            && finder.isFiltered((Component)src))
            return;
        lastEventTime = System.currentTimeMillis();
        eventDispatched(event);
    }

    /** Implement this to actually handle the event.
        @throws RecordingFailedException if an error was encountered and
        recording should discontinue.
     */
    protected abstract void eventDispatched(AWTEvent event)
        throws RecordingFailedException;

    /** Return the events of interest to this Recorder. */
    public long getEventMask() {
        return -1;
    }

    /** Return the ComponentFinder to be used by this recorder. */
    protected ComponentFinder getFinder() { return finder; }

    /** Return the Resolver to be used by this recorder. */
    protected Resolver getResolver() { return resolver; }

    /** Indicate the current recording state, so that the status may be
     * displayed elsewhere.
     */
    protected void setStatus(String msg) {
        if (al != null) {
            ActionEvent event = 
                new ActionEvent(this, ActionEvent.ACTION_PERFORMED, msg);
            al.actionPerformed(event);
        }
    }
}
