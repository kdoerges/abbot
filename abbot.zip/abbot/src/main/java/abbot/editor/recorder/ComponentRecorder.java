package abbot.editor.recorder;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.MenuComponent;
import java.awt.MenuContainer;
import java.awt.MenuItem;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentEvent;
import java.awt.event.ContainerEvent;
import java.awt.event.FocusEvent;
import java.awt.event.HierarchyEvent;
import java.awt.event.InputEvent;
import java.awt.event.InputMethodEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.text.AttributedCharacterIterator;
import java.text.CharacterIterator;
import java.util.ArrayList;
import java.util.WeakHashMap;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JToolTip;
import javax.swing.JWindow;

import abbot.BugReport;
import abbot.ComponentNotFoundException;
import abbot.Log;
import abbot.MultipleComponentsFoundException;
import abbot.Platform;
import abbot.Resolver;
import abbot.script.Action;
import abbot.script.Assert;
import abbot.script.ComponentReference;
import abbot.script.Step;
import abbot.tester.ComponentTester;
import abbot.tester.Robot;
import abbot.util.AWT;


/**
 * Record basic semantic events you might find on any component.  This class
 * handles the following actions:<p>
 * <ul>
 * <li>window actions
 * <li>popup menus
 * <li>click (based on coordinates)
 * <li>typed keys
 * <li>basic drag and drop (based on coordinates)
 * <li>InputMethod events (extended character input)
 * </ul>
 *
 * <h3>Window Actions</h3>
 * While these nominally might be handled in a WindowRecorder, they are so
 * common that it's easier to handle here instead.  Currently supports
 * tracking show/hide/activate.  TODO: move/resize/iconfify/deiconify.
 * <h3>Popup Menus</h3>
 * Currently only the click/select/click sequence is supported.  The
 * press/drag/release version shouldn't be hard to implement, though.
 * <h3>Click</h3>
 * Simple press/release on a component, storing the exact coordinate of the
 * click.  Most things with selectability will want to override this.  Culling
 * accidental intervening drags would be nice but probably not worth the
 * effort or complexity (better just to be less sloppy with your mouse).
 * <h3>Key Type</h3>
 * Capture only events that result in actual output.  No plain modifiers,
 * shortcuts, or mnemonics.
 * <h3>Drag/Drop</h3>
 * Basic drag from one component and drop on another, storing exact
 * coordinates of the press/release actions.  Should definitely override this
 * to represent your component's internal objects (e.g. cells in a table).
 * Note that these are two distinct actions, even though they always appear
 * together.  The source is responsible for identifying the drag, and the
 * target is responsible for identifying the drop.
 * <h3>InputMethod</h3>
 * Catch extended character input.
 */
// TODO: Use Recorders (Recognizer?) for individual event types, instead of
// doing all the parsing in-line here.  maybe create a new recognizer for each
// event. 
// NOTE: Mac OSX robot will actually generate key modifiers prior
// to  button2/3 
// NOTE: Mac OSX CTRL/ALT+MB1 invokes MB2
// CTRL+MB1->CTRL+MB2
// ALT+MB1->MB2
public class ComponentRecorder extends SemanticRecorder {

    private static final String[] TYPES = {"any",
                                           "window",
                                           "menu",
                                           "click",
                                           "key",
                                           "drag",
                                           "drop",
                                           "text",
                                           "input method"};

    /** Mappings for special keys. */
    private static java.util.HashMap specialMap;

    static {
        // Make explicit some special key mappings which we DON'T want to save
        // as the resulting characters (b/c they may not actually be
        // characters, or they're not particularly good to save as
        // characters. 
        int[][] mappings = { {'\t', KeyEvent.VK_TAB}, {'', KeyEvent.VK_ESCAPE}, // No escape sequence exists
                            {'\b', KeyEvent.VK_BACK_SPACE},
                            {'', KeyEvent.VK_DELETE}, // FIXME is there an escape code?
                            {'\n', KeyEvent.VK_ENTER},
                            {'\r', KeyEvent.VK_ENTER},};
        specialMap = new java.util.HashMap();
        for (int i = 0; i < mappings.length; i++) {
            specialMap.put(String.valueOf((char)mappings[i][0]), Robot.getKeyCode(mappings[i][1]));
        }
    }

    // For windows
    private Window window = null;

    private boolean isClose = false;

    // For key presses
    private char keychar = KeyEvent.CHAR_UNDEFINED;

    private int modifiers = 0;

    // For clicks
    private Component target = null;

    private Component forwardedTarget = null;

    private int x, y;

    private boolean expectNoClick = false; // unused

    private boolean released = false;

    private int clickCount = 0;

    // For menu events
    private Component invoker = null;

    private int menux, menuy;

    private MenuItem awtMenuTarget = null;

    private Frame awtMenuFrame = null;

    private Component menuTarget = null;

    private boolean isPopup = false;

    private boolean menuCanceled = false;

    // For drag events
    // This class is responsible for handling drag/drop once the action has
    // been recognized by a derived class
    private Component dragSource = null;

    private int dragx, dragy;

    // For drop events
    private Component dropTarget = null;

    private int dropx, dropy;

    private boolean desktopDrop = false;

    // misc tracking
    private boolean mouseLeft = false;

    // InputMethod
    private ArrayList imKeyCodes = new ArrayList();

    private StringBuffer imText = new StringBuffer();

    private int imModifiers = 0;

    /** Keep a short-term memory of windows we've seen open/close already. */
    private static WeakHashMap closeEventWindows = new WeakHashMap();

    private static WeakHashMap openEventWindows = new WeakHashMap();

    /** Create a ComponentRecorder for use in capturing the semantics of a GUI
     * action.
     */
    public ComponentRecorder(Resolver resolver) {
        super(resolver);
    }

    /** Does the given event indicate a window was shown? */
    protected boolean isOpen(AWTEvent event) {
        int id = event.getID();
        // 1.3 VMs may generate a WINDOW_OPEN without a COMPONENT_SHOWN
        // (see EventRecorderTest.testClickWithDialog)
        // NOTE: COMPONENT_SHOWN precedes WINDOW_OPENED, but we don't really
        // care in this case, since we're just recording the event, not
        // watching for the component's validity.
        if (((id == WindowEvent.WINDOW_OPENED && !openEventWindows.containsKey(event.getSource())) || id == ComponentEvent.COMPONENT_SHOWN)) {
            return true;
        }
        return false;
    }

    /** Does the given event indicate a window was closed? */
    protected boolean isClose(AWTEvent event) {
        int id = event.getID();
        // Window.dispose doesn't generate a HIDDEN event, but it does
        // generate a WINDOW_CLOSED event (1.3/1.4)
        if (((id == WindowEvent.WINDOW_CLOSED && !closeEventWindows.containsKey(event.getSource())) || id == ComponentEvent.COMPONENT_HIDDEN)) {
            return true;
        }
        return false;
    }

    /** Returns whether this ComponentRecorder wishes to accept the given
     * event.  If the event is accepted, the recorder must invoke init() with
     * the appropriate semantic event type.
     */
    @Override
    public boolean accept(AWTEvent event) {
        int rtype = SE_NONE;

        if (isWindowEvent(event)) {
            rtype = SE_WINDOW;
        } else if (isMenuEvent(event)) {
            rtype = SE_MENU;
        }
        // For now, only handle individual key strokes
        else if (isKeyTyped(event)) {
            rtype = SE_KEY;
        } else if (isClick(event)) {
            rtype = SE_CLICK;
        } else if (isDragDrop(event)) {
            rtype = SE_DROP;
        } else if (isInputMethod(event)) {
            rtype = SE_IM;
        } else {
            if (Log.isClassDebugEnabled(ComponentRecorder.class)) Log.debug("Ignoring " + Robot.toString(event));
        }

        init(rtype);
        boolean accepted = rtype != SE_NONE;
        if (accepted && Log.isClassDebugEnabled(ComponentRecorder.class))
            Log.debug("Accepted " + ComponentTester.toString(event));
        return accepted;
    }

    /** Test whether the given event is a trigger for a window event. 
     * Allow derived classes to change definition of a click.
     */
    protected boolean isWindowEvent(AWTEvent event) {
        // Ignore activate and deactivate.  They are unreliable.
        // We only want open/close events on non-tooltip windows
        return (event.getSource() instanceof Window)
               && !AWT.isTransientPopup(event.getSource())
               && !isToolTip(event.getSource())
               && (isClose(event) || isOpen(event));
    }

    /**
     * Return true if this event is tied to the showing or hiding of a tooltip.
     * Such events look like window events, but we check for them before other
     * kinds of window events so as to be able to filter them out.
     * <P>
     * TODO: emit steps to confirm value of tooltip?
     * <P>
     * @param event the event to be queried
     * @return true if this event was generated from a tooltip
     */
    protected boolean isToolTip(Object source) {
        // Tooltips appear to be a direct subclass of JWindow and
        // have a single component of class JToolTip
        if (source instanceof JWindow && !(source instanceof JFrame)) {
            Container pane = ((JWindow)source).getContentPane();
            while (pane.getComponentCount() == 1) {
                Component child = pane.getComponent(0);
                if (child instanceof JToolTip) return true;
                if (!(child instanceof Container)) break;
                pane = (Container)child;
            }
        }
        return false;
    }

    protected boolean isMenuEvent(AWTEvent event) {
        if (event.getID() == ActionEvent.ACTION_PERFORMED && event.getSource() instanceof java.awt.MenuItem) {
            return true;
        } else if (event.getID() == MouseEvent.MOUSE_PRESSED) {
            MouseEvent me = (MouseEvent)event;
            return me.isPopupTrigger()
                   || ((me.getModifiers() & ComponentTester.POPUP_MASK) != 0)
                   || (me.getComponent() instanceof javax.swing.JMenu);
        }
        return false;
    }

    protected boolean isKeyTyped(AWTEvent event) {
        return event.getID() == KeyEvent.KEY_TYPED;
    }

    /** Test whether the given event is a trigger for a mouse button click.
     * Allow derived classes to change definition of a click.
     */
    protected boolean isClick(AWTEvent event) {
        if (event.getID() == MouseEvent.MOUSE_PRESSED) {
            MouseEvent me = (MouseEvent)event;
            return (me.getModifiers() & MouseEvent.BUTTON1_MASK) != 0;
        }
        return false;
    }

    /** Test whether the given event precurses a drop. */
    protected boolean isDragDrop(AWTEvent event) {
        return event.getID() == MouseEvent.MOUSE_DRAGGED;
    }

    /** Default to recording a drag if it looks like one. */
    // FIXME may be some better detection, like checking for DND interfaces. */
    protected boolean canDrag() {
        return true;
    }

    /** Default to waiting for multiple clicks. */
    protected boolean canMultipleClick() {
        return true;
    }

    /** Is this the start of an input method event? */
    private boolean isInputMethod(AWTEvent event) {
        // NOTE: HALF_WIDTH signals start of kanji input
        // NOTE: Mac uses input method for some dual-keystroke chars (option-e)
        return (event.getID() == KeyEvent.KEY_RELEASED && ((KeyEvent)event).getKeyCode() == KeyEvent.VK_HALF_WIDTH)
               || event.getID() == InputMethodEvent.INPUT_METHOD_TEXT_CHANGED;
    }

    /** Provide standard parsing of mouse button events. */
    protected boolean parseClick(AWTEvent event) {
        boolean consumed = true;
        int id = event.getID();
        if (id == MouseEvent.MOUSE_PRESSED) {
            Log.debug("Parsing mouse down");
            MouseEvent me = (MouseEvent)event;
            if (clickCount == 0) {
                target = me.getComponent();
                x = me.getX();
                y = me.getY();
                modifiers = me.getModifiers();
                clickCount = 1;
                released = false;
            } else {
                if (target == me.getComponent()) {
                    clickCount = me.getClickCount();
                    released = false;
                } else if (!released) {
                    // It's possible to get two consecutive MOUSE_PRESSED
                    // events for different targets (e.g. double click on a
                    // table cell to get the default editor) (OSX 1.3.1, XP
                    // 1.4.1_01). Ignore the second click, since it is
                    // artificial, and wait for the original click to finish.
                    forwardedTarget = me.getComponent();
                }
            }
        } else if (id == MouseEvent.MOUSE_RELEASED) {
            Log.debug("Parsing mouse up");
            released = true;
            // Optionally allow for multiple clicks
            if (!canMultipleClick()) setFinished(true);
        } else if (id == MouseEvent.MOUSE_CLICKED) {
            // optionally wait for multiple clicks
            if (!canMultipleClick()) setFinished(true);
        } else if (id == MouseEvent.MOUSE_EXITED) {
            if (event.getSource() == target && forwardedTarget == null) mouseLeft = true;
        } else if (id == MouseEvent.MOUSE_ENTERED) {
            if (event.getSource() == target && forwardedTarget == null) mouseLeft = false;
        } else if (id == MouseEvent.MOUSE_DRAGGED && canDrag()) {
            Log.debug("Changing click to drag start");
            // Was actually a drag; pass off to drag handler
            setRecordingType(SE_DRAG);
            consumed = dragStarted(target, x, y, modifiers, (MouseEvent)event);
        }
        // These events will not prevent a multi-click from being registered.
        else if ((id >= ComponentEvent.COMPONENT_FIRST && id <= ComponentEvent.COMPONENT_LAST)
                 || (event instanceof ContainerEvent)
                 || (event instanceof FocusEvent)
                 || (id == HierarchyEvent.HIERARCHY_CHANGED && (((HierarchyEvent)event).getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) == 0)) {
            // Ignore most hierarchy change and component events between
            // clicks. 
            // The focus event is sporadic on w32 1.4.1_02
        } else {
            // All other events should cause the click to finish,
            // but don't register a click unless we've received the release
            // event. 
            if (released) {
                consumed = false;
                setFinished(true);
            }
        }
        return consumed;
    }

    protected boolean parseWindowEvent(AWTEvent event) {
        boolean consumed = true;
        isClose = isClose(event);
        // Keep track of window open/close state so we don't parse the same
        // semantic event twice (e.g. COMPONENT_SHOWN + WINDOW_OPENED or
        // multiple WINDOW_CLOSED events).
        if (isClose) {
            closeEventWindows.put(event.getSource(), event.getSource());
            openEventWindows.remove(event.getSource());
        } else {
            openEventWindows.put(event.getSource(), event.getSource());
            closeEventWindows.remove(event.getSource());
        }
        Log.log("close=" + isClose + " (" + Robot.toString(event) + ")");
        window = (Window)event.getSource();
        setFinished(true);
        return consumed;
    }

    protected boolean parseKeyEvent(AWTEvent event) {
        int id = event.getID();
        boolean consumed = true;
        if (id == KeyEvent.KEY_TYPED) {
            // If multiple key_typed events are sent, the lowest in the
            // hierarchy receives it first; ignore the next one, if any.
            if (target == null) {
                // Only a single event to capture here, note we're not
                // messing about with modifiers here.
                KeyEvent ke = (KeyEvent)event;
                target = ke.getComponent();
                keychar = ke.getKeyChar();
                modifiers = ke.getModifiers();
                // ignore events that produce no keychar and
                // where the modifier is other than a simple shift, save
                // as a keystroke instead (handled in EventRecorder).
                if (keychar == KeyEvent.CHAR_UNDEFINED || (modifiers != 0 && modifiers != InputEvent.SHIFT_MASK)) {
                    setRecordingType(SE_NONE);
                    setFinished(true);
                }
            } else {
                setFinished(true);
            }
        } else {
            setFinished(true);
            consumed = false;
        }
        return consumed;
    }

    protected boolean parseMenuSelection(AWTEvent event) {
        int id = event.getID();
        boolean consumed = true;
        // press, release, show, [move, show,] press, release
        // press, [drag, show,] release (FIXME not done)
        if (id == ActionEvent.ACTION_PERFORMED) {
            awtMenuTarget = (MenuItem)event.getSource();
            MenuContainer mc = awtMenuTarget.getParent();
            while (mc != null && (mc instanceof MenuComponent)) {
                mc = ((MenuComponent)mc).getParent();
            }
            awtMenuFrame = (Frame)mc;
            modifiers = ((ActionEvent)event).getModifiers();
            setFinished(true);
        } else if (id == MouseEvent.MOUSE_PRESSED) {
            MouseEvent me = (MouseEvent)event;
            // On the first press, we haven't yet set the invoker, which
            // is either a JMenu or the component holding the popup.
            if (invoker == null) {
                invoker = me.getComponent();
                menux = me.getX();
                menuy = me.getY();
                modifiers = me.getModifiers();
                isPopup = me.isPopupTrigger();
            } else if (event.getSource() instanceof JMenuItem) {
                // Click to select the menu item; this will be the second
                // press event received
                menuTarget = (Component)event.getSource();
            } else {
                // Mouse press in something other than the menu, assume it was
                // canceled. 
                // Popup was canceled.  Discard subsequent release/click.
                menuCanceled = true;
                setStatus("Popup menu selection canceled");
            }
            Log.log("Menu mouse press");
        } else if (id == MouseEvent.MOUSE_RELEASED) {
            MouseEvent me = (MouseEvent)event;
            // The menu target won't be set until the second mouse press
            if (menuCanceled) {
                setRecordingType(SE_NONE);
                setFinished(true);
            } else if (menuTarget == null) {
                // This is the first mouse release
                if (!isPopup) {
                    isPopup = me.isPopupTrigger();
                }
            } else {
                if (menuTarget != null) setFinished(true);
            }
            Log.log("Menu mouse release");
        } else if (id == MouseEvent.MOUSE_CLICKED && isPopup) {
            // If it was a popup trigger, make sure there was a popup,
            // otherwise record it as a click
            if (getFinder().findActivePopupMenu(invoker) == null) {
                setRecordingType(SE_CLICK);
                target = invoker;
                x = menux;
                y = menuy;
                setFinished(true);
            }
        } else {
            Log.log("Ignoring " + ComponentTester.toString(event));
        }
        return consumed;
    }

    protected boolean parseDrop(AWTEvent event) {
        int id = event.getID();
        boolean consumed = true;
        // Use enter/exit events to determine what the final destination
        // is, since drag events always use the drag source for the component. 
        if (id == MouseEvent.MOUSE_DRAGGED) {
            // If we don't have a target yet, default to the drag source
            if (dropTarget == null) {
                dropTarget = ((MouseEvent)event).getComponent();
                dropx = ((MouseEvent)event).getX();
                dropy = ((MouseEvent)event).getY();
            }
        } else if (id == MouseEvent.MOUSE_ENTERED) {
            dropTarget = ((MouseEvent)event).getComponent();
            dropx = ((MouseEvent)event).getX();
            dropy = ((MouseEvent)event).getY();
            desktopDrop = false;
        } else if (id == MouseEvent.MOUSE_EXITED) {
            desktopDrop = true;
        } else if (id == MouseEvent.MOUSE_RELEASED) {
            MouseEvent me = (MouseEvent)event;
            Log.debug("Dropped");
            // FIXME is the component always the original press source?
            dropTarget = me.getComponent();
            // I don't think the coords are correct
            //dropx = me.getX();
            //dropy = me.getY();
            setFinished(true);
        } else {
            if (Log.isClassDebugEnabled(ComponentRecorder.class))
                Log.debug("Ignoring " + ComponentTester.toString(event));
        }
        return consumed;
    }

    protected boolean parseInputMethod(AWTEvent event) {
        boolean consumed = true;
        int id = event.getID();
        if (id == KeyEvent.KEY_RELEASED) {
            KeyEvent ke = (KeyEvent)event;
            int code = ke.getKeyCode();
            switch (code) {
            case KeyEvent.VK_HALF_WIDTH:
                // This indicates the input method start (for kanji, anyway)
                break;
            case KeyEvent.VK_FULL_WIDTH:
                // This indicates the input method end (for kanji, anyway)
                Log.log("Captured " + imText);
                setFinished(true);
                break;
            case KeyEvent.VK_ALT_GRAPH:
            case KeyEvent.VK_CONTROL:
            case KeyEvent.VK_SHIFT:
            case KeyEvent.VK_META:
            case KeyEvent.VK_ALT:
                Log.debug("Modifier indicates end of InputMethod");
                consumed = false;
                setFinished(true);
                break;
            default:
                // Consume other key release events, assuming there was no
                // corresponding key press event.
                imKeyCodes.add(new Integer(code));
                break;
            }
        } else if (event instanceof InputMethodEvent) {
            InputMethodEvent ime = (InputMethodEvent)event;
            if (id == InputMethodEvent.INPUT_METHOD_TEXT_CHANGED) {
                if (ime.getCommittedCharacterCount() > 0) {
                    AttributedCharacterIterator iter = ime.getText();
                    StringBuffer sb = new StringBuffer();
                    for (char ch = iter.first(); ch != CharacterIterator.DONE; ch = iter.next()) {
                        sb.append(ch);
                    }
                    imText.append(sb.toString());
                    Log.debug("Partial capture " + sb.toString());
                }
                if (!Platform.isOSX()) setFinished(true);
            }
        } else {
            consumed = false;
            setFinished(true);
        }
        return consumed;
    }

    /** Handle an event.  Return whether the event was consumed. */
    @Override
    public boolean parse(AWTEvent event) {
        if (Log.isClassDebugEnabled(ComponentRecorder.class))
            Log.debug("Parsing " + ComponentTester.toString(event) + " as " + TYPES[getRecordingType()]);

        // Default handling is event consumed, and assume not finished
        boolean consumed = true;

        switch (getRecordingType()) {
        case SE_WINDOW:
            consumed = parseWindowEvent(event);
            break;
        case SE_KEY:
            consumed = parseKeyEvent(event);
            break;
        case SE_CLICK:
            consumed = parseClick(event);
            break;
        case SE_MENU:
            consumed = parseMenuSelection(event);
            break;
        case SE_DROP:
            consumed = parseDrop(event);
            break;
        case SE_IM:
            consumed = parseInputMethod(event);
            break;
        default:
            Log.warn("Unknown input type: " + getRecordingType());
            // error
            break;
        }
        if (isFinished()) {
            try {
                setStep(createStep());
                Log.log("Semantic event recorded");
            } catch (Throwable thr) {
                BugReport br =
                        new BugReport("An error was encountered while "
                                      + "recording; the offending step "
                                      + "has been omitted.", thr);
                setStatus("An error was encountered, see console for details");
                setRecordingType(SE_NONE);
                throw br;
            }
        }

        return consumed;
    }

    /** Returns whether the first drag motion event should be consumed.
     * Derived classes may override this to provide custom drag behavior.
     * Default behavior saves the drag initiation event by itself.
     */
    protected boolean dragStarted(Component target, int x, int y, int modifiers, MouseEvent dragEvent) {
        dragSource = target;
        dragx = x;
        dragy = y;
        setFinished(true);
        return false;
    }

    /** Returns the script step generated from the events recorded so far. */
    @Override
    protected Step createStep() {
        Step step = null;
        Log.debug("Creating step for semantic recorder");
        switch (getRecordingType()) {
        case SE_WINDOW:
            step = createWindowEvent(window, isClose);
            break;
        case SE_MENU:
            if (isPopup) {
                step = createPopupMenuSelection(invoker, menux, menuy, menuTarget);
            } else if (awtMenuTarget != null) {
                step = createAWTMenuSelection(awtMenuFrame, awtMenuTarget);
            } else if (menuTarget != null) {
                step = createMenuSelection(menuTarget);
            }
            break;
        case SE_KEY: {
            if (keychar != KeyEvent.CHAR_UNDEFINED) {
                step = createKey(target, keychar, modifiers);
            } else {
                step = null;
            }
            break;
        }
        case SE_CLICK: {
            if (!mouseLeft) {
                step = createClick(target, x, y, modifiers, canMultipleClick() ? clickCount : 1);
            } else {
                step = null;
            }
            break;
        }
        case SE_DRAG: {
            step = createDrag(dragSource, dragx, dragy);
            break;
        }
        case SE_DROP:
            if (desktopDrop) {
                // drop is to the desktop, apparently.  for now just save
                // coordinates 
                // FIXME
                step = null;
            } else {
                step = createDrop(dropTarget, dropx, dropy);
            }
            break;
        case SE_IM:
            if (imText.length() > 0)
                step = createInputMethod(imKeyCodes, imText.toString());
            else {
                Log.debug("Input method resulted in no text");
                step = null;
            }
            break;
        default:
            step = null;
            break;
        }

        return step;
    }

    /** Create a wait for the window show/hide.  Use an appropriate identifier
        string, which might be the name, title, or component reference.
    */
    protected Step createWindowEvent(Window window, boolean isClose) {
        // Prefer name to title to tag
        String name = getFinder().getComponentName(window);
        String identifier = name;
        if (identifier == null) {
            if (window instanceof Frame)
                identifier = ((Frame)window).getTitle();
            else if (window instanceof Dialog) identifier = ((Dialog)window).getTitle();
        }
        String method = "assertFrameShowing";
        String arg = identifier;
        // If this is an open event, and there are multiple windows that
        // match, then use a component reference instead of the name/title.
        boolean needRef = identifier == null || "".equals(identifier);
        if (!needRef) {
            try {
                Window w = getFinder().findWindow(identifier);
                if (isClose && w != window) needRef = true;
            } catch (MultipleComponentsFoundException m) {
                // Either still some matching windows found after close,
                // or several found on show; in either case, use a ref
                needRef = true;
            } catch (ComponentNotFoundException e) {
                if (!isClose) {
                    // This should never happen, but handle it anyway
                    Log.warn(e);
                    needRef = true;
                }
            }
        }
        if (needRef) {
            ComponentReference ref = getResolver().addComponent(window);
            method = "assertComponentShowing";
            arg = ref.getID();
        }
        Assert step = new Assert(getResolver(), null, method, new String[] {arg}, "true", isClose);
        step.setWait(true);
        return step;
    }

    protected Step createMenuSelection(Component menuItem) {
        ComponentReference cr = getResolver().addComponent(menuItem);
        Step step = new Action(getResolver(), null, "actionSelectMenuItem", new String[] {cr.getID()});
        return step;
    }

    protected Step createAWTMenuSelection(Frame frame, MenuItem menuItem) {
        ComponentReference ref = getResolver().addComponent(frame);
        Step step =
                new Action(getResolver(), null, "actionSelectAWTMenuItemByLabel", new String[] {ref.getID(),
                                                                                                menuItem.getLabel()});
        return step;
    }

    protected Step createPopupMenuSelection(Component invoker, int x, int y, Component menuItem) {
        ComponentReference inv = getResolver().addComponent(invoker);
        JMenuItem mi = (JMenuItem)menuItem;
        Step step =
                new Action(getResolver(), null, "actionSelectPopupMenuItem", new String[] {inv.getID(),
                                                                                           String.valueOf(x),
                                                                                           String.valueOf(y),
                                                                                           mi.getText()});
        return step;
    }

    protected Step createKey(Component comp, char keychar, int mods) {
        //ComponentReference cr = getResolver().addComponent(comp);
        // NOTE: Any keys which might have effects as key press/release should
        // be encoded as a keystroke, rather than a keystring.
        // Tabs are used for focus traversal.
        String code = (String)specialMap.get(String.valueOf(keychar));
        if (code != null) {
            String[] args = mods != 0 ? new String[] {code, Robot.getKeyModifiers(mods)} : new String[] {code};
            return new Action(getResolver(), null, "actionKeyStroke", args);
        }
        return new Action(getResolver(), null, "actionKeyString", new String[] {String.valueOf(keychar)});
    }

    protected Step createDrop(Component comp, int x, int y) {
        ComponentReference cr = getResolver().addComponent(comp);
        Step step =
                new Action(getResolver(), null, "actionDrop", new String[] {cr.getID(),
                                                                            String.valueOf(x),
                                                                            String.valueOf(y)});
        return step;
    }

    protected Step createDrag(Component comp, int x, int y) {
        ComponentReference ref = getResolver().addComponent(comp);
        Step step =
                new Action(getResolver(), null, "actionDrag", new String[] {ref.getID(),
                                                                            String.valueOf(x),
                                                                            String.valueOf(y)});
        return step;
    }

    /** Create a click event with the given event information. */
    protected Step createClick(Component target, int x, int y, int mods, int count) {
        ComponentReference cr = getResolver().addComponent(target);
        ArrayList args = new ArrayList();
        args.add(cr.getID());
        args.add(String.valueOf(x));
        args.add(String.valueOf(y));
        if ((mods != 0 && mods != MouseEvent.BUTTON1_MASK) || count > 1) {
            // NOTE: this currently saves POPUP or TERTIARY, rather than
            // an explicit button 2 or 3.  I figure that makes more sense
            // than a hard coded button number.
            args.add(Robot.getMouseModifiers(mods));
            if (count > 1) {
                args.add(String.valueOf(count));
            }
        }
        return new Action(getResolver(), null, "actionClick", (String[])args.toArray(new String[args.size()]));
    }

    protected Step createInputMethod(ArrayList codes, String text) {
        Log.debug("Text length is " + text.length());
        return new Action(getResolver(), null, "actionKeyString", new String[] {text});
    }

    @Override
    protected void init(int recordingType) {
        super.init(recordingType);
        target = null;
        forwardedTarget = null;
        mouseLeft = released = expectNoClick = false;
        clickCount = 0;
        keychar = KeyEvent.CHAR_UNDEFINED;
        invoker = null;
        awtMenuTarget = null;
        menuTarget = null;
        menuCanceled = false;
        dragSource = dropTarget = null;
        desktopDrop = false;
        window = null;
        isClose = false;
        imKeyCodes.clear();
        imText.delete(0, imText.length());
        imModifiers = 0;
    }
}
