package abbot.editor.recorder;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseEvent;

import javax.swing.text.JTextComponent;

import de.gebit.trend.gui.list.GTableControl;
import de.gebit.trend.gui.list.GTableControl.TableCell;

import abbot.Resolver;
import abbot.script.Action;
import abbot.script.ComponentReference;
import abbot.script.Step;
import extensions.util.TRENDGUIControlUtil;


/**
 * Dient zur Aufzeichung von Event auf TREND-GTextControls
 * @author sk
 */
public class GTableControlRecorder extends JTextComponentRecorder {

    public GTableControlRecorder(Resolver aResolver) {

        super(aResolver);
    }


    /** The text component click should click on the text index instead of a
    mouse coordinate. */
    @Override
    public Step createClick(Component comp, int x, int y, int mods, int count) {

        GTableControl target = (GTableControl) comp;
    	
        int tempSelectedIndex = 0;
        Object tempSelectedColumn = null;

        if (((GTableControl)target).getSelectionModel().isSingleSelection()) {
            tempSelectedIndex = target.getSelectedIndex();
            
            
            TableCell tempSelectedCell = target.getSelectedCell();
            tempSelectedIndex = tempSelectedCell.getRow();
            tempSelectedColumn = tempSelectedCell.getColumnId();
            
        } else {
            int[] tempSelIndices = target.getSelectedIndices();
            if (tempSelIndices.length == 0) {
                tempSelectedIndex = 1;
            } else {
                tempSelectedIndex = tempSelIndices[tempSelIndices.length - 1];
            }
        }


        //Count starting with 1
        tempSelectedIndex++;

        ComponentReference cr = getResolver().addComponent(target);

        String[] args = null;
        
        if (tempSelectedColumn == null) {
        args =new String[2];
        } else {
        	args =new String[3];
        }
        args[0] = cr.getID();
        args[1] = new Integer(tempSelectedIndex).toString();

        String tempMethodName = "actionSelectItem";
        
        if (tempSelectedColumn != null) {
        	args[2] = tempSelectedColumn.toString();
        }
        
        return new Action(getResolver(), null, tempMethodName, args);        	


    }


}
