package abbot.editor.recorder;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.InputEvent;
import java.util.ArrayList;

import javax.swing.JList;
import javax.swing.ListCellRenderer;

import abbot.Resolver;
import abbot.script.Action;
import abbot.script.ComponentReference;
import abbot.script.Step;


/**
 * Record basic semantic events you might find on an JList. <p>
 * <ul>
 * <li>Select a cell
 * </ul>
 */
public class JListRecorder extends JComponentRecorder {

    public JListRecorder(Resolver resolver) {
        super(resolver);
    }

    /** If the value looks meaningful, return it, otherwise return null. */
    private String getValueAsString(JList list, int index) {
        ListCellRenderer lcr = list.getCellRenderer();
        Object obj = list.getModel().getElementAt(index);
        Component cr = lcr.getListCellRendererComponent(list, obj, index, false, false);
        if (cr instanceof javax.swing.JLabel) return ((javax.swing.JLabel)cr).getText();
        return null;
    }

    /** Create a click referencing the String value that was clicked. */
    @Override
    protected Step createClick(Component target, int x, int y, int mods, int count) {
        JList list = (JList)target;
        ComponentReference cr = getResolver().addComponent(target);
        String methodName = "actionSelectValue";
        ArrayList args = new ArrayList();
        args.add(cr.getID());
        int index = list.locationToIndex(new Point(x, y));
        String value = getValueAsString(list, index);
        if (value != null) {
            args.add(value);
        } else {
            methodName = "actionSelectIndex";
            args.add(String.valueOf(index));
        }
        if ((mods != 0 && mods != InputEvent.BUTTON1_MASK) || count > 1) {
            methodName = value != null ? "actionClickValue" : "actionClickIndex";
            args.add(abbot.tester.Robot.getMouseModifiers(mods));
            if (count > 1) {
                args.add(String.valueOf(count));
            }
        }
        return new Action(getResolver(),
                          null,
                          methodName,
                          (String[])args.toArray(new String[args.size()]),
                          javax.swing.JList.class);
    }
}
