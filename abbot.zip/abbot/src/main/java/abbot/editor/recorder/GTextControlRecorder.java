package abbot.editor.recorder;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseEvent;

import javax.swing.text.JTextComponent;

import abbot.Resolver;
import abbot.script.Action;
import abbot.script.ComponentReference;
import abbot.script.Step;
import extensions.util.TRENDGUIControlUtil;


/**
 * Dient zur Aufzeichung von Event auf TREND-GTextControls
 * @author sk
 */
public class GTextControlRecorder extends JTextComponentRecorder {

    public GTextControlRecorder(Resolver aResolver) {

        super(aResolver);
    }


    /** The text component click should click on the text index instead of a
    mouse coordinate. */
    @Override
    protected Step createClick(Component comp, int x, int y, int mods, int count) {


        if ((mods == MouseEvent.BUTTON1_MASK && count == 1)) {

            // Behandlung der TREND-Controls

            if (TRENDGUIControlUtil.theInstance().isInnerTRENDControl(comp)) {
                Component tempRealComponent = TRENDGUIControlUtil.theInstance().getOuterTRENDControl(comp);
                ComponentReference cr = getResolver().addComponent(tempRealComponent);
                JTextComponent tc = (JTextComponent)comp;
                int index = tc.viewToModel(new Point(x, y));
                return new Action(getResolver(),
                                  null,
                                  "actionClick",
                                  new String[] {cr.getID(), String.valueOf(index),},
                                  tempRealComponent.getClass());

            }

        }

        return super.createClick(comp, x, y, mods, count);

    }


    @Override
    protected Step createDrop(Component comp, int start, int end) {


        if (TRENDGUIControlUtil.theInstance().isInnerTRENDControl(comp)) {
            Component tempRealComponent = TRENDGUIControlUtil.theInstance().getOuterTRENDControl(comp);
            ComponentReference cr = getResolver().addComponent(tempRealComponent);

            return new Action(getResolver(),
                              null,
                              "actionSelect",
                              new String[] {cr.getID(), String.valueOf(start), String.valueOf(end)},
                              tempRealComponent.getClass());


        }


        return super.createDrop(comp, start, end);
    }


}
