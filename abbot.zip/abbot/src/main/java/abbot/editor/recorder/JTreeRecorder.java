package abbot.editor.recorder;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JTree;
import javax.swing.tree.TreePath;

import abbot.Resolver;
import abbot.script.Action;
import abbot.script.ComponentReference;
import abbot.script.Step;


/**
 * Record basic semantic events you might find on an JTree. <p>
 * <ul>
 * <li>Click one or more times in a cell
 * </ul>
 */
public class JTreeRecorder extends JComponentRecorder {

    public JTreeRecorder(Resolver resolver) {
        super(resolver);
    }

    /** Normally, a click in a table results in selection of a given cell. */
    @Override
    protected Step createClick(Component target, int x, int y, int mods, int count) {
        JTree tree = (JTree)target;
        TreePath path = tree.getPathForLocation(x, y);
        int row = tree.getRowForPath(path);
        if (row != -1) {
            ComponentReference cr = getResolver().addComponent(target);
            String methodName = "actionSelectRow";
            ArrayList args = new ArrayList();
            args.add(cr.getID());
            args.add(String.valueOf(row));
            if ((mods != 0 && mods != MouseEvent.BUTTON1_MASK) || count > 1) {
                methodName = "actionClickRow";
                args.add(abbot.tester.Robot.getMouseModifiers(mods));
                if (count > 1) {
                    args.add(String.valueOf(count));
                }
            }
            return new Action(getResolver(),
                              null,
                              methodName,
                              (String[])args.toArray(new String[args.size()]),
                              javax.swing.JTree.class);
        }
        return null;
    }
}
