package abbot.editor;

import java.awt.Component;
import java.awt.Container;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JComponent;
import javax.swing.table.DefaultTableModel;

import abbot.Log;
import abbot.i18n.Strings;
import abbot.script.PropertyCall;
import abbot.tester.ComponentTester;


class ComponentPropertyModel extends DefaultTableModel {

    public static final int PROPERTY_NAME = 0;

    public static final int PROPERTY_VALUE = 1;

    public static final int METHOD_OBJECT = 3;

    private static HashMap filteredPropertyMap = new HashMap();

    static {
        // Indicate things that aren't particularly interesting
        setFilteredPropertyMethods(Component.class, new String[] {"getAccessibleContext",
                                                                  "getAlignmentX",
                                                                  "getAlignmentY",
                                                                  "getColorModel",
                                                                  "getComponentOrientation",
                                                                  "getDropTarget",
                                                                  "getGraphics",
                                                                  "getGraphicsConfiguration",
                                                                  "getHeight",
                                                                  "getInputContext",
                                                                  "getInputMethodRequests",
                                                                  "getLocale",
                                                                  "getLocation",
                                                                  "getLocationOnScreen",
                                                                  "getParent",
                                                                  "getPeer",
                                                                  "getToolkit",
                                                                  "getTreeLock",
                                                                  "getWidth",
                                                                  "getX",
                                                                  "getY",
                                                                  "isDoubleBuffered",
                                                                  "isLightweight",
                                                                  "isOpaque",
                                                                  "isValid",});
        setFilteredPropertyMethods(Container.class, new String[] {"getComponents",});
        setFilteredPropertyMethods(JComponent.class, new String[] {"getActionMap",
                                                                   "getAutoscrolls",
                                                                   "getDebugGraphicsOptions",
                                                                   "getInputMap",
                                                                   "getInputVerifier",
                                                                   "getRegisteredKeyStrokes",
                                                                   "getRootPane",
                                                                   "getTopLevelAncestor",
                                                                   "getUIClassID",
                                                                   "getVerifyInputWhenFocusTarget",
                                                                   "getVisibleRect",
                                                                   "isFocusCycleRoot",
                                                                   "isOpaque",
                                                                   "isOptimizedDrawingEnabled",
                                                                   "isPaintingTile",
                                                                   "isPreferredSizeSet",
                                                                   "isRequestFocusEnabled",
                                                                   "isValidateRoot",});
    }

    /** Install the given filtered property method properties.  Add-on
        ComponentTester classes should invoke this for the list of property
        methods they want to appear in the filtered property list. */
    public static void setFilteredPropertyMethods(Class cls, String[] methods) {
        String list = "";
        String comma = "";
        for (int i = 0; i < methods.length; i++) {
            list += comma + methods[i];
            comma = ",";
        }
        System.setProperty(cls.getName() + ".filtered_properties", list);
    }

    /** Create a model with two columns, the property name and the property
     * value.
     */
    public ComponentPropertyModel() {
        super(new Object[] {Strings.get("Name"), Strings.get("Value")}, 0);
    }

    public void clear() {
        // The setNumRows() method is required to be compatible with JDK
        // 1.2.2 and should be replaced with setRowCount() for 1.3 and above.
        //propTableModel.setNumRows(0); 
        setRowCount(0);
    }

    public void setComponent(Component comp) {
        setComponent(comp, true);
    }

    /** The current list of property methods corresponds to this class. */
    private Class currentComponentClass = null;

    /** Whether the current list is filtered. */
    private boolean isFiltered = false;

    /** Update the list of property methods based on the newly selected
        component.
    */
    public synchronized void setComponent(Component comp, boolean filterMethods) {
        Class cls = comp != null ? comp.getClass() : null;
        if (currentComponentClass == cls && filterMethods == isFiltered) return;
        Method[] all = getPropertyMethods(cls, filterMethods);
        Arrays.sort(all, new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                String n1 = getPropertyName(((Method)o1).getName());
                String n2 = getPropertyName(((Method)o2).getName());
                return n1.compareTo(n2);
            }
        });
        Object[] noArgs = new Object[0];
        Object[] oneArg = new Object[] {comp};
        for (int i = 0; i < all.length; i++) {
            Method method = all[i];
            Vector data = new Vector(2);
            data.addElement(method);
            try {
                Object target = comp;
                Object[] args = noArgs;
                if (ComponentTester.class.isAssignableFrom(method.getDeclaringClass())) {
                    target = ComponentTester.getTester(comp);
                    args = oneArg;
                }
                data.addElement(method.invoke(target, args));
            } catch (IllegalArgumentException e) {
                data.add("<illegal argument>");
                Log.log(e);
            } catch (InvocationTargetException e) {
                data.add("<target exception>");
                Log.log(e);
            } catch (IllegalAccessException e) {
                // method was somehow protected?
                data.add("<not accessible>");
                Log.log(e);
            }
            addRow(data);
        }
        fireTableDataChanged();
    }

    Method[] getPropertyMethods(Class cls, boolean filterMethods) {
        clear();
        currentComponentClass = cls;
        isFiltered = filterMethods;
        if (cls == null) return new Method[0];

        ComponentTester tester = ComponentTester.getTester(cls);
        // Make sure we only get one of each named method 
        HashMap processed = new HashMap();
        while (Component.class.isAssignableFrom(cls)) {
            Method[] methods = cls.getDeclaredMethods();
            for (int i = 0; i < methods.length; i++) {
                if (isAccessibleGetterMethod(methods[i], false) && !processed.containsKey(methods[i].getName())) {

                    if (filterMethods && isFilteredProperty(cls, methods[i].getName())) {
                        continue;
                    }
                    processed.put(methods[i].getName(), methods[i]);
                }
            }
            cls = cls.getSuperclass();
        }
        // Now look up propert accessors provided by the corresponding
        // ComponentTester class.
        Method[] methods = tester.getPropertyMethods();
        for (int i = 0; i < methods.length; i++) {
            if (!processed.containsKey(methods[i].getName())) {
                // Properties provided by the ComponentTester are never
                // filtered. 
                processed.put(methods[i].getName(), methods[i]);
            }
        }

        Log.debug("Total methods: " + processed.size());
        return (Method[])processed.values().toArray(new Method[processed.size()]);
    }

    private HashSet createFilteredPropertySet(Class cls, HashSet set) {
        boolean created = set == null;
        if (set == null) {
            set = new HashSet();
        }
        if (!cls.equals(Component.class)) {
            set = createFilteredPropertySet(cls.getSuperclass(), set);
        }
        String cname = cls.getName();
        String name = cname + ".filtered_properties";
        String list = System.getProperty(name);
        if (list != null) {
            StringTokenizer st = new StringTokenizer(list, ",");
            while (st.hasMoreTokens()) {
                String prop = st.nextToken();
                set.add(prop);
            }
        }

        if (created && set.size() > 0) {
            filteredPropertyMap.put(cls, set);
        }
        return set.size() > 0 ? set : null;
    }

    /** Return true if the method name represents a "filtered" property
        accessor.  In the context of the Script Editor, this means that the
        given property should <i>not</i> appear when the "filter" option is
        selected.
    */
    private boolean isFilteredProperty(Class cls, String methodName) {
        HashSet set = (HashSet)filteredPropertyMap.get(cls);
        if (set == null) {
            set = createFilteredPropertySet(cls, null);
            if (set == null) {
                return true;
            }
        }
        return set.contains(methodName);
    }

    /**
     * Method to check if the method specified on the class
     * is a "getter" for an attribute of that class
     *
     * @param method The method to be tested
     * @return true if the method is a "getter"
     */
    private boolean isAccessibleGetterMethod(Method method, boolean isTester) {
        Class[] types = method.getParameterTypes();
        int argc = types.length;
        return ((isTester && argc == 1 && Component.class.isAssignableFrom(types[0])) || (!isTester && argc == 0))
               && (method.getModifiers() & Modifier.PUBLIC) != 0
               && PropertyCall.isPropertyMethod(method);
    }

    /**
     * Method to "extract" the property name from the method name
     * following the convention specified for a bean
     *
     * @param methodName The name of the method
     * @return The name of the attribute
     */
    private String getPropertyName(String methodName) {
        String propName = methodName;
        if (methodName.startsWith("get") || methodName.startsWith("has")) {
            propName = methodName.substring(3);
        } else if (methodName.startsWith("is")) {
            propName = methodName.substring(2);
        }
        return propName.substring(0, 1).toLowerCase() + propName.substring(1);
    }

    /** Display the property name column apropriately. */
    @Override
    public Object getValueAt(int row, int col) {
        // Method object is in column zero, we want only the property part to
        // appear. 
        if (col == PROPERTY_NAME) {
            Method m = (Method)super.getValueAt(row, col);
            return getPropertyName(m.getName());
        }
        if (col == METHOD_OBJECT) {
            return super.getValueAt(row, 0);
        }
        return super.getValueAt(row, col);
    }
}
