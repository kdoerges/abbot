package abbot.editor.editors;

import java.awt.event.ActionEvent;
import java.lang.reflect.Method;
import java.util.ArrayList;

import javax.swing.JComboBox;

import abbot.i18n.Strings;
import abbot.script.InvalidScriptException;
import abbot.script.PropertyCall;
import abbot.tester.ComponentTester;


/** Provide convenient editing of a PropertyCall step. */
public abstract class PropertyCallEditor extends CallEditor {

    private JComboBox component;

    private PropertyCall call;

    private boolean ignoreCombo = false;

    public PropertyCallEditor(PropertyCall call) {
        super(call);
        this.call = call;
        component = addComponentSelector(Strings.get("ComponentID"), call.getComponentID(), call.getResolver(), true);
    }

    /** Restrict the available methods to those that are non-void.  If the
     * target class is not derived from java.awt.Component, restrict to static
     * methods as well.<p>
     * If this is a Component property call, add in ComponentTester-provided
     * pseudo-properties as well.<p>
     */
    @Override
    protected Method[] getMethods(Class cls, int mask) {
        PropertyCall pc = (PropertyCall)getCall();
        Method[] methods = super.getMethods(cls, mask);
        ArrayList list = new ArrayList();
        for (int i = 0; i < methods.length; i++) {
            if (!void.class.equals(methods[i].getReturnType())) {
                list.add(methods[i]);
            }
        }
        if (((PropertyCall)getCall()).getComponentID() != null) {
            // Scan the component tester for additional property methods
            try {
                ComponentTester tester = ComponentTester.getTester(getCall().getTargetClass());
                Method[] testerMethods = tester.getPropertyMethods();
                for (int i = 0; i < testerMethods.length; i++) {
                    list.add(testerMethods[i]);
                }
            } catch (InvalidScriptException ise) {
                // ignore
            }
        }
        return (Method[])list.toArray(new Method[list.size()]);
    }

    /** Indicate that the step data may have changed and that the editor should
     * update itself.
     */
    @Override
    protected void stepChanged() {
        ignoreCombo = true;
        component.setSelectedItem(call.getComponentID());
        ignoreCombo = false;
        super.stepChanged();
    }

    @Override
    protected void fieldChanged(ActionEvent ev) {
        Object src = ev.getSource();
        if (src == component) {
            if (!ignoreCombo) {
                String id = ((String)component.getSelectedItem()).trim();
                if ("".equals(id)) {
                    id = null;
                }
                call.setComponentID(id);
                fireStepChanged();
            }
        } else {
            super.fieldChanged(ev);
        }
    }
}
