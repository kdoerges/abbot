package abbot.editor.editors;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashMap;

import javax.swing.JComboBox;
import javax.swing.JTextField;

import abbot.Log;
import abbot.i18n.Strings;
import abbot.script.Call;
import abbot.script.InvalidScriptException;


/**
   Provide an editor for call steps.
   @author Blake Christensen <bchristen@users.sourceforge.net>
   @author twall@users.sourceforge.net
 */
public class CallEditor extends StepEditor implements ActionListener {

    private Call call;

    private JTextField target;

    private boolean ignoreCombo = false;

    private JComboBox method;

    private JTextField arguments;

    public CallEditor(Call call) {
        super(call);
        this.call = call;

        target = addTextField(Strings.get("TargetClass"), call.getTargetClassName());

        method = addComboBox(Strings.get("Method"), call.getMethodName(), getMethodNames());

        // FIXME add a field per argument
        arguments = addTextField(Strings.get("Arguments"), call.getEncodedArguments());

    }

    protected Call getCall() {
        return call;
    }

    /** Provide a list of method names corresponding to the current target
        class.  Be careful overloading this method, since it is called from
        the Constructor.
    */
    protected String[] getMethodNames() {
        try {
            Class cls = call.getTargetClass();
            String[] names = getMethodNames(getMethods(cls, Modifier.PUBLIC));
            Arrays.sort(names);
            return names;
        } catch (InvalidScriptException ise) {
            // Invalid class or class not found
            return new String[0];
        }
    }

    protected Class getTargetClass() throws InvalidScriptException {
        return call.getTargetClass();
    }

    /** Return all public member and static methods. */
    protected Method[] getMethods(Class cls, int mask) {
        HashMap processed = new HashMap();
        while (cls != null) {
            Method[] methods = cls.getDeclaredMethods();
            for (int i = 0; i < methods.length; i++) {
                // Only return one method of any given name
                if (!processed.containsKey(methods[i].getName()) && (methods[i].getModifiers() & mask) == mask) {
                    processed.put(methods[i].getName(), methods[i]);
                }
            }
            cls = cls.getSuperclass();
        }
        return (Method[])processed.values().toArray(new Method[processed.size()]);
    }

    /** Convert the given array of methods into an array of strings.
        Subclasses can do additional filtering here.
    */
    protected String[] getMethodNames(Method[] mlist) {
        String[] names = new String[mlist.length];
        for (int i = 0; i < mlist.length; i++) {
            names[i] = mlist[i].getName();
        }
        return names;
    }

    @Override
    protected void stepChanged() {
        target.setText(call.getTargetClassName());
        // Lame combo box fires when you set it up
        ignoreCombo = true;
        // Update the contents of the combo box
        method.removeAllItems();
        String[] items = getMethodNames();
        Log.debug("Updating method names with " + items.length + " items");
        for (int i = 0; i < items.length; i++) {
            method.addItem(items[i]);
        }
        method.setSelectedItem(call.getMethodName());
        ignoreCombo = false;
        arguments.setText(call.getEncodedArguments());
        super.stepChanged();
    }

    @Override
    protected void fieldChanged(ActionEvent ev) {
        Object src = ev.getSource();
        if (src == target) {
            // FIXME verify that the target class can be found
            call.setTargetClassName(target.getText().trim());
            Log.debug("Class changed");
            fireStepChanged();
        } else if (src == method) {
            if (!ignoreCombo) {
                // FIXME verify that the method exists
                call.setMethodName((String)method.getSelectedItem());
                fireStepChanged();
            }
        } else if (src == arguments) {
            // FIXME check method signature and do component field if the
            // first arg is a component, do popup from available refs
            // FIXME check arguments against method signature
            call.setArguments(arguments.getText());
            fireStepChanged();
        } else {
            super.fieldChanged(ev);
        }
    }
}
