package abbot.editor.editors;

import java.awt.event.ActionEvent;

import abbot.script.Sequence;

/** Provide convenient editing of a Sequence step. */
public class SequenceEditor extends StepEditor {

    private Sequence sequence;

    public SequenceEditor(Sequence seq) {
        super(seq);
        this.sequence = seq;
    }
}
