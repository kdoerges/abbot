package abbot.editor.editors;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.Scrollable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import abbot.Log;
import abbot.Resolver;
import abbot.script.ComponentReference;
import abbot.script.Step;


/** Provide base-level step editor support with step change notification.  */
// NOTE: this should really be done with beans instead...

public abstract class StepEditor extends JPanel implements ActionListener, Scrollable {

    private Step step;

    private JLabel label;

    private JTextField description;

    private LayoutManager layout;

    private ArrayList listeners = new ArrayList();

    private static final int MARGIN = 4;

    private Dimension scrollSize;

    public StepEditor(Step step) {
        setBorder(new EmptyBorder(2, 2, 2, 2));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        layout = getLayout();
        this.step = step;
        label = new JLabel(step.getXMLTag());
        label.setFont(label.getFont().deriveFont(Font.BOLD));
        label.setToolTipText(step.getUsage());
        add(label);
        description = addTextField(null, step.getDescription());
        scrollSize = getPreferredSize();
    }

    /** Indicate that the step data may have changed and that the editor should
     * update all its components.
     */
    protected void stepChanged() {
        label.setText(step.getXMLTag());
        label.setToolTipText(step.getUsage());
        description.setText(step.getDescription());
        repaint();
    }

    /** Keep a reasonable minimum width. */
    @Override
    public Dimension getMinimumSize() {
        Dimension min = super.getMinimumSize();
        min.width = 200;
        return min;
    }

    /** Keep a reasonable minimum width. */
    @Override
    public Dimension getPreferredSize() {
        Dimension size = super.getPreferredSize();
        size.width = 200;
        return size;
    }

    /** We don't want to become infinitely wide due to text fields. */
    @Override
    public Dimension getMaximumSize() {
        Dimension max = super.getMaximumSize();
        max.width = 400;
        return max;
    }

    protected JCheckBox addCheckBox(String title, boolean value) {
        JCheckBox cb = new JCheckBox(title);
        cb.setSelected(value);
        cb.addActionListener(this);
        add(cb);
        return cb;
    }

    private static final String NONE = "<None>";

    protected JComboBox addComponentSelector(String title, String refid, Resolver resolver, boolean allowNone) {
        Collection refs = resolver.getComponentReferences();
        JComboBox cb = new JComboBox() {

            @Override
            public Object getSelectedItem() {
                Object obj = super.getSelectedItem();
                if (obj == NONE) obj = null;
                return obj;
            }
        };
        if (allowNone) cb.addItem(NONE);
        Iterator iter = refs.iterator();
        while (iter.hasNext()) {
            cb.addItem(((ComponentReference)iter.next()).getID());
        }
        cb.setSelectedItem(refid);
        cb.addActionListener(this);
        add(title, cb);
        return cb;
    }

    protected JComboBox addComboBox(String title, Object value, Object[] values) {
        JComboBox cb = new JComboBox(values);
        cb.setEditable(true);
        cb.setSelectedItem(value);
        cb.addActionListener(this);
        add(title, cb);
        return cb;
    }

    protected JTextField addTextField(String title, String value) {
        JTextField field = new abbot.editor.TextField(value) {

            /** Don't allow text field to resize height. */
            @Override
            public Dimension getMaximumSize() {
                Dimension size = super.getMaximumSize();
                size.height = super.getPreferredSize().height;
                return size;
            }
        };
        field.addActionListener(this);
        add(title, field);
        return field;
    }

    protected JButton addButton(String title) {
        JButton button = new JButton(title);
        button.addActionListener(this);
        add(button);
        return button;
    }

    protected JTextArea addTextArea(String title, String value) {
        final JTextArea text = new JTextArea(value != null ? value : "");
        text.getDocument().addDocumentListener(new DocumentListener() {

            private void textChanged() {
                ActionEvent ev = new ActionEvent(text, ActionEvent.ACTION_PERFORMED, text.getText());
                StepEditor.this.actionPerformed(ev);
            }

            @Override
            public void changedUpdate(DocumentEvent ev) {
                textChanged();
            }

            @Override
            public void insertUpdate(DocumentEvent ev) {
                textChanged();
            }

            @Override
            public void removeUpdate(DocumentEvent ev) {
                textChanged();
            }
        });
        text.setLineWrap(true);
        text.setWrapStyleWord(true);
        text.setBorder(new JTextField().getBorder());
        add(title, text);
        return text;
    }

    /** Automatically remove the strut spacing and the component. */
    @Override
    public void remove(Component comp) {
        if (getLayout() == layout) {
            Component[] children = super.getComponents();
            for (int i = 1; i < children.length; i++) {
                if (children[i] == comp) {
                    super.remove(children[i - 1]);
                    break;
                }
            }
        }
        super.remove(comp);
    }

    /** Auto-add a label with a component. */
    @Override
    public Component add(String name, Component comp) {
        if (name != null) {
            JLabel label = new JLabel(name);
            label.setLabelFor(comp);
            add(label);
        }
        return add(comp);
    }

    /** Automatically add a vertical struct with a component. */
    @Override
    public Component add(Component comp) {
        if (getLayout() == layout) {
            super.add(Box.createVerticalStrut(MARGIN));
            if (comp instanceof JComponent) {
                ((JComponent)comp).setAlignmentX(JComponent.LEFT_ALIGNMENT);
            }
        }
        return super.add(comp);
    }

    /** This method is invoked whenever a field in the step editor indicates a
        change has been made.  Derived classes should handle events from any
        extra fields they add here, or invoking super.fieldChanged() if the
        event doesn't come from a locally-defined field.
    */
    protected void fieldChanged(ActionEvent ev) {
        Object src = ev.getSource();
        if (src == description) {
            String desc = description.getText();
            if ("".equals(desc)) {
                desc = null;
            }
            step.setDescription(desc);
            description.setText(step.getDescription());
            fireStepChanged();
        }
    }

    /** Respond to component changes.  Should always invoke fireStepChanged
        after updating the step data. */
    @Override
    public void actionPerformed(ActionEvent ev) {
        fieldChanged(ev);
        // Update the description after everything else has been updated;
        // this is required if we're using the default description.
        if (ev.getSource() != description) {
            description.setText(step.getDescription());
        }
    }

    public void addStepChangeListener(StepChangeListener scl) {
        synchronized (listeners) {
            listeners.add(scl);
        }
    }

    public void removeStepChangeListener(StepChangeListener scl) {
        synchronized (listeners) {
            listeners.remove(scl);
        }
    }

    protected void fireStepChanged() {
        synchronized (listeners) {
            Iterator iter = listeners.iterator();
            while (iter.hasNext()) {
                StepChangeListener scl = (StepChangeListener)iter.next();
                scl.stepChanged(step);
            }
        }
    }

    /** Return the appropriate editor panel for the given Step.
     * Custom editors must be named after the step class name, and be defined
     * in the abbot.editor.editors package, e.g. abbot.script.Launch expects
     * abbot.editor.editors.LaunchEditor, abbot.script.Assert expects
     * abbot.editor.editors.AssertEditor. 
     */
    public static StepEditor getEditor(Step step) {
        Class stepClass = step.getClass();
        Log.debug("Looking up editor for " + step + " using " + stepClass);
        String className = stepClass.getName();
        className = "abbot.editor.editors." + className.substring(className.lastIndexOf(".") + 1) + "Editor";
        try {
            Log.debug("Trying " + className);
            Class cls = Class.forName(className);
            Class[] types = new Class[] {stepClass};
            Constructor ctor = cls.getConstructor(types);
            return (StepEditor)ctor.newInstance(new Object[] {step});
        } catch (Exception e) {
            Log.debug(e);
            return null;
        }
    }

    /** Always maintain the minimum width. */
    @Override
    public Dimension getPreferredScrollableViewportSize() {
        return scrollSize;
    }

    @Override
    public int getScrollableBlockIncrement(Rectangle visible, int orient, int direction) {
        return orient == SwingConstants.HORIZONTAL ? visible.width : visible.height;
    }

    @Override
    public boolean getScrollableTracksViewportHeight() {
        return false;
    }

    @Override
    public boolean getScrollableTracksViewportWidth() {
        return true;
    }

    @Override
    public int getScrollableUnitIncrement(Rectangle visible, int orient, int direction) {
        return orient == SwingConstants.HORIZONTAL ? 10 : description.getSize().height;
    }

    @Override
    public String toString() {
        return getClass().getName() + " for " + label.getText();
    }
}
