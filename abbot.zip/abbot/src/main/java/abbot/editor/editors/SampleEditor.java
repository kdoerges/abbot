package abbot.editor.editors;

import java.awt.event.ActionEvent;

import javax.swing.JTextField;

import abbot.i18n.Strings;
import abbot.script.Sample;


/** Provide convenient editing of a Sample step. */
public class SampleEditor extends PropertyCallEditor {

    private Sample step;

    private JTextField property;

    public SampleEditor(Sample step) {
        super(step);
        this.step = step;
        property = addTextField(Strings.get("PropertyName"), step.getPropertyName());
    }

    /** Indicate that the step data may have changed and that the editor should
     * update itself.
     */
    @Override
    protected void stepChanged() {
        property.setText(step.getPropertyName());
        super.stepChanged();
    }

    @Override
    protected void fieldChanged(ActionEvent ev) {
        Object src = ev.getSource();
        if (src == property) {
            String name = property.getText().trim();
            if ("".equals(name)) {
                name = step.getPropertyName();
                property.setText(name);
            } else {
                step.setPropertyName(name);
                fireStepChanged();
            }
        } else {
            super.fieldChanged(ev);
        }
    }
}
