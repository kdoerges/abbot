package abbot.editor.editors;

import javax.swing.JComboBox;
import javax.swing.JTextField;

import abbot.Log;
import abbot.Resolver;
import abbot.script.Event;
import abbot.script.Tags;
import abbot.tester.ComponentTester;


/** Edit a raw AWTEvent. */

public class EventEditor extends StepEditor {

    private Event event;

    JComboBox type;

    JComboBox kind;

    JComboBox cref;

    private boolean ignoreCombo = false;

    JTextField xValue;

    JTextField yValue;

    JTextField keyCode;

    public EventEditor(Event event) {
        super(event);
        this.event = event;
        String idtype = event.getType();
        String idkind = event.getKind();
        String[] typeValues = {"Mouse Event", "Key Event"};
        ignoreCombo = true;
        type = addComboBox("Type", typeValues[0], typeValues);
        type.setEnabled(false);
        type.setEditable(false);
        Resolver resolver = event.getResolver();
        String refid = event.getComponentID();
        if ("MouseEvent".equals(idtype)) {
            String[] kindValues = {"MOUSE_PRESSED", "MOUSE_RELEASED", "MOUSE_MOVED", "MOUSE_DRAGGED"};
            kind = addComboBox("Kind", idkind, kindValues);
            kind.setEditable(false);
            kind.setEnabled(false);
            cref = addComponentSelector("On Component", refid, resolver, false);
            xValue = addTextField("X", event.getAttribute(Tags.TAG_X));
            yValue = addTextField("Y", event.getAttribute(Tags.TAG_Y));
        } else if ("KeyEvent".equals(idtype)) {
            type.setSelectedItem(typeValues[1]);
            String[] kindValues = {"KEY_PRESSED", "KEY_RELEASED"};
            kind = addComboBox("Kind", idkind, kindValues);
            kind.setEditable(false);
            cref = addComponentSelector("On Component", refid, resolver, false);
            // FIXME make a popup w/all keycodes
            keyCode = addTextField("Key Code", event.getAttribute(Tags.TAG_KEYCODE));
        } else {
            Log.warn("Unhandled ID type: " + idtype);
        }
        ignoreCombo = false;
    }

    /** Indicate that the step data may have changed and that the editor should
     * update itself.
     */
    @Override
    protected void stepChanged() {
        ignoreCombo = true;
        kind.setSelectedItem(event.getAttribute(Tags.TAG_KIND));
        ignoreCombo = false;
        String refid = event.getComponentID();
        cref.setSelectedItem(refid);
        if (xValue != null) {
            xValue.setText(event.getAttribute(Tags.TAG_X));
            yValue.setText(event.getAttribute(Tags.TAG_Y));
        } else {
            keyCode.setText(event.getAttribute(Tags.TAG_KEYCODE));
        }
        super.stepChanged();
    }

    @Override
    protected void fieldChanged(java.awt.event.ActionEvent ev) {
        Object src = ev.getSource();
        if (src == cref) {
            event.setComponentID((String)cref.getSelectedItem());
            fireStepChanged();
        } else if (src == kind) {
            if (!ignoreCombo) {
                event.setAttribute(Tags.TAG_KIND, (String)kind.getSelectedItem());
                fireStepChanged();
            }
        } else if (src == xValue) {
            try {
                int value = Integer.parseInt(xValue.getText());
                event.setAttribute(Tags.TAG_X, String.valueOf(value));
                fireStepChanged();
            } catch (NumberFormatException nfe) {
                xValue.selectAll();
            }
        } else if (src == yValue) {
            try {
                int value = Integer.parseInt(yValue.getText());
                event.setAttribute(Tags.TAG_Y, String.valueOf(value));
                fireStepChanged();
            } catch (NumberFormatException nfe) {
                yValue.selectAll();
            }
        } else if (src == keyCode) {
            try {
                String codestr = keyCode.getText().trim();
                int code = ComponentTester.getKeyCode(codestr);
                event.setAttribute(Tags.TAG_KEYCODE, codestr);
            } catch (IllegalArgumentException iae) {
                keyCode.selectAll();
            }
        } else {
            super.fieldChanged(ev);
        }
    }

}
