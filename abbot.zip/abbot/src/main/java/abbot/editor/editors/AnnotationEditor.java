package abbot.editor.editors;

import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTextArea;

import abbot.Log;
import abbot.WaitTimedOutError;
import abbot.i18n.Strings;
import abbot.script.Annotation;


/** A Annotation only has its description available for editing. */

public class AnnotationEditor extends StepEditor {

    private Annotation annotation;

    private JTextArea text;

    private JButton reposition;

    private JCheckBox userDismiss;

    private JComboBox relative;

    private transient boolean ignoreCombo = false;

    public AnnotationEditor(Annotation annotation) {
        super(annotation);
        this.annotation = annotation;
        text = addTextArea(Strings.get("AnnotationText"), annotation.getText());
        relative =
                addComponentSelector(Strings.get("AnchorComponent"),
                                     annotation.getRelativeTo(),
                                     annotation.getResolver(),
                                     true);
        reposition = addButton(Strings.get("Reposition"));
        userDismiss = addCheckBox(Strings.get("UserDismiss"), annotation.getUserDismiss());
    }

    /** Indicate that the step data may have changed and that the editor should
     * update all its components.
     */
    @Override
    protected void stepChanged() {
        super.stepChanged();
        text.setText(annotation.getText());
        userDismiss.setSelected(annotation.getUserDismiss());
        ignoreCombo = true;
        relative.setSelectedItem(annotation.getRelativeTo());
        ignoreCombo = false;
        if (annotation.isShowing()) {
            annotation.showAnnotation();
        }
    }

    /** An editor component changed, respond to it by updating the step. */
    @Override
    protected void fieldChanged(ActionEvent ev) {
        Object src = ev.getSource();
        if (src == text) {
            annotation.setText(text.getText());
            fireStepChanged();
        } else if (src == relative && !ignoreCombo) {
            annotation.setRelativeTo((String)relative.getSelectedItem());
            fireStepChanged();
        } else if (src == reposition) {
            try {
                annotation.showAnnotation();
            } catch (WaitTimedOutError err) {
                // FIXME show a dialog instead
                Log.warn(err);
            }
            fireStepChanged();
        } else if (src == userDismiss) {
            annotation.setUserDismiss(userDismiss.isSelected());
            if (annotation.isShowing()) annotation.showAnnotation();
            fireStepChanged();
        } else {
            super.fieldChanged(ev);
        }
    }
}
