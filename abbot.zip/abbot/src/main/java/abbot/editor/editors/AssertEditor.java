package abbot.editor.editors;

import java.awt.event.ActionEvent;
import java.lang.reflect.Method;
import java.util.ArrayList;

import javax.swing.JCheckBox;
import javax.swing.JTextField;

import abbot.Log;
import abbot.i18n.Strings;
import abbot.script.Assert;
import abbot.script.InvalidScriptException;
import abbot.script.PropertyCall;
import abbot.tester.ComponentTester;


/** Provide convenient editing of an Assert step. */
public class AssertEditor extends PropertyCallEditor {

    private Assert step;

    private JTextField value;

    private JCheckBox invert;

    private JCheckBox wait;

    private JTextField timeout = null;

    private JTextField interval = null;

    public AssertEditor(Assert step) {
        super(step);
        this.step = step;

        value = addTextField(Strings.get("ExpectedResult"), step.getExpectedResult());

        invert = addCheckBox(Strings.get("Invert"), step.isInverted());

        wait = addCheckBox(Strings.get("WaitToggle"), step.isWait());

        addWaitOptions();
    }

    /** Restrict methods to assertXXX if the target class a ComponentTester,
     * or property accessors otherwise.
     */
    @Override
    protected Method[] getMethods(Class cls, int mask) {
        Method[] methods = super.getMethods(cls, mask);
        ArrayList list = new ArrayList();
        boolean isTester = false;
        try {
            isTester = ComponentTester.class.isAssignableFrom(getCall().getTargetClass());
        } catch (InvalidScriptException ise) {
            // ignore, assume it's not a tester
            Log.warn(ise);
        }
        for (int i = 0; i < methods.length; i++) {
            if (isTester) {
                if (methods[i].getName().startsWith("assert")) list.add(methods[i]);
            } else if (PropertyCall.isPropertyMethod(methods[i])) {
                list.add(methods[i]);
            }
        }
        return (Method[])list.toArray(new Method[list.size()]);
    }

    private void addWaitOptions() {
        if (step.isWait()) {
            timeout = addTextField(Strings.get("Timeout"), String.valueOf(step.getTimeout()));
            interval = addTextField(Strings.get("PollInterval"), String.valueOf(step.getPollInterval()));
        } else if (timeout != null) {
            // remove them
            timeout.removeActionListener(this);
            interval.removeActionListener(this);
            while (getComponent(getComponentCount() - 1) != wait) {
                remove(getComponentCount() - 1);
            }
            timeout = interval = null;
        }
        revalidate();
        repaint();
    }

    /** Indicate that the step data may have changed and that the editor should
     * update itself.
     */
    @Override
    protected void stepChanged() {
        value.setText(step.getExpectedResult());
        invert.setSelected(step.isInverted());
        wait.setSelected(step.isWait());
        if (step.isWait()) {
            timeout.setText(String.valueOf(step.getTimeout()));
            interval.setText(String.valueOf(step.getPollInterval()));
        }
        super.stepChanged();
    }

    @Override
    protected void fieldChanged(ActionEvent ev) {
        Object src = ev.getSource();
        if (src == value) {
            step.setExpectedResult(value.getText());
            stepChanged();
            fireStepChanged();
        } else if (src == invert) {
            step.setInverted(!step.isInverted());
            stepChanged();
            fireStepChanged();
        } else if (src == wait) {
            step.setWait(!step.isWait());
            addWaitOptions();
            stepChanged();
            fireStepChanged();
        } else if (src == timeout) {
            try {
                step.setTimeout(Long.parseLong(timeout.getText()));
                fireStepChanged();
            } catch (NumberFormatException nfe) {
                timeout.setText(String.valueOf(Assert.DEFAULT_TIMEOUT));
            }
        } else if (src == interval) {
            try {
                step.setPollInterval(Long.parseLong(interval.getText()));
                fireStepChanged();
            } catch (NumberFormatException nfe) {
                timeout.setText(String.valueOf(Assert.DEFAULT_INTERVAL));
            }
        } else {
            super.fieldChanged(ev);
        }
    }
}
