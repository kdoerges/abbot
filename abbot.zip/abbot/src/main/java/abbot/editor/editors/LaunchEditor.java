package abbot.editor.editors;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import abbot.i18n.Strings;
import abbot.script.Launch;


/** Provide convenient editing of a launch step. */
public class LaunchEditor extends CallEditor {

    private Launch launch;

    private JTextField classpath;

    private JCheckBox reload;

    private JCheckBox thread;

    public LaunchEditor(Launch launch) {
        super(launch);
        this.launch = launch;
        JLabel label;

        classpath = addTextField(Strings.get("Classpath"), launch.getClasspath());

        reload = addCheckBox(Strings.get("Reload"), !launch.delegates());
        thread = addCheckBox(Strings.get("Thread"), launch.isThreaded());

        // Put these side by side instead of the default layout
        JPanel p = new JPanel(new GridLayout(1, 0));
        p.add(reload);
        p.add(thread);
        add(p);
    }

    /** Display only the public static member functions. */
    @Override
    protected String[] getMethodNames(Method[] mlist) {
        ArrayList list = new ArrayList();
        int mask = Modifier.PUBLIC | Modifier.STATIC;
        for (int i = 0; i < mlist.length; i++) {
            if ((mlist[i].getModifiers() & mask) == mask) {
                list.add(mlist[i].getName());
            }
        }
        return (String[])list.toArray(new String[list.size()]);
    }

    @Override
    protected void stepChanged() {
        classpath.setText(launch.getClasspath());
        reload.setSelected(!launch.delegates());
        thread.setSelected(launch.isThreaded());
        super.stepChanged();
    }

    @Override
    protected void fieldChanged(ActionEvent ev) {
        Object src = ev.getSource();
        if (src == classpath) {
            String cp = classpath.getText().trim();
            if ("".equals(cp)) cp = null;
            launch.setClasspath(cp);
            fireStepChanged();
        } else if (src == reload) {
            launch.setDelegates(!launch.delegates());
            fireStepChanged();
        } else if (src == thread) {
            launch.setThreaded(!launch.isThreaded());
            fireStepChanged();
        } else {
            super.fieldChanged(ev);
        }
    }
}
