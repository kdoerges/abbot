package abbot.editor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import abbot.Log;

public class Preferences extends Properties {

    private static final String PROPS_FILENAME = ".abbot.properties";

    public Preferences() {
        load();
    }

    public int getIntegerProperty(String name, int defaultValue) {
        try {
            return Integer.parseInt(getProperty(name));
        }
        catch(Exception e) {
            return defaultValue;
        }
    }

    private void load() {
        File file = new File(System.getProperty("user.home"),
                             PROPS_FILENAME);
        if (file.exists()) {
            try {
                load(new FileInputStream(file));
            }
            catch(IOException io) {
                Log.warn(io);
            }
        }
    }

    public void save() {
        File file = new File(System.getProperty("user.home"),
                             PROPS_FILENAME);
        try { store(new FileOutputStream(file), "Abbot view preferences"); }
        catch(IOException io) { Log.warn(io); }
    }
}
