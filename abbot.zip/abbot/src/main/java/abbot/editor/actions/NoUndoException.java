package abbot.editor.actions;

public class NoUndoException extends Exception {
}
