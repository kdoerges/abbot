package abbot.editor.actions;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import abbot.Log;
import abbot.editor.EditorConstants;
import abbot.editor.ScriptEditorFrame;
import abbot.i18n.Strings;

/** Encapsulate GUI attributes for an editor action. */

public class EditorAction extends AbstractAction implements EditorConstants {

    private ActionListener al;
    private int id;

    public EditorAction(int id, String key, ActionListener al) {
        super(Strings.get(key));
        String name = Strings.get(key);
        String desc = Strings.get(key + ".desc");
        if ("".equals(desc))
            desc = null;
        String longDesc = Strings.get(key + ".ldesc", true); 
        if ("".equals(longDesc))
            longDesc = null;
        String accelerator = Strings.get(key + ".acc", true);
        if ("".equals(accelerator))
            accelerator = null;
        if (accelerator != null)
            accelerator = Accelerator.get(accelerator);
        String mnemonic = Strings.get(key + ".mn", true);
        if ("".equals(mnemonic))
            mnemonic = null;
        String iconName = Strings.get(key + ".icon", true);
        if ("".equals(iconName))
            iconName = null;

        this.id = id;
        this.al = al;
        putValue(NAME, name);
        if (desc != null) {
            putValue(SHORT_DESCRIPTION, desc);
            // Use the short desc as the long description if there is no long
            // description. 
            if (longDesc == null) {
                putValue(LONG_DESCRIPTION, desc);
            }
        }
        if (longDesc != null) {
            putValue(LONG_DESCRIPTION, longDesc);
        }
        if (iconName != null) {
            putValue(SMALL_ICON, getIcon(iconName, 16));
            putValue(LARGE_ICON, getIcon(iconName, 24));
        }
        if (accelerator != null) {
            try {
                // In case the accelerator given is garbage...
                putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(accelerator));
            }
            catch(Exception e) {
                Log.warn("Bad accelerator '" + accelerator + "': " + e);
            }
        }
        if (mnemonic != null
            && mnemonic.length() > 0
            && ScriptEditorFrame.wantMnemonics) {
            putValue(MNEMONIC_KEY, new Integer(mnemonic.charAt(0)));
        }
    }

    public KeyStroke getAcceleratorKey() {
        return (KeyStroke)getValue(ACCELERATOR_KEY);
    }

    public void actionPerformed(ActionEvent ev) {
        Log.debug("Got " + ev);
        ev = new ActionEvent(this, id, (String)getValue(NAME));
        al.actionPerformed(ev);
    }

    /** 
     * Returns the Icon associated with the given name from the available
     * resources. 
     * 
     * @param name Base name of the icon file e.g., help for help16.gif
     * @param size Size in pixels of the icon from the filename, or zero if
     * none, e.g. 16 for help16.gif or 0 for help.gif.
     * @return an ImageIcon or null if no corresponding icon resource is found.
     */
    public ImageIcon getIcon(String name, int size)  {
        String base = ABBOT_IMAGE_DIR + name;
        URL url = getClass().getResource(base + ".gif");
        if (url == null) {
            url = getClass().getResource(base + size + ".gif");
        }
        ImageIcon icon = url != null ? new ImageIcon(url) : null;
        return icon;
    }
}
