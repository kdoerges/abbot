package abbot.editor.actions;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/** Encapsulate GUI attributes for an editor action. */

public class EditorToggleAction extends EditorAction {

    public static final String STATE = "STATE";

    public EditorToggleAction(int id, String base, ActionListener al) {
        super(id, base, al);
        setSelected(false);
    }

    @Override
    public void actionPerformed(ActionEvent ev) {
        setSelected(!isSelected());
        super.actionPerformed(ev);
    }

    public boolean isSelected() {
        return getValue(STATE) == Boolean.TRUE;
    }

    public void setSelected(boolean state) {
        putValue(STATE, state ? Boolean.TRUE : Boolean.FALSE);
    }
}
