package abbot.editor;

import java.awt.Component;
import java.awt.Container;
import java.awt.Frame;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuComponent;
import java.awt.MenuContainer;
import java.awt.MenuItem;
import java.awt.Window;
import java.util.ArrayList;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;

import abbot.ComponentFinder;
import abbot.DefaultComponentFinder;
import abbot.Log;
import abbot.i18n.Strings;
import abbot.tester.Robot;
import abbot.util.AWT;


public class ComponentNode extends DefaultMutableTreeNode {

    private ComponentFinder finder;

    public ComponentNode() {
        this(null, (Component)null);
    }

    public ComponentNode(ComponentNode parent, Component comp) {
        super(comp, parent == null || comp instanceof Container);
        this.finder = parent == null ? DefaultComponentFinder.getFinder() : parent.finder;
    }

    public ComponentNode(ComponentNode parent, MenuComponent comp) {
        super(comp, comp instanceof MenuContainer);
        this.finder = parent.finder;
    }

    public ComponentNode(ComponentNode parent, MenuItem comp) {
        super(comp, comp instanceof MenuContainer);
        this.finder = parent.finder;
    }

    @Override
    public TreeNode getChildAt(int index) {
        load();
        return super.getChildAt(index);
    }

    @Override
    public int getChildCount() {
        load();
        return super.getChildCount();
    }

    public void reload() {
        removeAllChildren();
        loaded = false;
    }

    private boolean loaded = false;

    private void load() {
        if (loaded) return;
        loaded = true;
        Object obj = getUserObject();
        if (isRoot()) {
            Window[] frames = finder.getRootWindows();
            Log.debug("Root node has " + frames.length + " frames from finder " + finder);
            for (int i = 0; i < frames.length; i++) {
                Log.debug("Adding " + Robot.toString(frames[i]));
                add(new ComponentNode(this, frames[i]));
            }
        } else if (obj instanceof Container) {
            if (obj instanceof Frame) {
                Frame f = (Frame)obj;
                if (f.getMenuBar() != null) {
                    add(new ComponentNode(this, f.getMenuBar()));
                }
            }
            Component[] children = getComponents();
            for (int i = 0; i < children.length; i++) {
                add(new ComponentNode(this, children[i]));
            }
        } else if (obj instanceof MenuBar) {
            MenuBar mb = (MenuBar)obj;
            for (int i = 0; i < mb.getMenuCount(); i++) {
                add(new ComponentNode(this, mb.getMenu(i)));
            }
        } else if (obj instanceof Menu) {
            Menu menu = (Menu)obj;
            for (int i = 0; i < menu.getItemCount(); i++) {
                add(new ComponentNode(this, menu.getItem(i)));
            }
        }
    }

    /** Provide a list of a Component's children, sans any transient popups
     */
    private Component[] getComponents() {
        Component[] children = finder.getComponents((Container)getComponent());
        ArrayList list = new ArrayList();
        for (int i = 0; i < children.length; i++) {
            if (!AWT.isTransientPopup(children[i])) list.add(children[i]);
        }
        return (Component[])list.toArray(new Component[list.size()]);
    }

    /** Returns the Component represented, or null if this is either the root
     * or a java.awt.MenuComponent.
     */
    public Component getComponent() {
        if (getUserObject() instanceof Component) return (Component)getUserObject();
        return null;
    }

    @Override
    public int hashCode() {
        return (isRoot() ? super.hashCode() : getUserObject().hashCode());
    }

    /** Return true if the represented components are the same. */
    @Override
    public boolean equals(Object other) {
        return this == other
               || ((other instanceof ComponentNode) && (getUserObject() == ((ComponentNode)other).getUserObject()));
    }

    // FIXME add a tooltip that shows the complete class name
    @Override
    public String toString() {
        if (isRoot()) {
            return getChildCount() == 0 ? Strings.get("NoComponents") : Strings.get("AllFrames");
        }
        return Robot.toString(getUserObject());
    }
}
