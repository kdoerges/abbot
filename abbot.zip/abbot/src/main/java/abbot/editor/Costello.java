package abbot.editor;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.JWindow;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.SoftBevelBorder;

import extensions.editor.ExtendedScriptEditor;

import abbot.Platform;
import abbot.i18n.Strings;


/** Simple splash screen for the script editor. */
public class Costello {

    static {
        System.setProperty("com.apple.mrj.application.apple.menu.about.name", "Costello");
        if (Platform.getJavaVersionNumber() < Platform.JAVA_1_4) {
            // Mac OSX setup stuff
            System.setProperty("com.apple.mrj.application.growbox.intrudes", "true");
            System.setProperty("com.apple.macos.use-file-dialog-packages", "true");
            System.setProperty("com.apple.macos.useScreenMenuBar", "true");
        } else {
            System.setProperty("apple.laf.useScreenMenuBar", "true");
            System.setProperty("apple.awt.showGrowBox", "true");
        }
    }

    private static class SplashScreen extends JWindow {

        boolean disposeOK = false;

        public SplashScreen() {}

        @Override
        @Deprecated
        public void hide() {
            if (disposeOK) {
                super.hide();
            }
        }

        @Override
        public void dispose() {
            if (disposeOK) {
                super.dispose();
            }
        }
    }

    private static SplashScreen splash = null;

    public static Window getSplashScreen() {
        return splash;
    }

    /** Note that this "main" is typical of many Swing apps, in that it does
        window showing and disposal directly from the main thread.  Running
        the editor under itself should provide a reasonable test for handling
        that scenario.
    */
    public static void main(String[] args) {

        try {
            String lafClass = System.getProperty("abbot.editor.look_and_feel");
            if ("system".equals(lafClass)) lafClass = UIManager.getSystemLookAndFeelClassName();
            if (lafClass != null && !"".equals(lafClass) && !"default".equals(lafClass))
                UIManager.setLookAndFeel(lafClass);
        } catch (Exception e) {}

        splash = new SplashScreen();
        // Load i18n-specific text for the splash screen
        String html = Strings.get("Splash");
        JLabel label = new JLabel(html);
        if (System.getProperty("mrj.version") == null) {
            label.setBorder(new SoftBevelBorder(BevelBorder.RAISED));
        } else {
            label.setBorder(new EmptyBorder(4, 4, 4, 4));
        }
        splash.getContentPane().add(label);
        splash.pack();
        Dimension d = splash.getToolkit().getScreenSize();
        Dimension size = splash.getSize();
        Point loc = new Point((d.width - size.width) / 2, (d.height - size.height) / 2);
        splash.setLocation(loc);
        splash.setVisible(true);

        try {
            //abbot_ext_begin
            ExtendedScriptEditor.main(args);
            //abbot_ext_end
        } finally {
            splash.disposeOK = true;
            // NOTE: disposal in main still screws us up, because the dispose
            // does an invokeAndWait...
            java.awt.EventQueue.invokeLater(new Runnable() {

                public void run() {
                    splash.dispose();
                    splash = null;
                }
            });
        }
    }
}
