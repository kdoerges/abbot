package abbot.editor;

import java.awt.Component;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import abbot.Log;


/** A better text field that fires when focus leaves the component, and
    also selects all the contents when the action is fired to indicate the
    contents were accepted. */
public class TextField extends JTextField {

    public static final String FOCUS_LOST = "focus-lost";

    public TextField(String value) {
        super(value);
        TextField.this.addFocusListener(new java.awt.event.FocusAdapter() {

            @Override
            public void focusLost(java.awt.event.FocusEvent ev) {
                if (!ev.isTemporary() && !isLocalMenuActive()) {
                    Log.debug("Firing on focus loss");
                    fireActionPerformed(FOCUS_LOST);
                }
            }
        });
    }

    /** Detect temporary focus loss due to menu activation. */
    private boolean isLocalMenuActive() {
        boolean active = false;
        Window window = SwingUtilities.getWindowAncestor(TextField.this);
        while (window != null && !active) {
            window = SwingUtilities.getWindowAncestor(window);
            if (window instanceof JFrame) {
                Component comp = window.getFocusOwner();
                Log.debug("Focus is in " + abbot.tester.Robot.toString(comp));
                active = comp != null && (comp instanceof JMenuItem);
            }
        }
        return active;
    }

    protected void fireActionPerformed(String actionCommand) {
        setActionCommand(actionCommand);
        super.fireActionPerformed();
    }

    @Override
    protected void fireActionPerformed() {
        selectAll();
        super.fireActionPerformed();
    }
}
