/**
 * Dieses Package besteht schon in den original Abbot Sourcen und umfasst alle Funktionen
 * f�r den SkriptEditor (und diesen selbst). Der Skripteditor ist ein grafisches Tool, 
 * mit Hilfe dessen Abbot Skripte aufgezeichnet und editiert werden k�nnen.
 * <br>
 * Hier werden Klassen abgelegt, die GfD seitig von den original Sourcen �berschrieben 
 * wurden. Die hier abgelegten Klassen ersetzen jeweils das Pendant im Originalpackage.
 */

package abbot.editor;