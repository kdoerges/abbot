package abbot.editor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.IllegalComponentStateException;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.Action;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import abbot.Log;
import abbot.Platform;
import abbot.editor.actions.EditorAction;
import abbot.editor.actions.EditorToggleAction;
import abbot.i18n.Strings;

import com.apple.mrj.MRJAboutHandler;
import com.apple.mrj.MRJApplicationUtils;

import extensions.system.ExtensionVersion;


/**
 * Provides the primary frame for the Costello script editor.
 *
 * Actions supported (via ActionMap):<br>
 * reload-hierarchy<br>
 * toggle-hierarchy-filter<br>
 * 
 * @author Kyle Girard, twall
 */
public class ScriptEditorFrame extends JFrame implements EditorConstants, abbot.Version {

    private static final Logger logger = LoggerFactory.getLogger(ScriptEditorFrame.class);

    public static final boolean wantMnemonics = !Platform.isMacintosh();

    private JMenuBar menuBar;

    private JLabel currentTestSuiteLabel;

    private JTextField testScriptDescription;

    private JButton testSuiteSelectionButton;

    private JButton runButton;

    private JComboBox testScriptSelector;

    // script on left, step editor on right
    private JSplitPane scriptSplit;

    // script split above, component browser below
    private JSplitPane scriptBrowserSplit;

    private final ScriptTable scriptTable;

    private final JPanel stepEditor;

    private JTextArea statusBar;

    private JDialog statusWindow;

    private boolean statusShown = false;

    private JTextArea statusText;

    private ComponentBrowser componentBrowser;

    private final ScriptEditor editor;

    private final EditorAction[] actions;

    private final Preferences prefs;

    /**
     * Constructs a ScriptEditorFrame with a title and a scriptable
     */
    public ScriptEditorFrame(ScriptEditor editor, String title, ScriptTable scriptTable, EditorAction[] actions) {
        super(title);
        prefs = new Preferences();
        // Keep track of the frame configuration
        addComponentListener(new ComponentAdapter() {

            @Override
            public void componentMoved(ComponentEvent e) {
                try {
                    Point loc = getLocationOnScreen();
                    prefs.setProperty("x", String.valueOf(loc.x));
                    prefs.setProperty("y", String.valueOf(loc.y));
                } catch (IllegalComponentStateException icse) {
                    // ignore it, sometimes the window has gone away
                }
            }

            @Override
            public void componentResized(ComponentEvent e) {
                prefs.setProperty("width", String.valueOf(getWidth()));
                prefs.setProperty("height", String.valueOf(getHeight()));
                /* abbot_ext begin */
                prefs.save();
                /* abbot_ext end */

            }
        });

        this.scriptTable = scriptTable;
        this.stepEditor = new JPanel();
        this.editor = editor;
        this.actions = actions;
        initComponents(editor);
        // Allow us to cancel out of a close.
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    }

    /**
     * Returns the componentBrowser.
     * @return ComponentBrowser
     */
    public ComponentBrowser getComponentBrowser() {
        return componentBrowser;
    }

    /**
     * Sets the componentBrowser.
     * @param componentBrowser The componentBrowser to set
     */
    public void setComponentBrowser(ComponentBrowser componentBrowser) {
        this.componentBrowser = componentBrowser;
        scriptBrowserSplit.setBottomComponent(componentBrowser);
    }

    /**
     * Returns the scriptTable.
     * @return ScriptTable
     */
    public ScriptTable getScriptTable() {
        return scriptTable;
    }

    public String getStatus() {
        return statusBar.getText();
    }

    @Override
    public void dispose() {
        Log.debug("saving prefs");
        /* abbot_ext begin */
        prefs.setProperty("width", "" + getWidth());
        prefs.setProperty("height", "" + getHeight());
        /* abbot_ext end */
        prefs.setProperty("split1", String.valueOf(scriptSplit.getDividerLocation()));
        prefs.setProperty("split2", String.valueOf(scriptBrowserSplit.getDividerLocation()));
        prefs.save();
        super.dispose();
    }

    /** Set the text for the status window.  The first argument is the short
        text and the second is additional optional text to be displayed in a
        larger dialog. 
    */
    public void setStatus(final String msg, final String extended, final Color color) {
        // setText is thread-safe w/r/t the dispatch thread, but setForeground
        // is not 
        statusBar.setText(msg);
        statusText.setText(msg + (extended != null ? "\n" + extended : ""));
        Runnable action = new Runnable() {

            @Override
            public void run() {
                statusBar.setForeground(color);
                statusText.setForeground(color);
                if (statusWindow.isShowing()) resizeStatusWindow();
            }
        };
        if (!color.equals(statusBar.getForeground())) abbot.util.AWT.invokeAction(action);
    }

    @Override
    public void pack() {
        /* abbot_ext begin */
        //  super.pack();
        Dimension size =
                new Dimension(prefs.getIntegerProperty("width", getWidth()), prefs.getIntegerProperty("height",
                                                                                                      getHeight()));
        if (size.width < 200 || size.height < 200) {
            Log.warn("Size is rather small: " + size);
            /* abbot_ext begin */
            size = new Dimension(500, 500);
            /* abbot_ext end */
        }
        Rectangle screen = getGraphicsConfiguration().getBounds();
        int x = (int)(screen.getX() + (screen.getWidth() - size.width) / 2);
        int y = (int)(screen.getY() + (screen.getHeight() - size.height) / 2);
        Point where = new Point(prefs.getIntegerProperty("x", x), prefs.getIntegerProperty("y", y));
        if (prefs.getIntegerProperty("x", 0) > x) {
            where = new Point(x, y);
        }
        setLocation(where);
        if (size.width > screen.getWidth() || size.height > screen.getHeight()) {
            size = new Dimension(800, 600);
        }
        setSize(size);
        int split = size.height / 2;
        split = prefs.getIntegerProperty("split1", -1);
        if (split != -1) {
            if (size.height < split) {
                scriptSplit.setDividerLocation(size.height / 2);
            } else {
                scriptSplit.setDividerLocation(split);
            }
        }
        split = prefs.getIntegerProperty("split2", -1);

        if (split != -1) {
            if (size.height < split) {
                scriptBrowserSplit.setDividerLocation(size.height / 2);
            } else {
                scriptBrowserSplit.setDividerLocation(split);
            }
        }
        /* abbot_ext end */
    }

    /**
     * Returns the testSuiteDescription.
     * @return JLabel
     */
    public JLabel getCurrentTestSuiteLabel() {
        return currentTestSuiteLabel;
    }

    /**
     * Returns the testScriptSelector.
     * @return JComboBox
     */
    public JComboBox getTestScriptSelector() {
        return testScriptSelector;
    }

    /**
     * Returns the testScriptDescription.
     * @return JTextField
     */
    public JTextField getTestScriptDescription() {
        return testScriptDescription;
    }

    private void initComponents(ActionListener al) {
        JPanel pane = (JPanel)getContentPane();

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.X_AXIS));
        top.setBorder(new EmptyBorder(4, 4, 4, 4));
        {
            JLabel suiteLabel = new JLabel(getString("AbbotSuite")) {

                @Override
                public Dimension getMaximumSize() {
                    return super.getPreferredSize();
                }
            };
            suiteLabel.setHorizontalAlignment(SwingConstants.RIGHT);
            currentTestSuiteLabel = new JLabel(getString("NoSuite"));
            currentTestSuiteLabel.setHorizontalAlignment(SwingConstants.LEFT);
            testSuiteSelectionButton = new JButton(actions[MI_SELECT_TESTSUITE]);


            runButton = new JButton(actions[MI_RUN]);
            top.add(suiteLabel);
            top.add(Box.createHorizontalStrut(8));
            top.add(currentTestSuiteLabel);
            top.add(Box.createHorizontalGlue());
            top.add(Box.createHorizontalStrut(8));
            top.add(testSuiteSelectionButton);
            top.add(Box.createHorizontalStrut(8));
            top.add(runButton);
        }

        JPanel center = new JPanel(new BorderLayout());
        {
            testScriptSelector = new JComboBox();
            JPanel scriptPane = new JPanel(new BorderLayout());
            {
                testScriptDescription = new TextField("");
                testScriptDescription.addActionListener(al);

                JScrollPane scroll = new JScrollPane(scriptTable) {

                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(250, 200);
                    }

                    @Override
                    public Dimension getMinimumSize() {
                        return new Dimension(250, super.getMinimumSize().height);
                    }
                };
                scroll.setBorder(null);
                scroll.getViewport().setBackground(scriptTable.getBackground());

                scriptSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
                // script gets extra space
                scriptSplit.setResizeWeight(1.0);
                scriptSplit.setDividerSize(4);
                scriptSplit.setBorder(null);
                scriptSplit.setLeftComponent(scroll);
                scriptBrowserSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
                // script gets extra space
                scriptBrowserSplit.setResizeWeight(1.0);
                scriptBrowserSplit.setDividerSize(4);
                scriptBrowserSplit.setBorder(null);
                scriptBrowserSplit.setTopComponent(scriptSplit);
                scriptPane.add(testScriptDescription, BorderLayout.NORTH);
                scriptPane.add(scriptBrowserSplit, BorderLayout.CENTER);
            }
            //center.add(buttons, BorderLayout.NORTH);
            center.add(testScriptSelector, BorderLayout.NORTH);
            center.add(scriptPane, BorderLayout.CENTER);
        }

        statusText = new JTextArea("");
        statusText.setEditable(false);
        statusText.setBackground(getContentPane().getBackground());
        statusText.setColumns(80);
        statusText.setLineWrap(true);
        statusText.setWrapStyleWord(true);
        statusWindow = createStatusWindow();
        JPanel wp = (JPanel)statusWindow.getContentPane();
        wp.add(new JScrollPane(statusText));

        statusBar = new JTextArea(getString("Initializing"));
        statusBar.setEditable(false);
        statusBar.setBackground(getContentPane().getBackground());
        statusBar.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent me) {
                boolean hasMoreText = !statusBar.getText().equals(statusText.getText());
                boolean hasWideText = statusBar.getPreferredSize().width > statusBar.getSize().width;
                Log.debug("has more=" + hasMoreText + ", hasWide=" + hasWideText);
                if (hasMoreText || hasWideText) {
                    resizeStatusWindow();
                    statusWindow.setVisible(true);
                    resizeStatusWindow();
                }
            }
        });
        statusBar.setToolTipText(getString("Status.tip"));

        pane.setLayout(new BorderLayout());
        pane.setBorder(new EmptyBorder(4, 4, 4, 4));
        pane.add(top, BorderLayout.NORTH);
        pane.add(center, BorderLayout.CENTER);
        pane.add(statusBar, BorderLayout.SOUTH);

        componentBrowser = null;
        menuBar = createMenuBar();

        //abbot_ext_begin
        createPopupMenu();
        //abbot_ext_end
        setJMenuBar(menuBar);
    }

    private JMenu insertMenu;

    private JMenu captureMenu;

    private JMenu actionMenu;

    private JMenu assertMenu;

    private JMenu waitMenu;

    private JDialog aboutBox;

    /** Create a menu item based on an element from our actions array. */
    private JMenuItem createMenuItem(int index) {
        JMenuItem mi;
        EditorAction action = actions[index];
        if (action instanceof EditorToggleAction) {
            mi = new CustomCheckBoxMenuItem((EditorToggleAction)action);
        } else {
            mi = new JMenuItem(action);
        }
        mi.setAccelerator(action.getAcceleratorKey());
        return mi;
    }

    private JMenuBar createMenuBar() {
        JMenuBar mb = new JMenuBar();
        JMenu menu;

        mb.add(menu = createMenu("File"));
        menu.add(createMenuItem(MI_NEW));
        menu.add(createMenuItem(MI_DUPLICATE));
        menu.add(createMenuItem(MI_OPEN));
        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_SAVE));
        menu.add(createMenuItem(MI_SAVE_AS));
        menu.add(createMenuItem(MI_RENAME));
        menu.add(createMenuItem(MI_CLOSE));


        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_DELETE));
        // Mac has it's own dedicated Quit menu item
        if (!Platform.isMacintosh()) {
            menu.add(new JSeparator());
            menu.add(createMenuItem(MI_EXIT));
        }

        mb.add(menu = createMenu("Edit"));
        menu.add(createMenuItem(MI_CUT));
        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_MOVE_UP));
        menu.add(createMenuItem(MI_MOVE_DOWN));
        menu.add(createMenuItem(MI_GROUP));
        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_CLEAR));

        /* abbot_ext begin */
        mb.add(menu = createMenu("Extensions"));
        menu.add(createMenuItem(MI_TOOLS_UNDO));
        menu.add(createMenuItem(MI_TOOLS_REDO));
        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_TOOLS_INSERTHEADER));
        menu.add(createMenuItem(MI_TOOLS_INSERT_COMMENT_SCREENSHOT));
        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_TOOLS_CUT_STEPS));
        menu.add(createMenuItem(MI_TOOLS_COPY_STEPS));
        menu.add(createMenuItem(MI_TOOLS_PASTE_STEPS));
        menu.add(createMenuItem(MI_TOOLS_EXTRACT_TO_SCRIPT));
        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_TOOLS_CHECKSCRIPTSTYLE));
        menu.add(createMenuItem(MI_TOOLS_BEAUTIFY));
        menu.add(createMenuItem(MI_TOOLS_SHOW_USED_VARIABLES));
        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_TOOLS_EXECUTE_NORMAL));
        menu.add(createMenuItem(MI_TOOLS_EXECUTE_ITERATE));
        menu.add(new JSeparator());

        menu.add(createMenuItem(MI_UDG_GENERATE_USERDOC));

        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_TOOLS_MANAGE_VARIABLES));


        mb.add(menu = createMenu("Test"));
        menu.add(createMenuItem(MI_RUN));
        menu.add(createMenuItem(MI_RUNTO));
        menu.add(createMenuItem(MI_RUNSELECTED));
        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_EXPORT_HIERARCHY));
        menu.add(new JSeparator());
        menu.add(createMenuItem(MI_LAUNCH));
        menu.add(createMenuItem(MI_TERMINATE));
        menu.add(new JSeparator());
        for (int i = MI_TOGGLE_FIRST; i <= MI_TOGGLE_LAST; i++) {
            menu.add(createMenuItem(i));
            if (i == MI_FORK) {
                menu.add(createMenuItem(MI_GETVMARGS));
            }
        }

        mb.add(menu = insertMenu = createMenu("Insert"));
        for (int i = MI_INSERT_FIRST; i <= MI_INSERT_LAST; i++) {
            menu.add(createMenuItem(i));
        }

        mb.add(captureMenu = createMenu("Capture"));
        if (Platform.isOSX()) {
            MRJApplicationUtils.registerAboutHandler(new MRJAboutHandler() {

                @Override
                public void handleAbout() {
                    showAboutBox();
                }
            });
            // TODO: add prefs handler when it becomes available
        } else {
            mb.add(menu = createMenu("Help"));
            menu.add(createMenuItem(MI_ABOUT));

            //abbot_ext_begin
            menu.add(createMenuItem(MI_RELEASENOTES));
            //abbot_ext_end
        }

        return mb;
    }

    public void showAboutBox() {
        if (aboutBox == null) {
            aboutBox = new JDialog(this, Strings.get("About.title"), true);
            String html = Strings.get("Splash");
            JPanel pane = (JPanel)aboutBox.getContentPane();
            pane.setLayout(new BorderLayout());
            JLabel label = new JLabel(html);
            label.setBorder(new EmptyBorder(4, 4, 4, 4));
            pane.add(label, BorderLayout.CENTER);
            //          abbot_ext_begin
            //label = new JLabel(VERSION);
            label = new JLabel(ExtensionVersion.EXTENSION_VERSION);
            //          abbot_ext_end
            label.setHorizontalAlignment(SwingConstants.CENTER);
            pane.add(label, BorderLayout.SOUTH);
            pane.setBorder(new EmptyBorder(4, 4, 4, 4));
            aboutBox.addMouseListener(new MouseAdapter() {

                @Override
                public void mouseClicked(MouseEvent me) {
                    aboutBox.setVisible(false);
                }
            });
            aboutBox.pack();
            aboutBox.setResizable(false);
        }
        // Center on the parent frame
        aboutBox.setLocation(getLocation().x + getWidth() / 2 - aboutBox.getWidth() / 2, getLocation().y
                                                                                         + getHeight()
                                                                                         / 2
                                                                                         - aboutBox.getHeight()
                                                                                         * 2
                                                                                         / 3);
        aboutBox.setVisible(true);
    }


    /* abbot_ext_begin */
    public void showReleaseNotes() {

        // Nicht mehr unterst�tzt

        //    	String filename = "doc/ReleaseNotes.html";
        //    	
        //    	AbbotService.showDocumentation(filename);


    }


    /* abbot_ext_end */


    /** Create a labeled menu and set its mnemonic. */
    private JMenu createMenu(String base) {
        String label = getString(base);
        JMenu tmp = new JMenu(label);
        if (wantMnemonics) {
            String mnemonic = Strings.get(base + ".mn");
            if (mnemonic != null) {
                tmp.setMnemonic(mnemonic.charAt(0));
            }
        }
        return tmp;
    }

    public void setAssertOptions(boolean wait, boolean invert) {
        getComponentBrowser().updateAssertText(wait, invert);
        assertMenu.setText(invert ? getString("AssertNot") : getString("Assert"));
        waitMenu.setText(invert ? getString("WaitNot") : getString("Wait"));
    }

    private void populateMenu(JMenu menu, ArrayList<Action> someActions) {
        for (int i = 0; i < someActions.size(); i++) {
            Action action = someActions.get(i);
            if (action == null)
                menu.add(new JSeparator());
            else {
                JMenuItem mi = new JMenuItem(action);
                mi.setAccelerator((KeyStroke)action.getValue(Action.ACCELERATOR_KEY));
                menu.add(mi);
            }
        }
    }

    /** Fill the menu with available actionXXX methods for the given class. */
    public void populateInsertMenu(ArrayList<Action> someActions) {
        while (insertMenu.getItemCount() > MI_INSERT_COUNT) {
            insertMenu.remove(MI_INSERT_COUNT);
        }
        insertMenu.add(new JSeparator());
        insertMenu.add(actionMenu = createMenu("Action"));
        insertMenu.add(assertMenu = createMenu("Assert"));
        insertMenu.add(waitMenu = createMenu("Wait"));

        populateMenu(actionMenu, someActions);
    }

    /** Fill the menu with available assertXXX methods for the given class. */
    public void populateAssertMenu(ArrayList<Action> someActions) {
        assertMenu.removeAll();
        populateMenu(assertMenu, someActions);
    }

    /** Same as populateAssertMenu, but makes them waits instead. */
    public void populateWaitMenu(ArrayList<Action> someActions) {
        waitMenu.removeAll();
        populateMenu(waitMenu, someActions);
    }

    /** Create the list of recordable GUI actions. */
    public void populateCaptureMenu(ArrayList<Action> someActions) {
        captureMenu.removeAll();
        populateMenu(captureMenu, someActions);
    }

    private static JPanel lastEditor = null;

    public JPanel getEditor() {
        return lastEditor;
    }

    public void setEditor(final JPanel editor) {
        if (editor != null) {
            // make sure the split pane doesn't resize with every new editor
            int loc = scriptSplit.getDividerLocation();
            JScrollPane scroll = new JScrollPane(editor);
            scroll.getViewport().setBackground(editor.getBackground());
            scroll.getViewport().setMinimumSize(editor.getMinimumSize());
            scriptSplit.setRightComponent(scroll);
            if (lastEditor != null) scriptSplit.setDividerLocation(loc);
        } else {
            scriptSplit.setRightComponent(null);
        }
        lastEditor = editor;
    }

    /** If a resource happens to be missing, use its key instead. */
    private static String getString(String key) {
        String value = Strings.get(key);
        if (value == null) value = key;
        return value;
    }

    private void resizeStatusWindow() {
        statusWindow.setResizable(true);
        statusWindow.pack();
        if (!statusShown) {
            Dimension size = statusWindow.getSize();
            Point vwhere = getLocationOnScreen();
            if (size.width < getWidth()) {
                size.width = getWidth();
                statusWindow.setSize(size);
            }
            Point where = new Point();
            where.x = vwhere.x + 10;
            where.y = vwhere.y + getHeight() - size.height;
            if (where.y < vwhere.y + 10) {
                where.y = vwhere.y + 10;
            }
            statusWindow.setLocation(where);
            statusShown = true;
        }
        statusWindow.setResizable(false);
        statusWindow.repaint();
    }

    private JDialog createStatusWindow() {
        JDialog dialog = new JDialog(this, Strings.get("Status.title"), false) {

            @Override
            public Dimension getMaximumSize() {
                Dimension max = super.getMaximumSize();
                max.height = ScriptEditorFrame.this.getMaximumSize().width;
                return max;
            }

            @Override
            public Dimension getMinimumSize() {
                Dimension min = super.getMinimumSize();
                min.height = 150;
                return min;
            }

            @Override
            public Dimension getPreferredSize() {
                Dimension pref = super.getPreferredSize();
                pref.width = ScriptEditorFrame.this.getPreferredSize().width;
                return pref;
            }
        };
        return dialog;
    }

    /* abbot_ext begin */
    public void createPopupMenu() {

        //Create the popup menu.
        JPopupMenu popup = new JPopupMenu();
        popup.add(createMenuItem(MI_TOOLS_CUT_STEPS));
        popup.add(createMenuItem(MI_TOOLS_COPY_STEPS));
        popup.add(createMenuItem(MI_TOOLS_PASTE_STEPS));
        popup.add(createMenuItem(MI_TOOLS_EXTRACT_TO_SCRIPT));

        //Add listener to the text area so the popup menu can come up.
        MouseListener popupListener = new PopupListener(popup);
        getScriptTable().addMouseListener(popupListener);
    }

    /* abbot_ext end */

    /* Port from abbot 1.3 */
    public void showError(String msg) {
        showError(Strings.get("Error.title"), msg);
    }

    /** Global facility for error dialogs. */
    public void showError(String title, String msg) {
        msg = TextFormat.dialog(msg);

        final String aMsg = msg;
        final String aTitle = title;

        try {
            javax.swing.SwingUtilities.invokeLater(new Runnable() {

                @Override
                public void run() {
                    JOptionPane.showMessageDialog(null, aMsg, aTitle, JOptionPane.ERROR_MESSAGE);
                }
            });
        } catch (HeadlessException e) {
            logger.warn("Not possible to run headless...", e);
        }
    }
}
