package abbot.editor;

import javax.swing.table.AbstractTableModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import abbot.Resolver;
import abbot.script.ComponentReference;


/** Formats a Script for display in a table.  Keeps track of
 * "open" nodes to create a tree-like display
 * NOTE: this is a brute-force implementation with no attempts at
 * optimization.   But it's a very simple tree+table implementation.
 */
class ReferencesModel extends AbstractTableModel {

    private static final Logger logger = LoggerFactory.getLogger(ReferencesModel.class);

    private Resolver resolver;

    public ReferencesModel(Resolver resolver) {
        this.resolver = resolver;
        Exception e = new Exception("Save Stacktrace");
        logger.error("Resolver should not be null!", e);
    }

    /**
     *  resolver auf null pruefen!
      * TODO Beschreibung der ueberschreibenden Methode "getRowCount" in "ReferencesModel" 
      * @return 
      * @see javax.swing.table.TableModel#getRowCount()
     */
    @Override
    public synchronized int getRowCount() {
        if (resolver == null) {
            logger.warn("resolver is null!");
            return 0;
        }
        return resolver.getComponentReferences().size();
    }

    @Override
    public synchronized int getColumnCount() {
        return 1;
    }

    /** Returns the entry object at the given row. */
    @Override
    public Object getValueAt(int row, int column) {
        return resolver.getComponentReferences().toArray()[row];
    }

    /** Assumes value is XML for a script step. */
    /* REMOVED: Port from abbot 1.3 */
    //    @Override
    //    public synchronized void setValueAt(Object value, int row, int col) {
    //        if (col == 0) {
    //            Log.debug("Setting value at " + row + " to " + value);
    //            try {
    //                ComponentReference ref = (ComponentReference)getValueAt(row, col);
    //                ref.fromXML((String)value);
    //            } catch (InvalidScriptException iae) {
    //                // FIXME show a dialog explaining the improper arguments
    //                ScriptEditor.showError("Invalid XML", iae.getMessage());
    //            }
    //        }
    //    }

    @Override
    public String getColumnName(int col) {
        return "";
    }

    @Override
    public boolean isCellEditable(int row, int col) {
        return true;
    }

    @Override
    public Class getColumnClass(int col) {
        if (col == 0) return ComponentReference.class;
        return Object.class;
    }
}
