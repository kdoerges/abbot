package abbot.editor;

import abbot.i18n.Strings;

/** Provides text formatting utilities. */

public class TextFormat {
    public static final int TOOLTIP_WRAP = 50;
    public static final int DIALOG_WRAP = 60;

    /** Line separator. */
//    public static final String LS = System.getProperty("line.separator");

    /** Wrap the given text at the given number of characters per line. */
    public static String wordWrap(String msg, int wrapAt, String lineSep) {
        if (msg == null)
            return null;
        
        int len = msg.length();
        StringBuffer sb = new StringBuffer(len * 3 / 2);
        int col = 0;
        int pos = 0;
        int endWord = 0;
        while (pos < len) {
            // as long as successive characters are whitespace, append them
            // until the column limit is reached
            while (pos < len 
                   && Character.isWhitespace(msg.charAt(pos))) {
                // Preserve embedded newlines
                char ch = msg.charAt(pos);
                boolean isNewline = ch == '\n';
                if (col >= wrapAt || isNewline) {
                    sb.append(lineSep);
                    if (isNewline) {
                        col = 0;
                    }
                }
                else {
                    // Ignore spaces at beginning of lines
                    if (col != 0 || !Character.isSpaceChar(ch)) {
                        sb.append(ch);
                        ++col;
                    }
                }
                ++pos;
            }
            if (pos < len) {
                endWord = pos;
                // figure out how long the next word is
                while (endWord < len
                       && !Character.isWhitespace(msg.charAt(endWord))) {
                    ++endWord;
                }
                if (endWord - pos > wrapAt - col) {
                    sb.append(lineSep);
                    col = 0;
                }
                while (pos < endWord) {
                    sb.append(msg.charAt(pos++));
                    ++col;
                }
            }
        }

        return sb.toString();
    }

    /** Emit html, suitably line-wrapped and formatted for a tool tip. */
    public static String tooltip(String tip) {
        if (tip.startsWith("<html>")) {
            tip = tip.substring(6, tip.length() - 7);
        }
        else {
            tip = wordWrap(tip, TOOLTIP_WRAP, "<br>");
        }
        return Strings.get("TooltipFormat", new Object[] { tip });
    }

    /** Emit html, suitably line-wrapped and formatted for a dialog. */
    public static String dialog(String msg) {
        if (msg.startsWith("<html>")) {
            msg = msg.substring(6, msg.length() - 7);
        }
        else {
            msg = wordWrap(msg, DIALOG_WRAP, "<br>");
        }
        return Strings.get("DialogFormat", new Object[] { msg });
    }
}
