package abbot.editor;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import abbot.*;
import abbot.editor.editors.XMLEditor;
import abbot.i18n.Strings;
import abbot.script.ComponentReference;
import abbot.tester.Robot;
import abbot.util.AWT;

import com.obi.test.tregs.abbot.component.AbbotProperties;


/** Browse an existing component hierarchy.  Thanks to the JFCUnit guys for
 * the basis for this code.
 */
// FIXME put the component reference ID into a label, not in the status
public class ComponentBrowser extends JPanel implements ActionListener {

    private final int TAB_HIERARCHY = 0;

    private JButton refreshButton;

    private JCheckBox filterButton;

    private JButton addAssertButton;

    private JButton addSampleButton;

    private JCheckBox filterPropertiesCheckBox;

    private Resolver resolver;

    private JTree componentTree;

    private DefaultTreeModel treeModel;

    private JTable propTable;

    private ReferencesModel refModel;

    private JTable refTable;

    private ComponentPropertyModel ptm;

    private ComponentNode rootNode;

    private boolean filter = true;

    private JTabbedPane tabs;

    private final EventQueue rootQueue;

    /** Currently selected component. */
    private Component selectedComponent = null;

    /** Is the currently selected component "fake"? */
    private boolean fakeComponent = false;

    /** Currently selected reference. */
    private ComponentReference selectedReference = null;

    private final ComponentFinder finder;

    /**
     * Default constructor
     */
    public ComponentBrowser(Resolver resolver, ComponentFinder finder) {
        this.resolver = resolver;
        this.finder = finder;
        setName("ComponentBrowser");
        equip(this);
        setSelectedComponent(null);
        setSelectedReference(null);

        // Listen for hierarchy changes and new windows so that we can update
        // the tree appropriately.
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        rootQueue = toolkit.getSystemEventQueue();

        // Track hierarchy changes and window open/close events.
        AWTEventListener awtl = new AWTEventListener() {

            private HierarchyListener hl = new BrowserHierarchyListener();

            @Override
            public void eventDispatched(AWTEvent ev) {
                if (AWT.isTransientPopup(ev.getSource())) return;

                boolean fire = false;
                if (ev.getID() == WindowEvent.WINDOW_OPENED) {
                    Component comp = (Component)ev.getSource();
                    if (!isFiltered(comp)) {
                        comp.addHierarchyListener(hl);
                        fire = true;
                    }
                } else if (ev.getID() == WindowEvent.WINDOW_CLOSED) {
                    Component comp = (Component)ev.getSource();
                    if (!isFiltered(comp)) {
                        comp.removeHierarchyListener(hl);
                        fire = true;
                    }
                }
                if (fire) {
                    fireHierarchyChanged();
                }
            }
        };
        long mask = WindowEvent.WINDOW_EVENT_MASK | HierarchyEvent.HIERARCHY_EVENT_MASK;
        toolkit.addAWTEventListener(awtl, mask);
    }

    /**
     * Method to create required widgets/components and populate
     * the content pane with them.
     *
     * @param pane   The content pane to which the created objects have to
     *               be added into.
     */
    private void equip(Container pane) {
        setLayout(new BorderLayout());
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, createLeftPanel(), createRightPanel());
        // prefer tree over property table
        split.setResizeWeight(1.0);
        split.setDividerSize(4);
        split.setBorder(null);
        pane.add(split, BorderLayout.CENTER);
    }

    private JPanel createHierarchyView() {
        JPanel pane = new JPanel(new BorderLayout());
        rootNode = new ComponentNode();
        componentTree = new JTree(rootNode) {

            @Override
            public void setSelectionPath(TreePath path) {
                // Make sure the selection is always visible
                super.setSelectionPath(path);
                Rectangle rect = getPathBounds(path);
                if (rect != null) super.scrollRectToVisible(rect);
                Log.debug("Path set to '" + path + "'");
            }
        };
        componentTree.setShowsRootHandles(true);
        componentTree.addTreeSelectionListener(new TreeSelectionListener() {

            @Override
            public void valueChanged(TreeSelectionEvent e) {
                if (!ignoreHierarchyChange) setSelectedComponent(getSelectedComponentFromTree());
            }
        });
        componentTree.setScrollsOnExpand(true);
        treeModel = (DefaultTreeModel)componentTree.getModel();
        JScrollPane scroll = new JScrollPane(componentTree);
        scroll.getViewport().setBackground(componentTree.getBackground());
        pane.add(scroll, BorderLayout.CENTER);

        refreshButton = new JButton(Strings.get("Reload"));
        refreshButton.addActionListener(this);
        filterButton = new JCheckBox(Strings.get("Filter"));
        filterButton.addActionListener(this);
        filterButton.setSelected(filter);
        JPanel buttons = new JPanel();
        buttons.add(refreshButton);
        buttons.add(filterButton);
        pane.add(buttons, BorderLayout.SOUTH);
        return pane;
    }

    /** Set the resolver on which the references list is based. */
    public void setResolver(Resolver resolver) {
        this.resolver = resolver;
        refModel = new ReferencesModel(resolver);
        refTable.setModel(refModel);
    }

    private Component createReferenceView() {
        // FIXME need buttons for new/delete (delete only enabled if the
        // reference is entirely unused
        refModel = new ReferencesModel(resolver);
        refTable = new JTable(refModel) {

            @Override
            public void setRowSelectionInterval(int start, int end) {
                Log.debug("Setting row selection " + start + "," + end);
                super.setRowSelectionInterval(start, end);
                // Make sure the selection is always visible. 
                Rectangle cellRect = getCellRect(start, 0, false);
                if (cellRect != null) super.scrollRectToVisible(cellRect);
            }
        };
        refTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        refTable.setDefaultEditor(ComponentReference.class, new XMLEditor());
        refTable.clearSelection();
        ListSelectionListener lsl = new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent lse) {
                if (!lse.getValueIsAdjusting()) {
                    referenceListSelectionChanged(lse);
                }
            }
        };
        refTable.getSelectionModel().addListSelectionListener(lsl);
        JScrollPane scroll = new JScrollPane(refTable);
        scroll.getViewport().setBackground(refTable.getBackground());
        return scroll;
    }

    /**
     * Create a tabbed pane for browsing either existing components or
     * component references.
     *
     * @return A JPanel for the left side of the main frame
     */
    private Component createLeftPanel() {
        tabs = new JTabbedPane() {

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(250, 200);
            }
        };
        tabs.add(Strings.get("Hierarchy"), createHierarchyView());
        tabs.add(Strings.get("References"), createReferenceView());
        tabs.addChangeListener(new ChangeListener() {

            @Override
            public void stateChanged(ChangeEvent e) {
                tabChanged(e);
            }
        });
        return tabs;
    }

    /**
     * Create the property browser/selection table.
     *
     * @return A JPanel for the right side of the main frame
     */
    private JPanel createRightPanel() {
        JPanel pane = new JPanel(new BorderLayout()) {

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(300, 150);
            }
        };
        ptm = new ComponentPropertyModel();
        propTable = new JTable(ptm);
        propTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        propTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        ListSelectionListener lsl = new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent lse) {
                if (!lse.getValueIsAdjusting()) {
                    propertyListSelectionChanged(lse);
                }
            }
        };
        propTable.getSelectionModel().addListSelectionListener(lsl);

        String label = Strings.get("AssertProperty", new Object[] {Strings.get("Equals")});
        addAssertButton = new JButton(label);
        addAssertButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ev) {
                firePropertyCheck(false);
            }
        });
        addAssertButton.setEnabled(false);
        addSampleButton = new JButton(Strings.get("SampleProperty"));
        addSampleButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ev) {
                firePropertyCheck(true);
            }
        });
        addSampleButton.setEnabled(false);

        String waitKeyName = KeyEvent.getKeyText(ScriptEditor.KC_WAIT);
        String invertKeyName = KeyEvent.getKeyText(ScriptEditor.KC_INVERT);
        String tip = Strings.get("AssertPropertyTip", new Object[] {invertKeyName, waitKeyName,});
        addAssertButton.setToolTipText(TextFormat.tooltip(tip));
        tip = Strings.get("SamplePropertyTip");
        addSampleButton.setToolTipText(TextFormat.tooltip(tip));

        filterPropertiesCheckBox = new JCheckBox(Strings.get("Filter"));
        filterPropertiesCheckBox.addActionListener(this);
        filterPropertiesCheckBox.setEnabled(true);
        filterPropertiesCheckBox.setSelected(true);
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.add(addAssertButton);
        buttonsPanel.add(addSampleButton);
        buttonsPanel.add(filterPropertiesCheckBox);

        JScrollPane scroll = new JScrollPane(propTable);
        scroll.getViewport().setBackground(propTable.getBackground());
        scroll.setColumnHeaderView(propTable.getTableHeader());
        pane.add(scroll, BorderLayout.CENTER);
        pane.add(buttonsPanel, BorderLayout.SOUTH);
        return pane;
    }

    public void updateAssertText(boolean isWait, boolean invert) {
        addAssertButton.setText(Strings.get(isWait ? "WaitProperty" : "AssertProperty",
                                            new Object[] {invert ? Strings.get("NotEquals") : Strings.get("Equals")}));
    }

    /** Select the given reference in the current view. */
    public void setSelectedReference(ComponentReference ref) {
        boolean update = ref != getSelectedReferenceFromList();
        if (ref != selectedReference) {
            selectedReference = ref;
            if (update) {
                updateReferenceSelection(ref);
            }
            Component c = ref != null ? getComponentForReference(ref) : null;
            if (c != selectedComponent) {
                selectedComponent = c;
                updateComponentSelection(c);
            }
            updatePropertyList();
            fireSelectionChanged();
        }
    }

    /** Select the given component (and make it visible) in the current
    	view.  Update the auxiliary view components appropriately.
    	If showing component references and the given component doesn't have
    	one, switch the view to the hierarchy.
    */
    public void setSelectedComponent(Component comp) {
        boolean update = comp != getSelectedComponentFromTree();
        Log.debug("Setting selected component to " + Robot.toString(comp));
        selectedComponent = comp;
        ComponentReference ref = comp == null ? null : resolver.getComponentReference(comp);
        if (ref != selectedReference) {
            selectedReference = ref;
            updateReferenceSelection(ref);
        }
        if (ref == null && !showingHierarchy()) {
            tabs.setSelectedIndex(TAB_HIERARCHY);
        }
        if (update) {
            updateComponentSelection(comp);
        }
        updatePropertyList();
        fireSelectionChanged();
    }

    /** Return the row index of the given component reference. */
    private int getRow(ComponentReference ref) {
        if (ref != null) {
            for (int i = 0; i < refTable.getRowCount(); i++) {
                ComponentReference value = (ComponentReference)refTable.getValueAt(i, 0);
                if (ref == value) {
                    return i;
                }
            }
        }
        return -1;
    }

    /** Flag to avoid responding to list/tree selection changes when they're
     * made programmatically instead of by the user.
     */
    private boolean ignoreHierarchyChange = false;

    private boolean ignoreReferenceChange = false;

    /** Set the appropriate selection in the reference list. */
    private void updateReferenceSelection(ComponentReference ref) {
        if (!showingHierarchy()) {
            Log.debug("Setting ref table selection to " + ref);
            int row = getRow(ref);
            ignoreReferenceChange = true;
            if (row == -1) {
                Log.debug("Clearing ref table selection");
                refTable.clearSelection();
            } else {
                refTable.setRowSelectionInterval(row, row);
            }
            ignoreReferenceChange = false;
        }
    }

    /** Set the appropriate selection in the component hierarchy tree. */
    private void updateComponentSelection(Component comp) {
        if (showingHierarchy()) {
            Log.debug("Setting component tree selection to " + comp);
            ignoreHierarchyChange = true;
            if (comp == null) {
                componentTree.clearSelection();
            } else {
                TreePath path = getPath(comp);
                componentTree.setSelectionPath(path);
            }
            ignoreHierarchyChange = false;
        }
    }

    /**
     * Utility method showing whether a component node has been selected or
     * not. 
     */
    public boolean isComponentSelected() {
        if (showingHierarchy()) {
            return (ComponentNode)componentTree.getLastSelectedPathComponent() != null;
        }
        return refTable.getSelectedRow() != -1;
    }

    private boolean isRootQueue() {
        return rootQueue == Toolkit.getDefaultToolkit().getSystemEventQueue();
    }

    /** When re-enabled, perform a reload of the tree. */
    @Override
    public void setEnabled(boolean state) {
        super.setEnabled(state);
        if (state) fireHierarchyChanged();
    }

    public void refresh() {
        fireHierarchyChanged();
    }


    /* abbot_ext begin */
    /**
     * Liefert true zur�ck, wenn bei fireHierachyChanged die Dialogreferenzen neu erzeugt werden sollen
     * Es sollte dann abgeschaltet werden, wenn Lasttests durchgef�hrt werden,
     * da ansonsten bereits geschlossene Dialoge noch referenziert und deshalb vom GarbageCollector
     * nicht freigegeben werden k�nnen
     */
    private boolean reloadActivated() {
        if (AbbotProperties.theInstance().getMemoryOptimizing()) {
            return false;
        } else {
            return true;
        }

    }

    /* abbot_ext end */

    private void fireHierarchyChanged() {
        // Only do the direct update when on the root event handling queue, to
        // avoid deadlocks with other queues.

        /* abbot_ext begin */
        // Merken der selektierten Komponente
        Component saveComponent = selectedComponent;
        /* abbot_ext end */

        if (isRootQueue() || Platform.getJavaVersionNumber() > 0x1410) {
            if (isEnabled()) {
                Log.debug("Reloading tree");
                if (reloadActivated()) {
                    rootNode.reload();
                    treeModel.reload();
                }
                /* abbot_ext end */
                if (showingHierarchy()) {
                    TreePath path = getPath(selectedComponent);
                    ComponentNode node = (ComponentNode)path.getLastPathComponent();
                    /* abbot_ext begin */
                    // @TODO ehem. dead-Store, Aufruf notwendig?
                    node.getComponent();
                    setSelectedComponent(saveComponent);
                    //setSelectedComponent(comp);
                    /* abbot_ext end */
                }
            }
        } else {
            Log.debug("Deferring hierarchy update to root queue");
            Toolkit kit = Toolkit.getDefaultToolkit();
            rootQueue.postEvent(new InvocationEvent(kit, new Runnable() {

                @Override
                public void run() {
                    fireHierarchyChanged();
                }
            }));
        }
    }

    private synchronized TreePath getPath(Component comp) {
        if (comp == null) return new TreePath(rootNode);
        TreePath path = getPath(finder.getComponentParent(comp));
        ComponentNode node = (ComponentNode)path.getLastPathComponent();
        for (int i = 0; i < node.getChildCount(); i++) {
            ComponentNode sub = (ComponentNode)node.getChildAt(i);
            if (comp.equals(sub.getComponent())) return path.pathByAddingChild(sub);
        }
        // If the component wasn't found, return the path so far.
        return path;
    }

    /** Convert the component reference into an actual component, creating a
     * dummy one if the real one is not available.
     */
    private Component getComponentForReference(ComponentReference ref) {
        Component comp = null;
        fakeComponent = false;
        try {
            comp = finder.findComponent(ref);
        } catch (MultipleComponentsFoundException mc) {
            // FIXME query the user to select the right one, then add more
            // information to the component reference to get specific enough.
            // For now, use the last one and just show a warning...
            // NOTE: repeated disposable dialogs reek of this
            Component[] list = mc.getComponents();
            String warning = "Multiple components found: ";
            for (int i = 0; i < list.length; i++) {
                warning += "\n" + Robot.toString(mc.getComponents()[i]);
            }
            Log.warn(warning);
            comp = list[list.length - 1];
        } catch (ComponentNotFoundException cnf) {
            try {
                // FIXME make sure the right class loader is used here,
                // notably when the gui under test isn't launched (i.e. the
                // current context will be used instead of the under test
                // context. 
                comp = (Component)(Class.forName(ref.getRefClassName())).newInstance();
                // Don't want it to ever show up in the hierarchy
                finder.filterComponent(comp);
                fakeComponent = true;
            } catch (Exception exc) {
                // Not much we can do here; we require a no-args constructor
            }
        }
        return comp;
    }

    public boolean showingHierarchy() {
        return tabs.getSelectedIndex() == TAB_HIERARCHY;
    }

    /** Returns the currently selected reference. */
    public ComponentReference getSelectedReference() {
        return selectedReference;
    }

    /** Returns which component is currently selected. */
    public Component getSelectedComponent() {
        return selectedComponent;
    }

    private boolean isFiltered(Component comp) {
        return filter && finder.isFiltered(comp);
    }

    /**
     * Generic action handler for buttons.  
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == refreshButton) {
            fireHierarchyChanged();
        } else if (e.getSource() == filterButton) {
            filter = !filter;
            finder.setFilterEnabled(filter);
            fireHierarchyChanged();
        } else if (e.getSource() == filterPropertiesCheckBox) {
            updatePropertyList();
        }
    }

    private void updatePropertyList() {
        // FIXME this should preserve the selection, if possible
        addAssertButton.setEnabled(false);
        addSampleButton.setEnabled(false);
        Component comp = showingHierarchy() || selectedReference != null ? selectedComponent : null;
        ptm.setComponent(comp, filterPropertiesCheckBox.isSelected());
    }

    /** Returns the Component represented by the current tree selection. */
    private Component getSelectedComponentFromTree() {
        ComponentNode node = (ComponentNode)componentTree.getLastSelectedPathComponent();
        Component comp = node != null ? node.getComponent() : null;
        return comp;
    }

    private ComponentReference getReferenceAt(int row) {
        return (ComponentReference)refTable.getValueAt(row, 0);
    }

    /** Returns the component reference represented by the current selection
     * in the reference list.
     */
    private ComponentReference getSelectedReferenceFromList() {
        int refrow = refTable.getSelectedRow();
        return refrow == -1 ? null : getReferenceAt(refrow);
    }

    public void propertyListSelectionChanged(ListSelectionEvent e) {
        int row = propTable.getSelectedRow();
        addAssertButton.setEnabled(row != -1 && isComponentSelected());
        addSampleButton.setEnabled(row != -1 && isComponentSelected());
    }

    /** Called when a the reference list selection changes, and when the
    	property list changes. */
    public void referenceListSelectionChanged(ListSelectionEvent e) {
        if (!ignoreReferenceChange) {
            setSelectedReference(getSelectedReferenceFromList());
        }
    }

    /** Invoked when the tab changes. */
    public void tabChanged(ChangeEvent e) {
        if (showingHierarchy()) {
            // If we were viewing a fake component in the reference view,
            // switch to no component selection in the hierarchy view
            if (fakeComponent) {
                fakeComponent = false;
                setSelectedComponent(null);
            } else {
                updateComponentSelection(selectedComponent);
                updatePropertyList();
            }
        } else {
            // Bug on OSX always leaves a selection in the reference list
            // Avoid it by explicitly setting the selection if we can
            if (selectedReference == null && refTable.getRowCount() > 0) {
                setSelectedReference(getReferenceAt(0));
            } else {
                updateReferenceSelection(selectedReference);
                updatePropertyList();
            }
        }
    }

    private final Vector<ComponentBrowserListener> listeners = new Vector<ComponentBrowserListener>(1);

    public void addSelectionListener(ComponentBrowserListener cbl) {
        listeners.add(cbl);
    }

    public void removeSelectionListener(ComponentBrowserListener cbl) {
        listeners.remove(cbl);
    }

    protected void fireSelectionChanged() {
        if (selectedComponent != null) {
            Log.debug("Selection changed to "
                      + Robot.toString(selectedComponent)
                      + " ("
                      + selectedComponent.getClass().getClassLoader()
                      + ")");
        }
        Enumeration<ComponentBrowserListener> tenum = listeners.elements();
        while (tenum.hasMoreElements()) {
            tenum.nextElement().selectionChanged(this, selectedComponent, selectedReference);
        }
    }

    protected void firePropertyCheck(boolean sample) {
        int row = propTable.getSelectedRow();
        if (row == -1 || selectedComponent == null) return;
        Method m = (Method)ptm.getValueAt(row, ComponentPropertyModel.METHOD_OBJECT);
        Object value = ptm.getValueAt(row, ComponentPropertyModel.PROPERTY_VALUE);
        Log.debug("Selection changed");
        Enumeration<ComponentBrowserListener> tenum = listeners.elements();
        while (tenum.hasMoreElements()) {
            tenum.nextElement().propertyAction(this, m, value, sample);
        }
    }

    private class BrowserHierarchyListener implements HierarchyListener {

        @Override
        public void hierarchyChanged(HierarchyEvent he) {
            Component comp = he.getComponent();
            if (isFiltered(comp)) {
                return;
            }
            /** We need to update the children list if the hierarchy changes,
             * for instance when a JTabbedPane changes the selected tab.
             */
            long flags = he.getChangeFlags();
            // he.DISPLAYABILITY_CHANGED;
            if ((flags & HierarchyEvent.SHOWING_CHANGED) != 0) {
                Log.debug("Fire on showing changed " + Robot.toString(he.getSource()));
                fireHierarchyChanged();
            } else if ((flags & HierarchyEvent.PARENT_CHANGED) != 0) {
                // Ignore certain renderer classes that change parents all the
                // time... 
                // FIXME are there other renderers to watch out for?
                boolean fire =
                        !((comp instanceof javax.swing.tree.TreeCellRenderer)
                          || (comp instanceof javax.swing.ListCellRenderer) || (comp instanceof javax.swing.table.TableCellRenderer));
                if (fire) {
                    fireHierarchyChanged();
                    Log.debug("Fire on parent changed " + Robot.toString(he.getSource()));
                }
            }
        }
    }
}
