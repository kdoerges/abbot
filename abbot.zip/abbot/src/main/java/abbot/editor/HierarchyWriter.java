package abbot.editor;

import java.awt.*;
import java.io.*;
import java.util.*;

import abbot.*;
import abbot.script.*;

/** Provides support for writing out a GUI hierarchy as XML. */
public class HierarchyWriter {

    /** Write to the given writer the GUI hierarchy represented by the given
     * set of root windows.
     */
    public void writeHierarchy(Writer writer, Window[] windows)
        throws IOException {
        Resolver r = new Script();
        writer.write("<awtHierarchy>\r\n");
        for (int i=0;i < windows.length;i++) {
            writeComponent(writer, r, windows[i], 1);
        }
        writer.write("</awtHierarchy>\r\n");
        writer.close();
    }

    // FIXME should include java.awt.MenuBar
    private void writeComponent(Writer writer, Resolver r,
                                Component c, int level) throws IOException {
        ComponentReference ref = new ComponentReference(r, c, false);
        final String INDENT = "  ";
        String xml = ref.toXMLString();
        for (int i=0;i < level;i++) 
            writer.write(INDENT);
        int kidCount = c instanceof Container 
            ? ((Container)c).getComponentCount() : 0;
        Window[] wins = (c instanceof Window)
            ? ((Window)c).getOwnedWindows() : null;
        int winCount = wins != null ? wins.length : 0;
        if (kidCount != 0 || winCount != 0) {
            writer.write(xml.substring(0, xml.length() - 2));
            writer.write(">\r\n");
            Component[] kids = ((Container)c).getComponents();
            for (int i=0;i < kids.length;i++) {
                writeComponent(writer, r, kids[i], level + 1);
            }
            for (int i=0;i < winCount;i++) {
                writeComponent(writer, r, wins[i], level + 1);
            }
            for (int i=0;i < level;i++) 
                writer.write(INDENT);
            writer.write("</component>\r\n");
        }
        else {
            writer.write(xml);
            writer.write("\r\n");
        }
    }
}
