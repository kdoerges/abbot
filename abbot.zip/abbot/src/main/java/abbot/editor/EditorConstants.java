package abbot.editor;

import java.awt.Toolkit;
import java.awt.event.InputEvent;


/** Common constants for editor actions.  NOTE: to add a new editor action,
 * define a constant for it here, possibly create a menu for it in
 * ScriptEditorFrame, add an action for it in
 * abbot.editor.ScriptEditor.createActions and handle it.
 * I know that's a lot of entries, I'd like to clean it up.
 */
public interface EditorConstants {

    static final int menuShortcutMask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();

    static final String menuShortcutString =
            menuShortcutMask == InputEvent.ALT_MASK ? "alt " : menuShortcutMask == InputEvent.META_MASK ? "meta "
                    : menuShortcutMask == InputEvent.SHIFT_MASK ? "shift " : "control ";

    static class Accelerator {

        public static String get(String key) {
            return menuShortcutString + key;
        }
    }

    // Image directory URL
    static final String ABBOT_IMAGE_DIR = "/abbot/editor/icons/";

    static final String LARGE_ICON = "LARGE_ICON";

    // menu actions
    static final int MI_ABOUT = 0;

    // File menu
    static final int MI_NEW = MI_ABOUT + 1;

    static final int MI_OPEN = MI_NEW + 1;

    static final int MI_DUPLICATE = MI_OPEN + 1;

    static final int MI_SAVE = MI_DUPLICATE + 1;

    static final int MI_SAVE_AS = MI_SAVE + 1;

    static final int MI_RENAME = MI_SAVE_AS + 1;

    static final int MI_CLOSE = MI_RENAME + 1;

    /* abbot_ext begin */


    static final int MI_TOOLS_UNDO = MI_CLOSE + 1;

    static final int MI_TOOLS_REDO = MI_TOOLS_UNDO + 1;

    static final int MI_TOOLS_INSERTHEADER = MI_TOOLS_REDO + 1;

    static final int MI_TOOLS_INSERT_COMMENT_SCREENSHOT = MI_TOOLS_INSERTHEADER + 1;

    static final int MI_TOOLS_CUT_STEPS = MI_TOOLS_INSERT_COMMENT_SCREENSHOT + 1;

    static final int MI_TOOLS_COPY_STEPS = MI_TOOLS_CUT_STEPS + 1;

    static final int MI_TOOLS_PASTE_STEPS = MI_TOOLS_COPY_STEPS + 1;

    static final int MI_TOOLS_EXTRACT_TO_SCRIPT = MI_TOOLS_PASTE_STEPS + 1;

    static final int MI_TOOLS_CHECKSCRIPTSTYLE = MI_TOOLS_EXTRACT_TO_SCRIPT + 1;

    static final int MI_TOOLS_BEAUTIFY = MI_TOOLS_CHECKSCRIPTSTYLE + 1;

    static final int MI_TOOLS_SHOW_USED_VARIABLES = MI_TOOLS_BEAUTIFY + 1;

    static final int MI_TOOLS_EXECUTE_NORMAL = MI_TOOLS_SHOW_USED_VARIABLES + 1;

    static final int MI_TOOLS_EXECUTE_ITERATE = MI_TOOLS_EXECUTE_NORMAL + 1;

    static final int MI_UDG_GENERATE_USERDOC = MI_TOOLS_EXECUTE_ITERATE + 1;

    static final int MI_TOOLS_MANAGE_VARIABLES = MI_UDG_GENERATE_USERDOC + 1;


    static final int MI_RELEASENOTES = MI_TOOLS_MANAGE_VARIABLES + 1;

    static final int MI_DELETE = MI_RELEASENOTES + 1;

    static final int MI_EXIT = MI_DELETE + 1;

    /* abbot_ext end */

    // Edit menu
    static final int MI_CUT = MI_EXIT + 1;

    static final int MI_MOVE_UP = MI_CUT + 1;

    static final int MI_MOVE_DOWN = MI_MOVE_UP + 1;

    static final int MI_GROUP = MI_MOVE_DOWN + 1;

    static final int MI_CLEAR = MI_GROUP + 1;

    // Test menu
    static final int MI_RUN = MI_CLEAR + 1;

    static final int MI_RUNTO = MI_RUN + 1;

    static final int MI_RUNSELECTED = MI_RUNTO + 1;

    static final int MI_EXPORT_HIERARCHY = MI_RUNSELECTED + 1;

    static final int MI_LAUNCH = MI_EXPORT_HIERARCHY + 1;

    static final int MI_TERMINATE = MI_LAUNCH + 1;

    static final int MI_GETVMARGS = MI_TERMINATE + 1;

    // Insert menu
    static final int MI_INSERT_FIRST = MI_GETVMARGS + 1;

    static final int MI_INSERT_LAUNCH = MI_INSERT_FIRST;

    static final int MI_INSERT_TERMINATE = MI_INSERT_LAUNCH + 1;

    static final int MI_INSERT_CALL = MI_INSERT_TERMINATE + 1;

    static final int MI_INSERT_SAMPLE = MI_INSERT_CALL + 1;

    static final int MI_INSERT_SEQUENCE = MI_INSERT_SAMPLE + 1;

    static final int MI_INSERT_SCRIPT = MI_INSERT_SEQUENCE + 1;

    static final int MI_INSERT_COMMENT = MI_INSERT_SCRIPT + 1;

    static final int MI_INSERT_ANNOTATION = MI_INSERT_COMMENT + 1;

    static final int MI_INSERT_LAST = MI_INSERT_ANNOTATION;

    static final int MI_INSERT_COUNT = MI_INSERT_LAST - MI_INSERT_FIRST + 1;

    // Toggle options
    static final int MI_TOGGLE_FIRST = MI_INSERT_LAST + 1;

    static final int MI_STOP_ON_FAILURE = MI_TOGGLE_FIRST;

    static final int MI_STOP_ON_ERROR = MI_STOP_ON_FAILURE + 1;

    static final int MI_FORK = MI_STOP_ON_ERROR + 1;

    static final int MI_SLOW = MI_FORK + 1;

    static final int MI_TOGGLE_LAST = MI_SLOW;

    /** Total menu item action count. */
    static final int MI_COUNT = MI_TOGGLE_LAST + 1;

    // Other actions, currently not in menus
    static final int MI_SELECT_TESTSUITE = MI_COUNT;

    /** Total action count (actually one greater than the highest index). */

    //abbot_ext_begin
    // static final int MI_ACTION_COUNT = MI_SELECT_TESTSUITE+1;
    // Auf auf alte Anzahl der Actions gesetzt, damit Methode createActions im ScriptEditor nicht abbricht
    static final int MI_ACTION_COUNT = 35;

    //abbot_ext_end

    /** Start of dynamically generated insert actions. */
    static final int MI_INSERT_DYNAMIC = 1000;

    static final int MI_ASSERT_DYNAMIC = 1100;

    static final int MI_WAIT_DYNAMIC = 1200;

    /** Start of dynamically generated capture actions. */
    static final int MI_CAPTURE_DYNAMIC = 2000;


}
