package abbot.editor;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Action;
import javax.swing.JCheckBoxMenuItem;

import abbot.Log;
import abbot.editor.actions.EditorToggleAction;


/** A custom JCheckBoxMenuItem that listens to the selected
 * state of its toggle action.
 */
public class CustomCheckBoxMenuItem extends JCheckBoxMenuItem {

    private PropertyChangeListener pcl;

    public CustomCheckBoxMenuItem(EditorToggleAction a) {
        super(a);
    }

    @Override
    protected void configurePropertiesFromAction(javax.swing.Action a) {
        super.configurePropertiesFromAction(a);
        boolean s = a != null && ((EditorToggleAction)a).isSelected();
        super.setSelected(s);
    }

    @Override
    protected PropertyChangeListener createActionPropertyChangeListener(Action a) {
        pcl = super.createActionPropertyChangeListener(a);
        return new CustomCheckBoxPropertyListener();
    }

    private class CustomCheckBoxPropertyListener implements PropertyChangeListener {

        @Override
        public void propertyChange(PropertyChangeEvent e) {
            Log.debug("Got action prop change: " + e.getPropertyName() + ":" + e.getNewValue());
            pcl.propertyChange(e);
            if (e.getPropertyName().equals(EditorToggleAction.STATE)) {
                Boolean val = (Boolean)e.getNewValue();
                CustomCheckBoxMenuItem.this.setSelected(val == Boolean.TRUE);
            }
        }
    }
}
