package abbot.editor;

/**
 * Nicht JUnit4 Kompatibel!
 */

/**
 * A test class selector. A simple dialog to pick the name of a test suite.
 * Thanks to JUnit for this code.  
 * FIXME this currently doesn't scan jar files, only bare classes, and depends
 * on the class path established at application launch.
 */
//class TestSelector extends JDialog {
//    /** If the selected item is this value, then use no test case class. */
//    public static final String TEST_NONE = "<None>";
//
//    private JButton fCancel;
//    private JButton fOk;
//    private JButton fNone;
//    private JList fList;
//    private JScrollPane fScrolledList;
//    private JLabel fDescription;
//    private String fSelectedItem;
//	
//    /**
//     * Renders TestFailures in a JList
//     */
//    static class TestCellRenderer extends DefaultListCellRenderer {
//        Icon fLeafIcon;
//        Icon fSuiteIcon;
//		
//        public TestCellRenderer() {
//            fLeafIcon= UIManager.getIcon("Tree.leafIcon");
//            fSuiteIcon= UIManager.getIcon("Tree.closedIcon");
//        }
//		
//        public Component getListCellRendererComponent(
//                                                      JList list, Object value, int modelIndex, 
//                                                      boolean isSelected, boolean cellHasFocus) {
//            Component c= super.getListCellRendererComponent(list, value, modelIndex, isSelected, cellHasFocus);
//            String displayString= displayString((String)value);
//			
//            if (displayString.startsWith("AllTests"))
//                setIcon(fSuiteIcon);
//            else
//                setIcon(fLeafIcon);
//				
//            setText(displayString);
//            return c;
//        }
//		
//        public static String displayString(String className) {
//            int typeIndex= className.lastIndexOf('.');
//            if (typeIndex < 0) 
//                return className;
//            return className.substring(typeIndex+1) + " - " + className.substring(0, typeIndex);
//        }
//		
//        public static boolean matchesKey(String s, char ch) {
//            return ch == Character.toUpperCase(s.charAt(typeIndex(s)));
//        }
//		
//        private static int typeIndex(String s) {
//            int typeIndex= s.lastIndexOf('.');
//            int i= 0;
//            if (typeIndex > 0) 
//                i= typeIndex+1;
//            return i;
//        }
//    }
//	
//    protected class DoubleClickListener extends MouseAdapter {
//        public void mouseClicked(MouseEvent e) {
//            if (e.getClickCount() == 2) {
//                okSelected();
//            }
//        }
//    }
//	
//    protected class KeySelectListener extends KeyAdapter {
//        public void keyTyped(KeyEvent e) {
//            keySelectTestClass(e.getKeyChar());
//        }
//    }
//
//    public TestSelector(Frame parent, TestCollector testCollector) {
//        super(parent, true);
//        setSize(350, 300);
//        setResizable(false);
//        setLocationRelativeTo(parent);
//        setTitle(Strings.get("TestSelector.title"));
//		
//        Vector list= null;
//        try {
//            parent.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
//            list= createTestList(testCollector);
//        } finally {
//            parent.setCursor(Cursor.getDefaultCursor());
//        }
//        fList= new JList(list);
//        fList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//        fList.setCellRenderer(new TestCellRenderer());
//        fScrolledList= new JScrollPane(fList);
//
//        fCancel= new JButton(Strings.get("Cancel"));
//        fNone= new JButton(Strings.get("None"));
//        fDescription= new JLabel(Strings.get("SelectTest"));
//        fOk= new JButton(Strings.get("OK"));
//        fOk.setEnabled(false);
//        getRootPane().setDefaultButton(fOk);
//		
//        defineLayout();
//        addListeners();
//    }
//	
//    private void addListeners() {
//        fCancel.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                dispose();
//            }
//        });
//		
//        fNone.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                fSelectedItem = TEST_NONE;
//                dispose();
//            }
//        });
//        fOk.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                okSelected();
//            }
//        });
//
//        fList.addMouseListener(new DoubleClickListener());
//        fList.addKeyListener(new KeySelectListener());
//        fList.addListSelectionListener(new ListSelectionListener() {
//            public void valueChanged(ListSelectionEvent e) {
//                checkEnableOK(e);
//            }
//        });
//
//        addWindowListener(new WindowAdapter() {
//            public void windowClosing(WindowEvent e) {
//                dispose();
//            }
//        });
//    }
//	
//    private void defineLayout() {
//        getContentPane().setLayout(new BorderLayout());
//        ((JPanel)getContentPane()).setBorder(new EmptyBorder(4,4,4,4));
//        getContentPane().add(fDescription, BorderLayout.NORTH);
//        getContentPane().add(fScrolledList, BorderLayout.CENTER);
//		
//        JPanel buttons = new JPanel(new GridLayout(1, 0));
//        buttons.add(fOk);
//        buttons.add(fNone);
//        buttons.add(fCancel);
//        getContentPane().add(buttons, BorderLayout.SOUTH);
//    }
//	
//    public void checkEnableOK(ListSelectionEvent e) {
//        fOk.setEnabled(fList.getSelectedIndex() != -1);
//    }
//	
//    public void okSelected() {
//        fSelectedItem= (String)fList.getSelectedValue();
//        dispose();
//    }
//	
//    public boolean isEmpty() {
//        return fList.getModel().getSize() == 0;
//    }
//	
//    public void keySelectTestClass(char ch) {
//        ListModel model= fList.getModel();
//        if (!Character.isJavaIdentifierStart(ch))
//            return;
//        for (int i= 0; i < model.getSize(); i++) {
//            String s= (String)model.getElementAt(i);
//            if (TestCellRenderer.matchesKey(s, Character.toUpperCase(ch))) {
//                fList.setSelectedIndex(i);
//                fList.ensureIndexIsVisible(i);
//                return;
//            }
//        }
//        Toolkit.getDefaultToolkit().beep();
//    }
//	
//    public String getSelectedItem() {
//        return fSelectedItem;
//    }
//
//    private Vector createTestList(TestCollector collector) {
//        Enumeration each= collector.collectTests();
//        Vector v= new Vector(200);
//        Vector displayVector= new Vector(v.size());
//        while(each.hasMoreElements()) {
//            String s= (String)each.nextElement();
//            v.addElement(s);
//            displayVector.addElement(TestCellRenderer.displayString(s));
//        }
//        if (v.size() > 0)
//            Sorter.sortStrings(displayVector, 0, displayVector.size()-1, new ParallelSwapper(v));
//        return v;
//    }
//	
//    private class ParallelSwapper implements Sorter.Swapper {
//        Vector fOther;
//		
//        ParallelSwapper(Vector other) {
//            fOther= other;
//        }
//        public void swap(Vector values, int left, int right) {
//            Object tmp= values.elementAt(left); 
//            values.setElementAt(values.elementAt(right), left); 
//            values.setElementAt(tmp, right);
//            Object tmp2= fOther.elementAt(left);
//            fOther.setElementAt(fOther.elementAt(right), left);
//            fOther.setElementAt(tmp2, right);
//        }			
//    }
//}
