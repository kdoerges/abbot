package abbot;

/** Indirect usage to avoid too much direct linkage to JUnit. */
public class AssertionFailedError
    extends junit.framework.AssertionFailedError {
    public AssertionFailedError() { }
    public AssertionFailedError(String msg) { super(msg); }
}
