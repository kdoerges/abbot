package abbot;

import java.awt.Component;
import java.awt.Container;
import java.awt.Frame;
import java.awt.Window;
import java.util.Iterator;

import abbot.script.ComponentReference;

/** Interface to support looking up existing components based on a number of
    different criteria.
*/
// FIXME some of these things are simply utilities and don't need to be in the
// interface.
// FIXME should probably split between component examination (getparent,
// getchildren) and component reference resolution; note that filtering only
// really applies to Windows

public interface ComponentFinder {

    /** Attempt to find the given component.  */
    Component findComponent(ComponentReference ref)
        throws ComponentNotFoundException, MultipleComponentsFoundException;

    /** Find the first showing window with a name or title that matches the
     * given string.  If a title is given, a regular expression is allowed.
     */
    Window findWindow(String nameOrTitle)
        throws ComponentNotFoundException, MultipleComponentsFoundException;

    /** Find the active popup menu invoked by the given component.  Returns
     * null if none found.
     */
    Component findActivePopupMenu(Component invoker);

    /** Look up the first menu item below root with the given title. */
    Component findMenuItemByName(Component root, String name);
    
    /** Returns all available root Windows (those that have no parent). */
    Window[] getRootWindows();

    /** Returns all immediate child windows of the given parent window. */
    Window[] getWindows(Window parent);

    /** Returns the set of all available windows. */
    Window[] getWindows();

    /** Return all children of the given container, including Windows,
     * MenuElements, and popup menus.
     */
    Component[] getComponents(Container c);

    /** Look up the apparent parent of a component.  */
    Component getComponentParent(Component comp);

    /** Returns the parent window for the given component.  In this context,
     * the parent of a popup menu is its invoker. */
    Window getComponentWindow(Component comp);

    /** 
     * Return the title of the nearest ancestor window with a title.  
     * If no title is found, return null.
     */
    String getComponentWindowTitle(Component comp);

    /** Return the component's owning frame.   This will only be null in the
     * case of an Applet Dialog, since even a frameless window will have a
     * temporary frame generated for it. 
     */
    Frame getComponentFrame(Component comp);

    /** Return the component's nearest owning window with a title. */
    Window getComponentTitledWindow(Component comp);

    /** Return the component's name. */
    String getComponentName(Component comp);

    /** Returns true if the component or its Window ancestor is filtered. */
    boolean isFiltered(Component comp);

    /** Don't return the given component in any queries.  Makes the given
        component unavailable unless filtering is turned off. */
    void filterComponent(Component comp);

    /** Indicate whether to filter component lists. */
    void setFilterEnabled(boolean enable);

    /** Ignore (for the purpose of future lookup) the given component. */
    void ignoreComponent(Component comp);

    /** Ignore (for the purposes of future lookup) all currently available
     * components.
     */ 
    void ignoreExistingComponents();

    /** Discard all currently available windows. */
    void disposeWindows();

    /** Send close events to all available showing windows. */
    void closeWindows();

    /** Return whether the given component is showing and ready for
     * input.
     */ 
    boolean isShowing(Component c);
}
