package abbot;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;


/** Exception for reporting unexpected situations in the program.
 * Automatically generates a message suitable for posting in a bug report.
 */
public class BugReport extends Error {

    private String error;

    private Throwable exception;

    private static final String LS = System.getProperty("line.separator");

    private static final String REPORT_URL = "http://sourceforge.net/tracker/?func=add&group_id=50939&atid=461490";

    private static String getReportingInfo() {
        return "Please report this bug at the following URL:"
               + LS
               + REPORT_URL
               + LS
               + "(include the stack trace and system information below)";
    }

    private static String getSystemInfo() {
        return LS
               + "          OS: "
               + System.getProperty("os.name")
               + " "
               + System.getProperty("os.version")
               + " ("
               + System.getProperty("os.arch")
               + ") "
               + LS
               + "Java version: "
               + System.getProperty("java.version")
               + " (vm "
               + System.getProperty("java.vm.version")
               + ")"
               + LS
               + "   Classpath: "
               + System.getProperty("java.class.path");
    }

    public BugReport(String error) {
        this(error, null);
    }

    public BugReport(String error, Throwable thr) {
        super(error);
        this.error = error;
        this.exception = thr;
    }

    @Override
    public String toString() {
        String exc = "";
        if (exception != null) {
            OutputStream os = new ByteArrayOutputStream();
            PrintStream ps = new PrintStream(os, true);
            exception.printStackTrace(ps);
            exc = LS + os.toString();
        }
        return error + LS + getReportingInfo() + getSystemInfo() + exc;
    }
}
