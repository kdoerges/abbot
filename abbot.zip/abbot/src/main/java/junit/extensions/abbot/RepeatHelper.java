package junit.extensions.abbot;

import junit.extensions.RepeatedTest;
import junit.framework.Test;
import junit.framework.TestResult;
import junit.framework.TestSuite;
import abbot.Log;

/** Convenience functions to wrap a given test case such that individual
    methods may be run with heavy repetition, and default suites run with
    light repetition. 
*/

public class RepeatHelper {

    // no instantiations
    private RepeatHelper() { }

    public static void runTests(String[] args, Class testClass) {
        args = Log.init(args);
        try {
            Test test;
            if (args.length > 0 && args[0].startsWith("test")) {
                test = (Test)testClass.getConstructor(new Class[]{
                    String.class
                }).newInstance(new Object[] { args[0] });
                // Really stress-test individual cases
                int repeat = 1;
                if (args.length > 1) {
                    try { repeat = Integer.parseInt(args[1]); }
                    catch(NumberFormatException nfe) { }
                }
                if (repeat > 1)
                    test = new RepeatedTest(test, repeat);
            }
            else {
                int repeat = 1;
                if (args.length == 1) {
                    try { repeat = Integer.parseInt(args[0]); }
                    catch(NumberFormatException nfe) { }
                }
                try {
                    test = (Test)testClass.getMethod("suite", null).
                        invoke(null, null);
                }
                catch(Exception exc) {
                    test = new TestSuite(testClass);
                }
                if (args.length > 0) {
                    try { repeat = Integer.parseInt(args[0]); }
                    catch(NumberFormatException nfe) { }
                }
                // Mildly stress-test the whole group
                test = new RepeatedTest(test, repeat);
            }
            junit.textui.TestRunner runner = new junit.textui.TestRunner();
            try {
                TestResult r = runner.doRun(test, false);
                if (!r.wasSuccessful())
                    System.exit(-1);
                System.exit(0);
            }
            catch(Throwable thr) {
                System.err.println(thr.getMessage());
                System.exit(-2);
            }
        }
        catch(Exception exc) {
            System.err.println(exc.getMessage());
            System.exit(-2);
        }
    }
}
