package junit.extensions.abbot;

import abbot.Log;
import abbot.script.Script;
import abbot.script.StepRunner;


/** Simple wrapper for a test script to run under JUnit. */

public class ScriptFixture extends ComponentTestFixture {

    private Script script;

    /** Construct a test case with the given name, which <i>must</i> be the
     * filename of the script to run.
     */
    public ScriptFixture(String filename) {
        // It is essential that the name be passed to super() unmodified, or
        // the JUnit GUI will consider it a different test.
        super(filename);
        script = new Script(filename);
    }

    /** Override the default TestCase runTest method to invoke the script. */
    @Override
    protected void runTest() throws Throwable {
        Log.log("Running " + script + " with " + getClass());
        StepRunner runner = new StepRunner();
        try {
            runner.run(script);
        } finally {
            Log.log(script.toString() + " finished");
        }
    }

    /** Assumes each argument is an Abbot script.  Runs each one. */
    public static void main(String[] args) {
        ScriptTestSuite.main(args);
    }
}
