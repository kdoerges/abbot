package junit.extensions.abbot;


/** @deprecated Use ScriptFixture instead. */
public class ScriptTestCase extends ScriptFixture {

    /** Sole Constructor. */
    public ScriptTestCase(String filename) { 
        super(filename);
    }

    /** Assumes each argument is an Abbot script.  Runs each one. */
    public static void main(String[] args) {
        ScriptTestSuite.main(args);
    }
}
