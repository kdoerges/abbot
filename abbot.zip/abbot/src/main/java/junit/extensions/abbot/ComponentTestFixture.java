package junit.extensions.abbot;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.AWTEventListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.border.EmptyBorder;

import junit.framework.TestCase;
import abbot.ComponentFinder;
import abbot.DefaultComponentFinder;
import abbot.ExitException;
import abbot.Log;
import abbot.Resolver;
import abbot.script.Script;
import abbot.tester.Robot;
import abbot.tester.WindowTracker;
import abbot.util.EventDispatchExceptionHandler;
import abbot.util.Properties;


/** Simple wrapper for testing components under JUnit.  Ensures proper setup
 * and cleanup for a GUI environment.  Provides methods for automatically
 * placing a GUI component within a frame and properly handling Window
 * showing/hiding (including modal dialogs).  Catches exceptions thrown on the
 * event dispatch thread and rethrows them as test failures.<p> 
 * Use showFrame(Component) when testing individual components, or
 * showWindow(Window) when testing a Frame, Dialog, or Window.
 */

public class ComponentTestFixture extends TestCase {

    /** Typical delay to wait for a robot event to be translated into a Java
        event. */
    public static final int EVENT_GENERATION_DELAY = 5000;

    public static final int WINDOW_DELAY = 20000; // for slow systems

    public static final int POPUP_DELAY = 10000;

    private static Robot robot = new Robot();

    private static WindowTracker tracker = WindowTracker.getTracker();

    private static ComponentFinder finder = DefaultComponentFinder.getFinder();

    private Resolver resolver = new Script();

    /** Return an Abbot robot for basic event generation.  */
    protected Robot getRobot() {
        return robot;
    }

    /** Return a WindowTracker instance. */
    protected WindowTracker getWindowTracker() {
        return tracker;
    }

    /** This method should be invoked to display the component under test.
     * The frame's size will be its preferred size.
     */
    protected Frame showFrame(Component comp) {
        return showFrame(comp, null);
    }

    /** This method should be invoked to display the component under test,
     * when a specific size of frame is desired.
     */
    protected Frame showFrame(Component comp, Dimension size) {
        JFrame frame = new JFrame(getName());
        JPanel pane = (JPanel)frame.getContentPane();
        pane.setBorder(new EmptyBorder(10, 10, 10, 10));
        pane.add(comp);
        showWindow(frame, size, true);
        return frame;
    }

    /** Safely display a window, avoiding deadlock. */
    protected void showWindow(Window w) {
        showWindow(w, null, true);
    }

    /** Safely display a window, avoiding deadlock. */
    protected void showWindow(final Window w, final Dimension size) {
        showWindow(w, size, true);
    }

    /** Safely display a window, avoiding deadlock.  This also works with
     * modal dialogs, since the "show" is called on the event dispatch
     * thread. 
     */
    protected void showWindow(final Window w, final Dimension size, final boolean pack) {
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                if (pack) {
                    w.pack();
                    // Make sure the window is positioned away from
                    // any toolbars around the display borders
                    w.setLocation(100, 100);
                }
                if (size != null) w.setSize(size.width, size.height);
                w.show();
            }
        });
        // Ensure the window is visible before returning
        Timer timer = new Timer();
        while (!tracker.isWindowReady(w)) {
            if (timer.elapsed() > WINDOW_DELAY)
                throw new RuntimeException("Timed out waiting for Window to show (" + timer.elapsed() + "ms)");
        }
    }

    /** Synchronous, safe hide of a window. */
    protected void hideWindow(final Window w) {
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                w.hide();
            }
        });
        Timer timer = new Timer();
        while (w.isShowing()) {
            if (timer.elapsed() > WINDOW_DELAY)
                throw new RuntimeException("Timed out waiting for Window to close (" + timer.elapsed() + "ms)");
        }
    }

    /** Install the given popup on the given component.  Takes care of
     * installing the appropriate mouse handler to activate the popup.
     */
    protected void installPopup(Component invoker, final JPopupMenu popup) {
        invoker.addMouseListener(new MouseAdapter() {

            private void maybeShow(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popup.show(e.getComponent(), e.getX(), e.getY());
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                maybeShow(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                maybeShow(e);
            }
        });
    }

    /** Safely display a popup, returning when it is visible. */
    protected void showPopup(final JPopupMenu popup, final Component invoker, final int x, final int y) {
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                popup.show(invoker, x, y);
            }
        });
        Timer timer = new Timer();
        while (!popup.isShowing() || !popup.isVisible()) {
            if (timer.elapsed() > POPUP_DELAY) throw new RuntimeException("Timed out waiting for popup to show");
        }
    }

    /** Construct a test case with the given name.  */
    public ComponentTestFixture(String name) {
        super(name);
    }

    /** Obtain a component finder to look up components. */
    protected ComponentFinder getFinder() {
        return finder;
    }

    /** Obtain a consistent resolver. */
    protected Resolver getResolver() {
        return resolver;
    }

    /** Override the default TestCase runBare method to ensure propert test
     * harness setup and teardown that won't likely be accidentally overridden
     * by a subclass. 
     */
    @Override
    public void runBare() throws Throwable {
        // Preserve all system properties to restore them later
        java.util.Properties oldProps = (java.util.Properties)System.getProperties().clone();

        // Install our own event handler, which will forward events thrown on
        // the event queue
        try {
            new ExceptionCatcher().install();
        } catch (RuntimeException re) {
            // Not fatal if we can't install, since most tests don't
            // depend on it.  We won't be able to throw errors that were
            // generated on the event dispatch thread, though.
        }

        robot.resetPointer();
        if (Robot.hasMultiClickFrameBug()) robot.delay(500);
        // Facilitate debugging by logging all events
        AWTEventListener listener = new AWTEventListener() {

            @Override
            public void eventDispatched(AWTEvent event) {
                Log.debug(Robot.toString(event));
            }
        };
        Toolkit tk = Toolkit.getDefaultToolkit();
        long mask =
                Properties.getProperty("abbot.fixture.event_mask",
                                       Long.MIN_VALUE,
                                       Long.MAX_VALUE,
                                       abbot.editor.recorder.EventRecorder.RECORDING_EVENT_MASK);

        if (Log.isClassDebugEnabled(ComponentTestFixture.class)) {
            Log.debug("Using mask value " + mask);
            tk.addAWTEventListener(listener, mask);
        }

        // Don't interfere with any existing framework (e.g. JUnit gui)
        getFinder().ignoreExistingComponents();

        try {
            super.runBare();
            // If any exceptions were thrown on the event dispatch thread,
            // re-throw them here.  Note that these will only show up if no
            // other exception was thrown.
            Throwable thr = ExceptionCatcher.getThrowable();
            if (thr != null) {
                throw thr;
            }
        } finally {
            getFinder().disposeWindows();
            tk.removeAWTEventListener(listener);
            System.setProperties(oldProps);
        }
    }

    /** Provide access to the most recent exception caught on the dispatch
     * thread.
     */
    public static class ExceptionCatcher extends EventDispatchExceptionHandler {

        private static Throwable throwable = null;

        @Override
        public void install() {
            clear();
            super.install();
        }

        /** Return the most recent exception caught on the dispatch thread, or
            null if none has been thrown.  Also clears the exception.
        */
        public synchronized static Throwable getThrowable() {
            Throwable t = throwable;
            clear();
            return t;
        }

        public synchronized static void clear() {
            throwable = null;
        }

        @Override
        protected void exceptionCaught(Throwable thr) {
            if (!(thr instanceof ExitException)) {
                synchronized (ExceptionCatcher.class) {
                    throwable = thr;
                }
            }
        }
    }
}
