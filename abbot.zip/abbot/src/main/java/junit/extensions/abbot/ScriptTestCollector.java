package junit.extensions.abbot;


/**
 * Nicht JUnit4 Kompatibel!
 */

/** Collects all available classes derived from ScriptTestCase in the current
 * classpath.
 */
/**
public class ScriptTestCollector extends LoadingTestCollector {
    private ClassLoader loader;

    public ScriptTestCollector() {
        loader = Thread.currentThread().getContextClassLoader();
        if (loader == null)
            loader = new TestCaseClassLoader();
    }

    protected boolean isTestClass(String classFileName) {
        Log.debug("Checking " + classFileName);
        if (super.isTestClass(classFileName)) {
            try {
                Class testClass = getClassFromFile(classFileName);
                return testClass != null
                    && (ScriptFixture.class.isAssignableFrom(testClass)
                        || ScriptTestSuite.class.isAssignableFrom(testClass));
            }
            catch(ClassNotFoundException expected) {
            }
            catch(NoClassDefFoundError notFatal) {
            }
        }
        return false;
    }

    private Class getClassFromFile(String classFileName) 
        throws ClassNotFoundException {
        String className = classNameFromFile(classFileName);
        return loader.loadClass(className);
    }
}
**/
