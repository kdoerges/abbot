package junit.extensions.abbot;

import java.util.ArrayList;

import junit.framework.Test;
import junit.framework.TestResult;
import junit.framework.TestSuite;
import abbot.Log;


/** Provides automatic test suite generation given command-line arguments.
 * Also allows for a single test to be run if it is specified.  Supports "-v"
 * (verbose) to display each test's name prior to running the test (aids in
 * identifying which test failed when the VM crashes).
 */

public class TestHelper {

    private TestHelper() {}

    public static Test generateSuite(Class[] classes) {
        TestSuite suite = new TestSuite();
        for (int i = 0; i < classes.length; i++) {
            try {
                java.lang.reflect.Method suiteMethod = classes[i].getMethod("suite", null);
                suite.addTest((Test)suiteMethod.invoke(null, null));
            } catch (Exception exc) {
                suite.addTest(new TestSuite(classes[i]));
            }
        }
        return suite;
    }

    private static boolean printNames = false;

    private static String[] parseArgs(String[] args) {
        ArrayList newArgs = new ArrayList();
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-v"))
                printNames = true;
            else {
                newArgs.add(args[i]);
            }
        }
        return (String[])newArgs.toArray(new String[newArgs.size()]);
    }

    public static void runTests(String[] args, Class testClass) {
        args = Log.init(args);
        args = parseArgs(args);

        try {
            Test test;
            if (args.length == 1 && args[0].startsWith("test")) {
                test = (Test)testClass.getConstructor(new Class[] {String.class}).newInstance(new Object[] {args[0]});
            } else {
                try {
                    test = (Test)testClass.getMethod("suite", null).invoke(null, null);
                } catch (Exception exc) {
                    test = new TestSuite(testClass);
                }
            }
            junit.textui.TestRunner runner = new junit.textui.TestRunner() {

                @Override
                public synchronized void startTest(Test test) {
                    // if (printNames)
                    // TODO: compatibility
                    // writer().print(test.toString());
                    super.startTest(test);
                }

                @Override
                public synchronized void endTest(Test test) {
                    super.endTest(test);
                    // if (printNames)
                    // TODO: compatibility
                    // writer().println("");
                }
            };
            try {
                TestResult r = runner.doRun(test, false);
                if (!r.wasSuccessful()) System.exit(-1);
                System.exit(0);
            } catch (Throwable thr) {
                System.err.println(thr.getMessage());
                System.exit(-2);
            }
        } catch (Exception exc) {
            System.err.println(exc.getMessage());
            System.exit(-2);
        }
    }
}
