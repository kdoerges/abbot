package abbot.script;

import junit.extensions.abbot.TestHelper;
import junit.framework.TestCase;

/** 
 * Verify the sequence works as advertised.
 */
public class SequenceTest extends TestCase {

    public void testStub() {
    }

    public SequenceTest(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestHelper.runTests(args, SequenceTest.class);
    }
}
