
#!/bin/sh

mvn gpg:sign-and-deploy-file -Dfile=build/abbot.jar -DpomFile=abbot.xml -Durl=http://oss.sonatype.org/service/local/staging/deploy/maven2/ -DrepositoryId=ossrh
mvn gpg:sign-and-deploy-file -Dfile=build/costello.jar -DpomFile=costello.xml -Durl=http://oss.sonatype.org/service/local/staging/deploy/maven2/ -DrepositoryId=ossrh


mvn gpg:sign-and-deploy-file -Dfile=build/abbot-src.zip -DpomFile=abbot.xml -Durl=http://oss.sonatype.org/service/local/staging/deploy/maven2/ -DrepositoryId=ossrh -Dclassifier=sources
mvn gpg:sign-and-deploy-file -Dfile=build/costello-src.zip -DpomFile=costello.xml -Durl=http://oss.sonatype.org/service/local/staging/deploy/maven2/ -DrepositoryId=ossrh -Dclassifier=sources


mvn gpg:sign-and-deploy-file -Dfile=build/abbot-doc.zip -DpomFile=abbot.xml -Durl=http://oss.sonatype.org/service/local/staging/deploy/maven2/ -DrepositoryId=ossrh -Dclassifier=javadoc

mvn gpg:sign-and-deploy-file -Dfile=build/abbot-doc.zip -DpomFile=costello.xml -Durl=http://oss.sonatype.org/service/local/staging/deploy/maven2/ -DrepositoryId=ossrh -Dclassifier=javadoc

