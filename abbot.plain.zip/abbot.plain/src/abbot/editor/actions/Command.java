package abbot.editor.actions;

public interface Command {
    public void execute();
}
